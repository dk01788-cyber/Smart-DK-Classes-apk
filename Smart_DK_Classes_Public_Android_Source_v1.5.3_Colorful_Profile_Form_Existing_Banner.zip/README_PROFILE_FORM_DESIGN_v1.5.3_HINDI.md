# Smart DK Classes Public App v1.5.3 — Colorful Profile Form

## बदलाव
- First-run Student Profile form का colorful, card-based UI.
- ऐप के मौजूदा `app/src/main/assets/images/banner.png` को header banner के रूप में उपयोग किया गया है; नया/अलग banner नहीं लगाया गया।
- Name और 10-digit mobile required; OTP नहीं।
- Profile photo optional; add/change/remove actions retained.
- Existing local profile save and `ProfileSync.sync(this)` flow retained.
- Profile edit mode में Save Changes और Back to Home retained.
- बाकी app structure और features को नहीं बदला गया।

## Build
1. ZIP extract करें और Android Studio में project root खोलें।
2. Gradle Sync करें।
3. Build > Build APK(s) से APK बनाएं।
4. पहले test device पर install करके banner crop, profile save, photo selection और Continue flow जाँचें।

Application ID: `com.smartdkclasses.app`
Version: `1.5.3` (versionCode 29)

यह source ZIP है, prebuilt APK नहीं। इस environment में Android Gradle build/device test नहीं चलाया गया है।
