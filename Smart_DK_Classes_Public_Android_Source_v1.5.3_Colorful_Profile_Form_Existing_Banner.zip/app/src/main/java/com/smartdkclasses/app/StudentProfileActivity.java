package com.smartdkclasses.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.UUID;
import org.json.JSONObject;

/** Colorful student profile form using the existing Smart DK Classes banner asset. */
public final class StudentProfileActivity extends Activity {
    public static final String PREF = "sdkc_student_profile_v1";
    private static final int SELECT_PHOTO=7001;
    private final int blue=Color.rgb(7,91,216);
    private final int navy=Color.rgb(14,43,110);
    private final int ink=Color.rgb(24,47,83);
    private EditText name, phone;
    private ImageView photo;
    private boolean editing;
    public static SharedPreferences prefs(Activity a){return a.getSharedPreferences(PREF,MODE_PRIVATE);}
    public static String currentName(Activity a){return prefs(a).getString("name","");}
    public static String currentPhoto(Activity a){
       try {File f=new File(a.getFilesDir(),"sdkc_student_avatar.jpg");if(!f.exists())return "";
         try(InputStream in=new java.io.FileInputStream(f)){
           byte[] buff=new byte[(int)Math.min(f.length(),100000)];int pos=0,n;
           while(pos<buff.length&&(n=in.read(buff,pos,buff.length-pos))>0)pos+=n;
           return "data:image/jpeg;base64,"+Base64.encodeToString(buff,0,pos,Base64.NO_WRAP);
         }
       }catch(Exception ex){return "";}
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(blue);getWindow().setNavigationBarColor(Color.WHITE);
        editing=getIntent().getBooleanExtra("edit",false);draw();}

    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable shape(int color,int radius,int strokeColor,int strokeDp){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(strokeDp>0)d.setStroke(dp(strokeDp),strokeColor);return d;
    }
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void draw(){
      SharedPreferences sp=prefs(this);
      ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(242,247,255));
      LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(16),dp(14),dp(16),dp(28));

      // Existing SDKC banner from app/src/main/assets/images/banner.png (not a replacement banner).
      ImageView banner=new ImageView(this);banner.setScaleType(ImageView.ScaleType.CENTER_CROP);banner.setBackground(shape(Color.WHITE,18,Color.rgb(218,229,250),1));
      try(InputStream in=getAssets().open("images/banner.png")){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)banner.setImageBitmap(b);}catch(Exception ignored){}
      LinearLayout.LayoutParams bp=lp(-1,132);bp.bottomMargin=dp(16);page.addView(banner,bp);

      LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(20),dp(18),dp(20));card.setBackground(shape(Color.WHITE,24,Color.rgb(220,231,250),1));
      if(android.os.Build.VERSION.SDK_INT>=21){card.setElevation(dp(5));}
      TextView welcome=text(editing?"✨  Edit Your Profile":"👋  Welcome to Smart DK Classes!",23,navy,true);welcome.setGravity(Gravity.CENTER);card.addView(welcome,lp(-1,-2));
      TextView subtitle=text(editing?"Keep your student details up to date":"Personalize your learning experience",14,Color.rgb(93,112,145),false);subtitle.setGravity(Gravity.CENTER);LinearLayout.LayoutParams subp=lp(-1,-2);subp.topMargin=dp(7);subp.bottomMargin=dp(16);card.addView(subtitle,subp);

      LinearLayout photoPanel=new LinearLayout(this);photoPanel.setOrientation(LinearLayout.VERTICAL);photoPanel.setGravity(Gravity.CENTER);photoPanel.setPadding(dp(12),dp(12),dp(12),dp(12));photoPanel.setBackground(shape(Color.rgb(239,246,255),18,Color.rgb(214,229,255),1));
      photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setBackground(shape(Color.rgb(215,232,255),60,Color.WHITE,3));photo.setClipToOutline(true);
      LinearLayout.LayoutParams pp=lp(92,92);pp.gravity=Gravity.CENTER;photoPanel.addView(photo,pp);renderPhoto();
      TextView photoTitle=text("Add a profile photo",15,ink,true);photoTitle.setGravity(Gravity.CENTER);LinearLayout.LayoutParams pt=lp(-1,-2);pt.topMargin=dp(8);photoPanel.addView(photoTitle,pt);
      TextView photoSub=text("Optional • You can continue without a photo",12,Color.rgb(100,119,151),false);photoSub.setGravity(Gravity.CENTER);LinearLayout.LayoutParams ps=lp(-1,-2);ps.topMargin=dp(3);photoPanel.addView(photoSub,ps);
      Button pick=new Button(this);pick.setText("📷  Choose Photo");pick.setAllCaps(false);pick.setTextColor(Color.WHITE);pick.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));LinearLayout.LayoutParams pickp=lp(-1,46);pickp.topMargin=dp(10);photoPanel.addView(pick,pickp);pick.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(i,"Select profile photo"),SELECT_PHOTO);});
      TextView remove=text("Remove photo",12,Color.rgb(213,63,83),true);remove.setGravity(Gravity.CENTER);LinearLayout.LayoutParams rp=lp(-1,32);rp.topMargin=dp(2);photoPanel.addView(remove,rp);remove.setOnClickListener(v->{new File(getFilesDir(),"sdkc_student_avatar.jpg").delete();renderPhoto();});
      LinearLayout.LayoutParams phlp=lp(-1,-2);phlp.bottomMargin=dp(18);card.addView(photoPanel,phlp);

      card.addView(fieldLabel("Full Name *"));name=input("Enter your full name",sp.getString("name",""),InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);card.addView(name,lp(-1,54));
      LinearLayout.LayoutParams gap=lp(1,12);card.addView(new View(this),gap);
      card.addView(fieldLabel("Mobile Number *"));phone=input("Enter 10-digit mobile number",sp.getString("mobile",""),InputType.TYPE_CLASS_NUMBER);phone.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});card.addView(phone,lp(-1,54));
      TextView otp=text("🔒  No OTP • No login password required",12,Color.rgb(63,104,155),false);otp.setGravity(Gravity.CENTER);LinearLayout.LayoutParams op=lp(-1,-2);op.topMargin=dp(9);op.bottomMargin=dp(14);card.addView(otp,op);

      LinearLayout notice=new LinearLayout(this);notice.setOrientation(LinearLayout.VERTICAL);notice.setPadding(dp(12),dp(12),dp(12),dp(12));notice.setBackground(shape(Color.rgb(255,248,226),14,Color.rgb(255,224,151),1));
      TextView nt=text("ℹ️  Profile & Mock Test Results",13,Color.rgb(128,82,10),true);notice.addView(nt);
      TextView nd=text("Your name and mobile number will be saved in Smart DK Classes Admin. Your mobile number is not OTP-verified. Photo is optional and stays on this phone.",12,Color.rgb(111,91,54),false);LinearLayout.LayoutParams ndp=lp(-1,-2);ndp.topMargin=dp(4);notice.addView(nd,ndp);LinearLayout.LayoutParams np=lp(-1,-2);np.bottomMargin=dp(16);card.addView(notice,np);

      Button save=new Button(this);save.setText(editing?"✓  Save Changes":"Continue to Classes  ➜");save.setAllCaps(false);save.setTextSize(16);save.setTypeface(Typeface.DEFAULT,Typeface.BOLD);save.setTextColor(Color.WHITE);save.setBackground(shape(blue,16,blue,0));if(android.os.Build.VERSION.SDK_INT>=21)save.setElevation(dp(3));card.addView(save,lp(-1,54));save.setOnClickListener(v->save());
      if(editing){TextView back=text("Back to Home",14,blue,true);back.setGravity(Gravity.CENTER);LinearLayout.LayoutParams backp=lp(-1,42);backp.topMargin=dp(5);card.addView(back,backp);back.setOnClickListener(v->finish());}
      page.addView(card,lp(-1,-2));
      TextView footer=text("SMART DK CLASSES  •  Learn • Practice • Succeed",11,Color.rgb(112,130,159),true);footer.setGravity(Gravity.CENTER);LinearLayout.LayoutParams fp=lp(-1,-2);fp.topMargin=dp(16);page.addView(footer,fp);
      scroll.addView(page);setContentView(scroll);
    }
    private TextView fieldLabel(String s){TextView t=text(s,14,ink,true);LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(7);t.setLayoutParams(p);return t;}
    private EditText input(String hint,String value,int type){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setTextColor(ink);e.setHintTextColor(Color.rgb(135,151,176));e.setHint(hint);e.setInputType(type);e.setText(value);e.setPadding(dp(14),0,dp(14),0);e.setBackground(shape(Color.rgb(248,251,255),14,Color.rgb(202,219,247),1));return e;}
    private void renderPhoto(){try{Bitmap b=BitmapFactory.decodeFile(new File(getFilesDir(),"sdkc_student_avatar.jpg").getAbsolutePath());if(b!=null){photo.setImageBitmap(b);return;}}catch(Exception ignored){}photo.setImageResource(android.R.drawable.ic_menu_camera);}
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r!=SELECT_PHOTO||c!=RESULT_OK||data==null)return;
       try(InputStream in=getContentResolver().openInputStream(data.getData())){
         Bitmap original=BitmapFactory.decodeStream(in);if(original==null)throw new Exception("Invalid picture");
         int max=320;float scale=Math.min(1f,(float)max/Math.max(original.getWidth(),original.getHeight()));
         Bitmap small=Bitmap.createScaledBitmap(original,Math.max(1,(int)(original.getWidth()*scale)),Math.max(1,(int)(original.getHeight()*scale)),true);
         try(FileOutputStream out=new FileOutputStream(new File(getFilesDir(),"sdkc_student_avatar.jpg"))){small.compress(Bitmap.CompressFormat.JPEG,80,out);}
         renderPhoto();
       }catch(Exception e){Toast.makeText(this,"Photo नहीं चुनी जा सकी।",Toast.LENGTH_SHORT).show();}
    }
    @Override public void onBackPressed(){if(!editing && !prefs(this).getBoolean("initialized",false))finishAffinity();else super.onBackPressed();}
    private void save(){String n=name.getText().toString().trim(),m=phone.getText().toString().trim();
      if(n.length()<2){name.setError("Please enter your name");return;}
      if(!m.matches("[0-9]{10}")){phone.setError("Enter a 10-digit mobile number");return;}
      SharedPreferences sp=prefs(this);String id=sp.getString("profile_id","");String token=sp.getString("profile_token","");
      if(id.isEmpty())id=UUID.randomUUID().toString();if(token.isEmpty())token=UUID.randomUUID().toString();
      sp.edit().putString("name",n).putString("mobile",m).putString("profile_id",id).putString("profile_token",token).putBoolean("share",true).putBoolean("initialized",true).apply();
      ProfileSync.sync(this);setResult(RESULT_OK);finish();
    }
}
