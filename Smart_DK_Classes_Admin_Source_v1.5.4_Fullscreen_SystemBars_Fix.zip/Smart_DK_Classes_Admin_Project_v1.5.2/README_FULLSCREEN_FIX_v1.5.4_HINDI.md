# Smart DK Classes Admin App v1.5.4 — Full-screen / System-bar fix

## समस्या
कुछ Android 15/16 फोन पर status bar और navigation bar Admin WebView के ऊपर आ रहे थे।

## सुधार
- WebView के बजाय outer FrameLayout पर system-bar insets लागू किए।
- Top status bar और bottom navigation area के अंदर app content नहीं जाएगा।
- Insets consume किए जाते हैं ताकि page content system bars के पीछे render न हो।
- बाकी Admin HTML/features और blue-white colorful design नहीं बदले गए।

## Build
GitHub Actions से Admin APK build करें और फोन पर जाँचें। यह source ZIP है, prebuilt APK नहीं।
