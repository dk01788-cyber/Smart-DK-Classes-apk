package com.smartdkclasses.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.provider.Settings;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.concurrent.Executor;

public class AdminActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 7101;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 91, 216));
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        // Keep system bars outside the WebView's content viewport. On Android 15+
        // targetSdk 35+ apps are edge-to-edge by default, so apply insets to a
        // dedicated root container (not the WebView itself) and consume them.
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        if (Build.VERSION.SDK_INT >= 35) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().setStatusBarColor(Color.rgb(7, 91, 216));
            getWindow().setNavigationBarColor(Color.WHITE);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return WindowInsets.CONSUMED;
            });
        } else {
            root.setFitsSystemWindows(true);
        }
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        // Admin HTML runs locally. Never silently load untrusted websites inside the
        // privileged WebView, where the Android JavaScript bridge exists.
        webView.setWebViewClient(new WebViewClient() {
            private boolean handleNavigation(String url) {
                if (url != null && url.startsWith("file:///android_asset/")) return false;
                if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
                    openSafeExternalUrl(url);
                }
                return true;
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleNavigation(request.getUrl().toString());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleNavigation(url);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String requestedType = "*/*";
                String all = "";
                if (params != null && params.getAcceptTypes() != null) {
                    StringBuilder accepts = new StringBuilder();
                    for (String accept : params.getAcceptTypes()) if (accept != null) accepts.append(accept.toLowerCase()).append(' ');
                    all = accepts.toString();
                }
                if (all.contains("pdf")) requestedType = "application/pdf";
                else if (all.contains("apk") || all.contains("android.package")) {
                    requestedType = "application/vnd.android.package-archive";
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/vnd.android.package-archive", "application/octet-stream"});
                }
                intent.setType(requestedType);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(AdminActivity.this, "File picker unavailable", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new AdminBridge(), "Android");
        webView.loadUrl("file:///android_asset/admin.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
        }
    }

    private void openSafeExternalUrl(String url) {
        try {
            Uri uri = Uri.parse(url);
            if (!"https".equalsIgnoreCase(uri.getScheme())) {
                Toast.makeText(this, "Only secure links are allowed", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            Toast.makeText(this, "Link could not be opened", Toast.LENGTH_SHORT).show();
        }
    }

    private void js(String script) {
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    public class AdminBridge {
        @JavascriptInterface public void closeAdmin() { runOnUiThread(() -> finish()); }

        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> openSafeExternalUrl(url));
        }

        @JavascriptInterface public void biometric() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    Executor executor = getMainExecutor();
                    CancellationSignal cancel = new CancellationSignal();
                    try {
                        BiometricPrompt prompt = new BiometricPrompt.Builder(AdminActivity.this)
                                .setTitle("Unlock Smart DK Classes Admin")
                                .setSubtitle("Use fingerprint / biometric")
                                .setDescription("Private admin access")
                                .setNegativeButton("Use Password", executor, (dialog, which) -> js("window.onBiometricFallback&&window.onBiometricFallback();"))
                                .build();
                        prompt.authenticate(cancel, executor, new BiometricPrompt.AuthenticationCallback() {
                            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                                super.onAuthenticationSucceeded(result);
                                js("window.onBiometricSuccess&&window.onBiometricSuccess();");
                            }
                            @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                                super.onAuthenticationError(errorCode, errString);
                                String msg = errString == null ? "Biometric authentication failed" : errString.toString().replace("'", "\\'");
                                js("window.onBiometricError&&window.onBiometricError('" + msg + "');");
                            }
                        });
                    } catch (Exception e) {
                        new AlertDialog.Builder(AdminActivity.this).setTitle("Biometric unavailable").setMessage("Use password login on this device.").setPositiveButton("OK", null).show();
                    }
                } else {
                    new AlertDialog.Builder(AdminActivity.this).setTitle("Biometric unavailable").setMessage("Use password login on this device.").setPositiveButton("OK", null).show();
                }
            });
        }

        @JavascriptInterface public void openSecuritySettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS)); }
                catch (Exception ignored) { }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
