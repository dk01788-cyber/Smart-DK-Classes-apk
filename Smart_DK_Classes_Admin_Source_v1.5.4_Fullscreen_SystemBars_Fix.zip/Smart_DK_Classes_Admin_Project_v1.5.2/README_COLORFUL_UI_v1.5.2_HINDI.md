# Smart DK Classes Admin App v1.5.2 — Colorful Redesign

इस ZIP में पूरा Android Gradle Admin Source Project है।

## बदलाव
- नया Blue Gradient header और welcome hero
- रंगीन Dashboard management cards, quick access और नीचे पाँच navigation tabs
- Students, Mock Tests, Analytics, Content और Settings की पुरानी कार्यप्रणाली बनी हुई है
- Existing Supabase API, admin login, biometric, upload, tests, query inbox, students analytics को नहीं बदला गया है
- Android versionName 1.5.2, versionCode 10 (पहले 9)
- किसी भी student count को नकली live आंकड़े के रूप में नहीं दिखाया गया है

## APK कैसे बनाएं
इस ZIP को GitHub के Smart-DK-Classes-apk repo root में उसी नाम से upload करें। Actions में Automatic APK and Play AAB Builder चलाएँ। Build सफल होने पर Artifacts से APK लें।

**सावधानी:** पहले से installed Admin App के ऊपर update के लिए वही signing key आवश्यक है। ZIP source है, APK नहीं। पहले Debug/Signed APK build और test करें।
