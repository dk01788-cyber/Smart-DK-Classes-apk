# SMART DK CLASSES — FINAL SOURCE UPDATE PACK | 26 October 2026

## शामिल फाइलें

- `SDKC_Public_App_Source_v1.5.0.zip` — Public Android native source, Welcome/Edit Profile, Photo, Mobile, Name*, opt-in consent; one top-right Update; website mock profile bridge.
- `SDKC_Admin_App_Source_v1.5.1.zip` — Original Admin app with new Student Analytics, Recent Students, score list and editable Mock Questions; old test/PDF/video management retained.
- `SDKC_Website_Source_v8.1.0.zip` — Website with `/app-update.html`, `/student-profile.html`, name/photo on mock results, consent-based Supabase result sync; original blue-white theme unchanged.
- `SDKC_Supabase_SQL_Update.zip` — Student opt-in/private analytics schema and independently importable mock seed SQL.
- `SDKC_60_Mock_Tests_1800_MCQs.zip` — 12 exams, 5 test sets each, 30 questions per set, original MCQs with explanations, per-set CSV and SQL import.

## पहले समझें

**यह Source ZIP है, फोन पर क्लिक से इंस्टॉल होने वाला APK नहीं।** APK बनाने के लिए Android Studio / existing GitHub Action से Android projects build करने होंगे; पुरानी Signing Key से sign करके versionCode ज्यादा रखना होगा। यहां Android APK build नहीं किया गया और live Cloudflare/ Supabase पर इन नए बदलावों को deploy नहीं किया गया।

### Public App Location

- पहली बार ऐप: `Your Name *`, `Mobile Number *` (10 अंक अनिवार्य), `Profile Photo` वैकल्पिक; checkbox नहीं, **No OTP / No Login**. Continue से पहले स्पष्ट नोटिस दिखता है कि नाम और मोबाइल Admin में सेव होंगे.
- Name के आगे केवल * चिह्न है। Mobile और Photo के आगे कोई Required/Optional शब्द या स्टार नहीं।
- Home: Welcome name + `My Profile / Edit` (नाम, मोबाइल, फोटो और consent बदले जा सकते हैं)।
- Home top-right: एकमात्र `Update` बटन। यह Android Browser में `/app-update.html` खोलेगा; ऐप APK डाउनलोड नहीं करेगा।
- Mock Test Result: नाम और लोकल प्रोफाइल फोटो; फोन नंबर Result में नहीं।

### Admin App Location

- Dashboard → `Student Analytics`: opted-in user count, joined today, last 7 days, total test attempts, test takers, average accuracy; recent profiles with individual scores.
- Dashboard → `Mock Test Manager`: 60 नए टेस्ट भी यहीं मैनेज होंगे; प्रश्न को Edit / Delete / Add / CSV Import; title, folder, time, negative marks, answer review, publish/unpublish.
- Dashboard → `Website APK`: नया signed APK upload कर Publish करें; वेबसाइट `/app-update.html` पेज वही published APK दिखाएगा।

### Website Location

- `/app-update.html` — Website से latest APK Download link.
- `/student-profile.html` — Website के लिए अलग browser-local profile; WebView में Android नाम व फोटो ब्रिज से पढ़े जाते हैं।
- `/mock-tests.html` — पुराने test/folder UI के साथ Name/Photo Result और opt-in Admin Result Sync.

## Installation / Migration Order

1. पहले Supabase Dashboard के SQL Editor में **`database/01_STUDENT_ANALYTICS_PRIVACY_SAFE.sql`** चलाएँ। इसे चलाने के बाद RLS और protected Admin read policies की जाँच करें।
2. Mock bank के **`01_IMPORT_60_MOCK_TESTS.sql`** चलाएँ। इससे पहले से मौजूद `sdkc_mock_tests`, UPTET/PET, Bank टेस्ट या अन्य फोल्डर नहीं हटेंगे/बदलेंगे। Stable UUID + `ON CONFLICT DO NOTHING` के कारण Import दोहराने पर डुप्लीकेट नहीं बनेंगे।
3. Website `public/` को अपने मौजूदा **Cloudflare Pages `smart-dk-classes-web`** प्रोजेक्ट में नई source version के रूप में deploy करें; पुराने project/URLs/theme को न बदलें।
4. Android Public v1.5.0 Build करें, पुरानी app Signing Key से sign करें; package name `com.smartdkclasses.app` बरकरार है। नया versionCode `26` है (पहले 25)। Android targetSdk 36.
5. Admin Android v1.5.1 Build करें; अपनी **पुरानी Admin Signing Key** से sign करें। नया Admin versionCode `9` है (पहले 8)।
6. नई Public APK Admin के Website APK सेक्शन से upload करके release version/notes publish करें। `/app-update.html` नया link दिखाएगा। पुरानी Public App v1.4.9 तक के users को नया native Welcome/Update पाने के लिए कम-से-कम एक बार नया APK इंस्टॉल करना पड़ेगा।
7. Test करें: first open → Name* → Continue → Home Name → edit photo/mobile → Mock Test 2-3 प्रश्न → Result में Name/Photo → optional consent → Admin Analytics after Refresh.

## विशेष ध्यान: सुरक्षा एवं सहमति

- नाम, 10 अंक का optional मोबाइल और फोटो **local phone storage** में हैं; मोबाइल और फोटो **कभी Admin/Supabase पर नहीं भेजे जाते**।
- Student checkbox के माध्यम से अलग opt-in देने पर केवल नाम + random pseudonymous profile ID + सर्वर पर जाँचे गए score/attempt data Supabase में जाते हैं। Consent हटाने पर linked server profile/attempts हटाने का अनुरोध होता है।
- Admin द्वारा दिखाई जाने वाली गिनती **consent देने वाले profiles** की है। यह सत्यापित अलग-अलग व्यक्ति या वास्तविक APK install count नहीं है। वास्तविक installations के लिए अलग approved analytics system चाहिए।
- Mobile OTP नहीं है; नाम/डिवाइस पहचान सत्यापित नहीं है। इसे official attendance/qualification/identity proof न समझें।
- नाबालिगों का डेटा एकत्रित करने से पहले लागू नियमों के अनुसार आवश्यक अभिभावकीय सहमति/गोपनीयता नोटिस/सुरक्षा लागू करें। नया opt-in checkbox अपने आप सभी legal compliance पूरा नहीं करता।
- Public RPC endpoints को बड़े पैमाने पर खोलने से पहले rate-limits और abuse protection (उदाहरण Cloudflare) जोड़ें; same device false registrations और unsolicited submissions संभव हैं।
- इस कोड पैक को लोकल/स्टेजिंग पर पहले Build + QA करना जरूरी है।

## नए Exams (सभी 5 सेट × 30 MCQ)

1. Agniveer Army CEE
2. BSF Constable / Tradesman
3. Railway → RRB NTPC
4. Railway → RRB Group D
5. Railway → Station Master
6. SSC CGL
7. SSC CHSL
8. SSC GD Constable
9. UP Police Constable
10. UP Police SI
11. CTET
12. UPSC NDA

**प्रश्न स्वरचित Quant/Reasoning + कुछ संबंधित General Awareness/Subject Concept practice MCQ हैं।** वास्तविक भर्ती का पूर्ण सिलेबस, मौजूदा आधिकारिक पैटर्न, Previous Year Exam questions, या Station Master CBAT की वास्तविक मनोवैज्ञानिक परीक्षा होने का दावा नहीं किया गया है। प्रकाशित करने से पहले विषयवार शैक्षणिक समीक्षा करें।

## README STATUS

- Source prepared: YES
- JS syntax checked: YES
- CSV unique 1800 questions, answers/explanations checked structurally: YES
- Android APK compiled here: NO (Android SDK/Gradle unavailable)
- Live Supabase updated: NO — SQL supplied only
- Live Cloudflare website deployed: NO — source supplied only
- 60 test sets live/published: NO — SQL import pending
