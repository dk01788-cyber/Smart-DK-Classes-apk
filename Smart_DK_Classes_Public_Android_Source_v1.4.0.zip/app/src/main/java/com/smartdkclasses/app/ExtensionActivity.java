package com.smartdkclasses.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.net.Uri;
import android.content.Intent;

/** Dedicated online learning modules. Main public app remains native Android. */
public class ExtensionActivity extends Activity {
    private static final String HOST = "smart-dk-classes-web.pages.dev";
    private WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,91,216));
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri=req.getUrl();
                if("https".equalsIgnoreCase(uri.getScheme()) && HOST.equalsIgnoreCase(uri.getHost()))return false;
                // External links (PDF / YouTube) go to Android's normal trusted browser chooser.
                if("https".equalsIgnoreCase(uri.getScheme())) {
                  startActivity(new Intent(Intent.ACTION_VIEW,uri));
                }
                return true;
            }
        });
        setContentView(web);
        String page=getIntent().getStringExtra("page");
        if(page==null || !page.matches("^(mock-tests|direct)(\\.html)?(\\?folder=[0-9a-fA-F-]{36})?$"))page="mock-tests.html";
        if(!page.contains(".html"))page=page.replace("?", ".html?")+ (page.contains("?")?"":".html");
        web.loadUrl("https://"+HOST+"/"+page);
    }
    @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
