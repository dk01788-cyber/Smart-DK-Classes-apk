# Smart DK Classes — Indus Re-submission Source (v1.1.1)

This source is the corrected Android project prepared after the Indus Appstore rejection that described the earlier build as a website converted into an app.

## Main architecture change
- The public/student experience is now native Android Java UI in `MainActivity.java`.
- The previous full-app WebView shell has been removed.
- Only the protected Admin Panel uses a local WebView (`admin.html`) because it is an internal management interface, not the public app experience.

## Public app features
- Native Home screen and locked blue-white Smart DK Classes branding.
- Classes 9, 10, 11, 12 and subject navigation.
- Native global search over published app content.
- Native PDFs/Notes, Model Papers and Question Papers lists.
- PDF **Open**: opens online PDF directly in the in-app Android PDF viewer.
- PDF **Download**: saves an offline copy in app-private storage.
- **My Downloads** screen: open/delete downloaded PDFs without requiring external storage permission.
- Native Videos list with YouTube links.
- Native Vacancy Updates list.
- Loading, empty-state, retry/error handling.
- Android back navigation handled by native screens.

## PDF security / storage
- Online PDFs are cached only while being viewed.
- Downloaded PDFs are stored under the app's private files directory (`files/pdfs`).
- No broad storage permission is requested.
- PDF viewer uses `FLAG_SECURE` to block screenshots/screen recording where Android supports it.

## Admin login — intentionally unchanged
The existing admin authentication flow remains:
- Email ID or registered mobile number
- Password
- Supabase admin-role verification (`profiles.is_admin`)
- Fingerprint/biometric unlock for a previously verified admin session
- Change Password option

The Admin Panel still supports PDF upload/link, videos, vacancies, Home visibility, App/Website/Both visibility, publish/unpublish, delete, and password change.

## Version
- applicationId: `com.smartdkclasses.app`
- versionCode: `2`
- versionName: `1.1.0`

## Important
No APK has been built as part of this source-only correction step. Build/sign the APK only after final review of the code/features.


## App ↔ Website shared admin sync
- Android Admin Panel is linked to the same Supabase `app_content` source used by the Cloudflare Pages website.
- Default publish target remains **App + Website (Both)**.
- Admin may still select **App Only**, **Website Only**, or **App + Website** per item.
- PDFs/Notes, Model Papers, Question Papers, Videos and Vacancy updates published as `both` are consumed by both products.
- Admin Dashboard now includes **App + Website Sync** status, **Check Sync**, and **Open Website**.
- Website target configured for the existing Cloudflare Pages deployment: `https://smart-dk-classes-web.pages.dev`.
- Login process is unchanged.

## v1.1.3 YouTube section update
- Videos tab stays inside the app and shows up to 4 latest Smart DK Classes channel videos.
- Home Latest Videos also shows up to 4 latest channel videos.
- Full channel opens only through the More Videos link/button.
- Individual Watch buttons open the selected video.


## v1.1.4 Portrait + Landscape support
- Removed the portrait-only lock from Main, PDF Viewer, Downloads and Admin activities.
- The app now follows the device orientation and works in both portrait and landscape when Auto-rotate is enabled.
- Existing native layouts remain scrollable/responsive in landscape.
- PDF pages are recalculated and fit to the available viewer area after rotation, while pinch-to-zoom remains available.
- Admin login, App/Website sync, PDF download behavior and YouTube section are unchanged.
- versionCode: 6
- versionName: 1.1.4


## v1.1.5 APK website download management
- Protected Admin Panel can upload/publish the latest APK for the public website.
- Website v5.1 reads the latest APK path/version from `site_settings`.
- Run `SUPABASE_APK_DOWNLOAD_SETUP.sql` once before first APK upload.
- versionCode: 7
- versionName: 1.1.5
