package com.smartdkclasses.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import android.graphics.pdf.PdfRenderer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class PdfActivity extends Activity {
    private static final int BLUE = Color.rgb(7, 91, 216);

    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private PdfRenderer.Page currentPage;
    private Bitmap currentBitmap;
    private PdfZoomImageView imageView;
    private TextView statusView;
    private TextView pageView;
    private Button prevButton;
    private Button nextButton;
    private Button retryButton;
    private int pageIndex = 0;
    private File tempFile;
    private boolean deleteOnClose = false;
    private String sourceUrl;
    private String sourcePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(BLUE);
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        String title = getIntent().getStringExtra("title");
        sourceUrl = getIntent().getStringExtra("url");
        sourcePath = getIntent().getStringExtra("path");
        buildUi(title == null || title.trim().isEmpty() ? "PDF Viewer" : title);

        if (sourcePath != null && !sourcePath.trim().isEmpty()) {
            openLocal(new File(sourcePath));
        } else if (sourceUrl != null && !sourceUrl.trim().isEmpty()) {
            downloadAndOpen(sourceUrl);
        } else {
            showError("PDF link unavailable.");
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private void buildUi(String title) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(244, 247, 251));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), dp(7), dp(12), dp(7));
        header.setBackgroundColor(BLUE);

        Button back = new Button(this);
        back.setText("‹");
        back.setTextSize(28);
        back.setTextColor(Color.WHITE);
        back.setBackground(new ColorDrawable(Color.TRANSPARENT));
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(52), dp(52)));

        TextView titleView = text(title, 17, Color.WHITE);
        titleView.setMaxLines(2);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        titleView.setTypeface(null, Typeface.BOLD);
        header.addView(titleView, new LinearLayout.LayoutParams(0, dp(58), 1f));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER);
        statusRow.setPadding(dp(10), dp(4), dp(10), dp(4));
        statusView = text("Loading PDF…", 13, Color.rgb(70, 88, 110));
        statusView.setGravity(Gravity.CENTER);
        statusRow.addView(statusView, new LinearLayout.LayoutParams(0, dp(34), 1f));
        retryButton = new Button(this);
        retryButton.setText("Retry");
        retryButton.setTextSize(12);
        retryButton.setTextColor(Color.WHITE);
        retryButton.setBackground(rounded(BLUE, 9));
        retryButton.setVisibility(View.GONE);
        retryButton.setOnClickListener(v -> retryOpen());
        statusRow.addView(retryButton, new LinearLayout.LayoutParams(dp(80), dp(36)));
        root.addView(statusRow);

        // PDF page is fitted completely inside this area on first open.
        // Pinch with two fingers to zoom; drag to pan while zoomed.
        imageView = new PdfZoomImageView(this);
        imageView.setBackgroundColor(Color.rgb(229, 234, 240));
        imageView.setPadding(dp(6), dp(6), dp(6), dp(6));
        root.addView(imageView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(dp(10), dp(5), dp(10), dp(8));
        controls.setBackgroundColor(Color.WHITE);

        prevButton = new Button(this);
        prevButton.setText("‹ Previous");
        prevButton.setEnabled(false);
        prevButton.setOnClickListener(v -> showPage(pageIndex - 1));
        controls.addView(prevButton, new LinearLayout.LayoutParams(0, dp(48), 1f));

        pageView = text("—", 14, Color.rgb(25, 50, 80));
        pageView.setGravity(Gravity.CENTER);
        pageView.setTypeface(null, Typeface.BOLD);
        controls.addView(pageView, new LinearLayout.LayoutParams(dp(95), dp(48)));

        nextButton = new Button(this);
        nextButton.setText("Next ›");
        nextButton.setEnabled(false);
        nextButton.setOnClickListener(v -> showPage(pageIndex + 1));
        controls.addView(nextButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(controls);

        setContentView(root);
    }

    private void retryOpen() {
        retryButton.setVisibility(View.GONE);
        statusView.setText("Loading PDF…");
        closeRenderer();
        if (sourcePath != null && !sourcePath.trim().isEmpty()) openLocal(new File(sourcePath));
        else if (sourceUrl != null && !sourceUrl.trim().isEmpty()) downloadAndOpen(sourceUrl);
    }

    private void openLocal(File file) {
        try {
            if (!file.exists() || file.length() == 0) throw new Exception("File not found");
            tempFile = file;
            deleteOnClose = false;
            descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(descriptor);
            if (renderer.getPageCount() <= 0) throw new Exception("Empty PDF");
            statusView.setText("");
            retryButton.setVisibility(View.GONE);
            showPage(0);
        } catch (Exception e) {
            showError("Saved PDF could not be opened.");
        }
    }

    private void downloadAndOpen(String pdfUrl) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL u = new URL(pdfUrl);
                conn = (HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(45000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("Accept", "application/pdf,*/*");
                conn.connect();
                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);

                tempFile = new File(getCacheDir(), "viewer_" + System.currentTimeMillis() + ".pdf");
                deleteOnClose = true;
                try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(tempFile)) {
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }

                descriptor = ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY);
                renderer = new PdfRenderer(descriptor);
                if (renderer.getPageCount() <= 0) throw new Exception("Empty PDF");
                runOnUiThread(() -> {
                    statusView.setText("");
                    retryButton.setVisibility(View.GONE);
                    showPage(0);
                });
            } catch (Exception e) {
                runOnUiThread(() -> showError("PDF open नहीं हो पाया। Internet check करके Retry करें."));
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private void showError(String text) {
        statusView.setText(text);
        retryButton.setVisibility(View.VISIBLE);
        Toast.makeText(this, "PDF could not be opened", Toast.LENGTH_SHORT).show();
    }

    private void showPage(int index) {
        if (renderer == null || index < 0 || index >= renderer.getPageCount()) return;
        try {
            if (currentPage != null) {
                currentPage.close();
                currentPage = null;
            }
            if (currentBitmap != null) {
                currentBitmap.recycle();
                currentBitmap = null;
            }

            pageIndex = index;
            currentPage = renderer.openPage(index);

            // Render at a higher resolution for clean pinch zoom, then FIT the entire page
            // to the available viewer area. The bitmap itself is never displayed at raw size.
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            int targetWidth = Math.max(1200, Math.min(2200, Math.round(screenWidth * 2f)));
            float ratio = (float) currentPage.getHeight() / (float) currentPage.getWidth();
            int targetHeight = Math.max(1, Math.round(targetWidth * ratio));
            currentBitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
            currentBitmap.eraseColor(Color.WHITE);
            currentPage.render(currentBitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);

            imageView.setPdfBitmap(currentBitmap);
            pageView.setText((pageIndex + 1) + " / " + renderer.getPageCount());
            prevButton.setEnabled(pageIndex > 0);
            nextButton.setEnabled(pageIndex < renderer.getPageCount() - 1);
        } catch (OutOfMemoryError e) {
            Toast.makeText(this, "PDF page is too large to render", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Page could not be rendered", Toast.LENGTH_SHORT).show();
        }
    }

    private void closeRenderer() {
        try { if (currentPage != null) currentPage.close(); } catch (Exception ignored) {}
        currentPage = null;
        try { if (renderer != null) renderer.close(); } catch (Exception ignored) {}
        renderer = null;
        try { if (descriptor != null) descriptor.close(); } catch (Exception ignored) {}
        descriptor = null;
        if (currentBitmap != null) {
            currentBitmap.recycle();
            currentBitmap = null;
        }
        if (deleteOnClose && tempFile != null && tempFile.exists()) tempFile.delete();
        tempFile = null;
    }

    @Override
    protected void onDestroy() {
        closeRenderer();
        super.onDestroy();
    }

    /**
     * Lightweight PDF page ImageView with:
     *  - initial full-page fit (no left/right cropping)
     *  - two-finger pinch zoom
     *  - drag/pan when zoomed
     *  - automatic bounds clamping so the page cannot be lost off-screen
     */
    private static class PdfZoomImageView extends ImageView {
        private final Matrix drawMatrix = new Matrix();
        private final ScaleGestureDetector scaleDetector;
        private float userScale = 1f;
        private float lastX;
        private float lastY;
        private boolean dragging;

        PdfZoomImageView(Context context) {
            super(context);
            setScaleType(ScaleType.MATRIX);
            setClickable(true);
            scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector detector) {
                    if (getDrawable() == null) return false;
                    float requested = detector.getScaleFactor();
                    float newScale = userScale * requested;
                    if (newScale < 1f) requested = 1f / userScale;
                    if (newScale > 5f) requested = 5f / userScale;
                    userScale *= requested;
                    drawMatrix.postScale(requested, requested, detector.getFocusX(), detector.getFocusY());
                    clampToBounds();
                    setImageMatrix(drawMatrix);
                    return true;
                }
            });
        }

        void setPdfBitmap(Bitmap bitmap) {
            setImageBitmap(bitmap);
            userScale = 1f;
            post(this::fitWholePage);
        }

        private void fitWholePage() {
            if (getDrawable() == null || getWidth() <= 0 || getHeight() <= 0) return;

            float drawableW = getDrawable().getIntrinsicWidth();
            float drawableH = getDrawable().getIntrinsicHeight();
            if (drawableW <= 0 || drawableH <= 0) return;

            float left = getPaddingLeft();
            float top = getPaddingTop();
            float availableW = Math.max(1f, getWidth() - getPaddingLeft() - getPaddingRight());
            float availableH = Math.max(1f, getHeight() - getPaddingTop() - getPaddingBottom());

            // FIT_CENTER behavior: both width and height stay fully visible.
            float baseScale = Math.min(availableW / drawableW, availableH / drawableH);
            float scaledW = drawableW * baseScale;
            float scaledH = drawableH * baseScale;

            float dx = left + (availableW - scaledW) / 2f;
            float dy = top + (availableH - scaledH) / 2f;

            drawMatrix.reset();
            drawMatrix.postScale(baseScale, baseScale);
            drawMatrix.postTranslate(dx, dy);
            userScale = 1f;
            setImageMatrix(drawMatrix);
        }

        private void clampToBounds() {
            if (getDrawable() == null) return;

            RectF rect = new RectF(0, 0, getDrawable().getIntrinsicWidth(), getDrawable().getIntrinsicHeight());
            drawMatrix.mapRect(rect);

            float minLeft = getPaddingLeft();
            float minTop = getPaddingTop();
            float maxRight = getWidth() - getPaddingRight();
            float maxBottom = getHeight() - getPaddingBottom();
            float areaW = maxRight - minLeft;
            float areaH = maxBottom - minTop;

            float dx = 0f;
            float dy = 0f;

            if (rect.width() <= areaW) {
                dx = minLeft + areaW / 2f - rect.centerX();
            } else if (rect.left > minLeft) {
                dx = minLeft - rect.left;
            } else if (rect.right < maxRight) {
                dx = maxRight - rect.right;
            }

            if (rect.height() <= areaH) {
                dy = minTop + areaH / 2f - rect.centerY();
            } else if (rect.top > minTop) {
                dy = minTop - rect.top;
            } else if (rect.bottom < maxBottom) {
                dy = maxBottom - rect.bottom;
            }

            drawMatrix.postTranslate(dx, dy);
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            if (getDrawable() != null && (oldw == 0 || oldh == 0)) post(this::fitWholePage);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lastX = event.getX();
                    lastY = event.getY();
                    dragging = true;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    break;

                case MotionEvent.ACTION_MOVE:
                    if (!scaleDetector.isInProgress() && dragging && event.getPointerCount() == 1 && userScale > 1f) {
                        float x = event.getX();
                        float y = event.getY();
                        drawMatrix.postTranslate(x - lastX, y - lastY);
                        clampToBounds();
                        setImageMatrix(drawMatrix);
                        lastX = x;
                        lastY = y;
                    }
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    performClick();
                    break;

                case MotionEvent.ACTION_POINTER_UP:
                    lastX = event.getX(0);
                    lastY = event.getY(0);
                    break;
            }
            return true;
        }

        @Override
        public boolean performClick() {
            super.performClick();
            return true;
        }
    }
}
