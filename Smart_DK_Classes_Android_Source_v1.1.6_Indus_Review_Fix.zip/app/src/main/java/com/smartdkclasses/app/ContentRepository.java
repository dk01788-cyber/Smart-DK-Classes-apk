package com.smartdkclasses.app;

import android.net.Uri;
import android.util.Xml;

import org.json.JSONArray;
import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class ContentRepository {
    public static final String SUPABASE_URL = "https://pmayishujtcwsvzedzwe.supabase.co";
    public static final String SUPABASE_KEY = "sb_publishable_L9CjjODFruFmi6-lFYx4Tw_md1JdMLU";

    private ContentRepository() {}

    public static List<ContentItem> fetchPublishedAppContent() throws Exception {
        String endpoint = SUPABASE_URL
                + "/rest/v1/app_content?select=*&is_published=eq.true"
                + "&display_target=in.(app,both)&order=sort_order.desc,created_at.desc";
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(endpoint).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("apikey", SUPABASE_KEY);
            conn.setRequestProperty("Accept", "application/json");
            int code = conn.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            String body = readAll(stream);
            if (code < 200 || code >= 300) {
                throw new Exception("Content server error (" + code + ")");
            }
            JSONArray arr = new JSONArray(body);
            List<ContentItem> items = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                items.add(ContentItem.fromJson(arr.getJSONObject(i)));
            }
            return items;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    public static List<ContentItem> fetchLatestYouTubeVideos(int limit) throws Exception {
        final String channelId = "UCxaVDJ6NSpm_jQFPA_uJMjQ";
        final String endpoint = "https://www.youtube.com/feeds/videos.xml?channel_id=" + channelId;
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(endpoint).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("Accept", "application/atom+xml,application/xml,text/xml,*/*");
            conn.setRequestProperty("User-Agent", "SmartDKClasses/1.1");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) {
                throw new Exception("YouTube feed error (" + code + ")");
            }

            List<ContentItem> videos = new ArrayList<>();
            try (InputStream stream = conn.getInputStream()) {
                XmlPullParser parser = Xml.newPullParser();
                parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
                parser.setInput(stream, "UTF-8");

                boolean inEntry = false;
                String title = "";
                String videoId = "";
                int event = parser.getEventType();
                while (event != XmlPullParser.END_DOCUMENT && videos.size() < Math.max(1, limit)) {
                    if (event == XmlPullParser.START_TAG) {
                        String name = parser.getName();
                        if ("entry".equals(name)) {
                            inEntry = true;
                            title = "";
                            videoId = "";
                        } else if (inEntry && "title".equals(name)) {
                            title = parser.nextText();
                        } else if (inEntry && "videoId".equals(name)) {
                            videoId = parser.nextText();
                        }
                    } else if (event == XmlPullParser.END_TAG && "entry".equals(parser.getName())) {
                        if (inEntry && videoId != null && !videoId.trim().isEmpty()) {
                            ContentItem item = new ContentItem();
                            item.id = "youtube:" + videoId.trim();
                            item.contentType = "video";
                            item.title = title == null || title.trim().isEmpty() ? "Smart DK Classes Video" : title.trim();
                            item.description = "Latest video from Smart DK Classes";
                            item.youtubeUrl = "https://www.youtube.com/watch?v=" + videoId.trim();
                            item.externalUrl = item.youtubeUrl;
                            item.showOnHome = true;
                            videos.add(item);
                        }
                        inEntry = false;
                    }
                    event = parser.next();
                }
            }
            return videos;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    public static String resolveContentUrl(ContentItem item) {
        if (item == null) return "";
        if (item.filePath != null && !item.filePath.trim().isEmpty()) {
            if (item.filePath.startsWith("http://") || item.filePath.startsWith("https://")) {
                return item.filePath;
            }
            String[] parts = item.filePath.split("/");
            StringBuilder encoded = new StringBuilder();
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) encoded.append('/');
                encoded.append(Uri.encode(parts[i]));
            }
            return SUPABASE_URL + "/storage/v1/object/public/public-content/" + encoded;
        }
        return item.externalUrl == null ? "" : item.externalUrl;
    }
}
