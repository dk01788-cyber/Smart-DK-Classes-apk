package com.smartdkclasses.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

public class DownloadsActivity extends Activity {
    private static final int BLUE = Color.rgb(7, 91, 216);
    private static final int BG = Color.rgb(244, 248, 253);
    private static final int TEXT = Color.rgb(16, 35, 63);
    private static final int MUTED = Color.rgb(103, 123, 146);
    private static final int BORDER = Color.rgb(222, 233, 244);

    private LinearLayout list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BLUE);
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        buildUi();
        renderDownloads();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (list != null) renderDownloads();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), dp(8), dp(14), dp(8));
        header.setBackgroundColor(BLUE);

        Button back = button("‹", Color.TRANSPARENT, Color.WHITE);
        back.setTextSize(28);
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(52), dp(52)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(tv("My Downloads", 19, Color.WHITE, true));
        titles.addView(tv("PDFs saved privately inside Smart DK Classes", 11, Color.rgb(225, 239, 255), false));
        header.addView(titles, new LinearLayout.LayoutParams(0, dp(52), 1f));
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(6), 0, dp(18));
        scroll.addView(list, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private void renderDownloads() {
        list.removeAllViews();
        File dir = new File(getFilesDir(), "pdfs");
        File[] files = dir.listFiles((d, name) -> name.toLowerCase(Locale.ROOT).endsWith(".pdf"));
        if (files == null || files.length == 0) {
            addEmpty("No downloaded PDF yet. Use the Download button on any PDF to keep it here for offline reading.");
            return;
        }
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        for (File file : files) list.addView(downloadRow(file));
    }

    private View downloadRow(File file) {
        LinearLayout row = card();
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView icon = tv("📄", 24, BLUE, true);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(56)));

        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setPadding(dp(6), 0, dp(6), 0);
        TextView title = tv(displayName(file.getName()), 14, TEXT, true);
        title.setMaxLines(2);
        words.addView(title);
        String size = formatBytes(file.length());
        String date = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(new Date(file.lastModified()));
        words.addView(tv(size + " • " + date, 11, MUTED, false));
        row.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        Button open = button("Open", Color.rgb(232, 244, 255), BLUE);
        open.setOnClickListener(v -> {
            Intent i = new Intent(this, PdfActivity.class);
            i.putExtra("path", file.getAbsolutePath());
            i.putExtra("title", displayName(file.getName()));
            startActivity(i);
        });
        actions.addView(open, new LinearLayout.LayoutParams(dp(78), dp(38)));
        View gap = new View(this);
        actions.addView(gap, new LinearLayout.LayoutParams(1, dp(5)));
        Button delete = button("Delete", Color.rgb(255, 238, 241), Color.rgb(194, 44, 70));
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Delete PDF?")
                .setMessage("This removes the offline copy from Smart DK Classes.")
                .setPositiveButton("Delete", (d, which) -> {
                    if (file.delete()) {
                        Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                        renderDownloads();
                    } else {
                        Toast.makeText(this, "Could not delete file", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show());
        actions.addView(delete, new LinearLayout.LayoutParams(dp(78), dp(38)));
        row.addView(actions);
        return row;
    }

    private String displayName(String name) {
        int sep = name.indexOf("__");
        String value = sep >= 0 ? name.substring(sep + 2) : name;
        if (value.toLowerCase(Locale.ROOT).endsWith(".pdf")) value = value.substring(0, value.length() - 4);
        return value;
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024d;
        if (kb < 1024) return String.format(Locale.getDefault(), "%.1f KB", kb);
        return String.format(Locale.getDefault(), "%.1f MB", kb / 1024d);
    }

    private void addEmpty(String message) {
        LinearLayout box = card();
        TextView t = tv(message, 13, MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(22), dp(14), dp(22));
        box.addView(t);
        list.addView(box);
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setBackground(round(Color.WHITE, 14, BORDER, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(14), dp(8), dp(14), 0);
        box.setLayoutParams(lp);
        box.setElevation(dp(2));
        return box;
    }

    private Button button(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(fg);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(round(bg, 10, 0, 0));
        return b;
    }

    private TextView tv(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int fill, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
