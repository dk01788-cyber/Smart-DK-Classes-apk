/* Admin-only protected views and aggregate reporting. Never displays local phone/photo. */
async function sdkcLoadStudentAnalytics(){
 const el=extGet('sdkcStudentAnalyticsMsg');if(!el)return;
 el.textContent='Loading...';
 try{
  await ensureAdmin();
  const [metrics,students]=await Promise.all([
   api('/rest/v1/rpc/sdkc_admin_student_overview',{method:'POST',headers:authHeaders(true),body:'{}'}),
   api('/rest/v1/sdkc_student_profiles?select=id,display_name,created_at,updated_at&order=created_at.desc&limit=100',{headers:authHeaders(false)})
  ]);
  const values=[['Registered Profiles',metrics.profiles],['Joined Today',metrics.joined_today],['Last 7 Days',metrics.joined_week],['Mock Attempts',metrics.attempts],['Test Takers',metrics.test_takers],['Avg Accuracy',String(metrics.average_accuracy||0)+'%']];
  extGet('sdkcStudentMetrics').innerHTML=values.map(([k,v])=>`<div class="card" style="margin:0;padding:10px"><div class="muted">${extEsc(k)}</div><h2>${extEsc(v)}</h2></div>`).join('');
  extGet('sdkcStudentNames').innerHTML=(students||[]).map(s=>`<div class="structure-row"><b>${extEsc(s.display_name)}</b><div class="muted">${extEsc(new Date(s.created_at).toLocaleString('en-IN'))}</div><button class="btn ghost" onclick="sdkcStudentAttempts('${s.id}')">View Results</button></div>`).join('')||'<div class="notice">No consenting profiles yet.</div>';
  el.textContent='✓ Profiles shown only for students who opted in.';
 }catch(e){el.textContent='Could not load: '+e.message;el.classList.add('danger');}
}
async function sdkcStudentAttempts(studentId){
 const box=extGet('sdkcStudentResults');box.textContent='Loading...';
 try{await ensureAdmin();
  if(!/^[0-9a-f-]{36}$/i.test(studentId))throw Error('Invalid student ID');
  const rows=await api('/rest/v1/sdkc_mock_attempts?select=id,test_id,total,attempted,correct,wrong,unattempted,score,max_score,accuracy,submitted_at,sdkc_mock_tests(title)&student_id=eq.'+encodeURIComponent(studentId)+'&order=submitted_at.desc&limit=100',{headers:authHeaders(false)});
  box.innerHTML=(rows||[]).map(r=>`<div class="structure-row"><b>${extEsc(r.sdkc_mock_tests?.title||r.test_id)}</b><div class="muted">${extEsc(new Date(r.submitted_at).toLocaleString('en-IN'))}</div><div>Score ${extEsc(r.score)}/${extEsc(r.max_score)} • Accuracy ${extEsc(r.accuracy)}% • ✓ ${extEsc(r.correct)} / ✕ ${extEsc(r.wrong)} / Unanswered ${extEsc(r.unattempted)}</div></div>`).join('')||'<div class="notice">No saved attempts for this student.</div>';
  box.scrollIntoView({behavior:'smooth'});
 }catch(e){box.textContent='Error: '+e.message;}
}
