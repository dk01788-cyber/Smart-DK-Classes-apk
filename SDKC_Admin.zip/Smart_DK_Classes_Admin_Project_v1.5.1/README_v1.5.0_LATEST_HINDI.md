# Smart DK Classes — Admin Android Source v1.5.0 (23 October 2026)

## आपको क्या मिला?
यह **Android Studio / GitHub Actions से Build होने वाला Source ZIP** है। यह APK नहीं है, और इसे अभी लाइव ऐप या वेबसाइट पर Deploy नहीं किया गया है।

**Project:** SmartDKClassesAdmin  • **Package:** `com.smartdkclasses.adm`  • **versionCode:** 8  • **versionName:** 1.5.0  • **compileSdk/targetSdk:** 36  • **minimum Android:** 7.0 (API 24)

## पहले की सभी Admin सुविधाएँ सुरक्षित
- Registered email/mobile + password login, authenticated Supabase session, `profiles.is_admin` से permission जाँच; उपलब्ध होने पर fingerprint unlock with password fallback।
- Class → Subject → Category → Chapter, हर category में chapter, visible/hidden/locked card controls, card order and card design/background.
- PDF और video upload, direct folder upload, multi-PDF bulk upload, bulk move, content management and homepage-curated videos.
- Vacancy post, APK website download release management, user/admin password change.
- Mock Test hub, Exam Folders, create/draft/publish test, timer, negative marks, answer-review toggle, 2–6 option questions, marks, explanation, CSV import and question management.
- Student Query Inbox: student name, question, optional *one* contact input on website/public app; Supabase stores separately in `email`/`mobile`; Admin shows both and can resolve/reopen/delete.
- Supabase database sync to both existing website and public app.

## v1.5.0 बदलाव
1. Android targetSdk and compileSdk **36**; Android Gradle Plugin **8.10.1** (JDK 17, Gradle 8.11.1+ compatible). `versionCode` 8, `versionName` 1.5.0.
2. Dashboard में **Refresh Admin Data**: content/structure/folders और खुली Mock Test या Query List Supabase से दोबारा लोड।
3. **Edit Existing Mock Test Settings**: title, description, duration, negative marks, review toggle और folder को बिना प्रश्न मिटाए बदलें।
4. **Student Mock Test Preview** वेबसाइट पर `https://smart-dk-classes-web.pages.dev/mock-tests.html` खोलता है।
5. Dashboard और Mock Test में साफ बताया है कि Final Submit/Result के लिए वेबसाइट **v8.0.10** fix जरूरी है।
6. WebView external navigation guard: trusted bundled Admin HTML के बाहर URL सीधे privileged WebView में नहीं खुलेगा, HTTPS links external browser में खुलेंगे।
7. Android 15/16 के लिए WebView के ऊपर/नीचे safe system-bar insets दिए हैं।
8. Admin theme और बाकी व्यवहार पहले जैसे हैं।

## क्या Auto-Update होता है?
- **हाँ (Data):** नए प्रश्न, Mock Tests, class/subject/category, PDF/videos, Student Queries, shared Supabase backend से load होते हैं। Sync के लिए Admin APK हर बार बदलना नहीं पड़ेगा।
- **नहीं (Native UI):** नए Android buttons, security code, नया Admin HTML bundle, या Android permissions बदलने पर नया APK build/install करना पड़ेगा।
- पुराने public app का Final Submit website v8.0.10 deploy होने के बाद WebView पर भी ठीक हो सकता है। इस Admin source का ZIP डालने से अपने आप वेबसाइट deploy नहीं होती।
- वेबसाइट का `/admin.html` अभी public admin dashboard नहीं है (होम पर redirect करता है), इसलिए बिना सुरक्षित नया server-side admin host तैयार किए किसी remote admin UI पर login/token नहीं भेजे जाते।

## Build / Install
1. ZIP Extract करें। अंदर `Smart_DK_Classes_Admin_Project_v1.5.0` में Gradle project files हैं।
2. GitHub APK repo या Android Studio में इस **नए Admin Source ZIP** से Build करें। JDK 17, Android SDK 36, Android Gradle Plugin 8.10.1 और Gradle 8.11.1 की आवश्यकता है।
3. Android 7+ पर Install करें और registered admin email/mobile तथा password से login करें। **पुराने Admin App पर in-place update के लिए वही original signing key** इस्तेमाल करें।
4. Admin में Mock Test manager से एक test बनाएँ/खोलें, Questions और Student Query Inbox जाँचें। Final Submit के लिए वेबसाइट पर v8.0.10 का deployment अलग से जरूरी है।

## सत्यापन और सीमाएँ
Source ZIP structure, Javascript syntax, Android source guard checks और ZIP CRC validate किए जा सकते हैं। Android Gradle build, device install, signed APK या Supabase live data write इस पैकेज से स्वयं नहीं हुआ है।
कृपया वास्तविक फोन पर परीक्षण करिए, विशेषकर biometric, file picker और Android 15/16 system bar insets।
