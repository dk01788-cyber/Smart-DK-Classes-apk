# Admin App v1.4.1

Mock Test Manager > Create Exam Folder > Test Create / Bulk CSV Questions / Move Selected Test to Folder.
सभी Exam Folders Main Mock Test Card के अंदर बनते हैं; Home पर अलग Card नहीं जोड़ते।
पूर्ववर्ती PDF Upload, Existing Cards, Test Result और Review को नहीं बदला गया।
Version Code: 6. कृपया पुराने Admin APK की Signing Key से ही इस APK को Sign करें।
