# Smart DK Classes Demo v3

Changes in this build:
- Android system safe areas fixed: app content stays below status bar and above Back/Home/Recents navigation area.
- Final mirrored Smart DK Classes banner added.
- Blue-white locked theme retained.
- Admin Panel, biometric unlock, Change Password demo retained.
