package com.smartdkclasses.app;
import android.app.Activity;
import android.content.SharedPreferences;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import org.json.JSONObject;
/** Only opt-in name + pseudonymous ID; mobile/photo never uploaded. */
public final class ProfileSync {
 private ProfileSync(){}
 public static void sync(Activity a){
   SharedPreferences sp=StudentProfileActivity.prefs(a);
   String id=sp.getString("profile_id","");String token=sp.getString("profile_token","");
   boolean share=sp.getBoolean("share",false);if(id.isEmpty()||token.isEmpty())return;
   String name=sp.getString("name","");
   new Thread(()->{HttpURLConnection c=null;try{
     URL u=new URL(ContentRepository.SUPABASE_URL+"/rest/v1/rpc/sdkc_save_student_profile");
     c=(HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(10000);c.setReadTimeout(10000);
     c.setRequestProperty("apikey",ContentRepository.SUPABASE_KEY);c.setRequestProperty("Content-Type","application/json");
     JSONObject json=new JSONObject();json.put("p_id",id);json.put("p_token",token);json.put("p_name",name);json.put("p_consent",share);
     try(OutputStream o=c.getOutputStream()){o.write(json.toString().getBytes("UTF-8"));}
     c.getResponseCode();
   }catch(Exception ignored){}finally{if(c!=null)c.disconnect();}}).start();
 }
}
