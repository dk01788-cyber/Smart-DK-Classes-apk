package com.smartdkclasses.app;
import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.content.SharedPreferences;
import org.json.JSONObject;
/** Website mock test WebView receives only name/photo, opt-in ID+secret; never phone. */
public final class StudentProfileBridge {
 private final Activity activity;
 public StudentProfileBridge(Activity activity){this.activity=activity;}
 @JavascriptInterface public String getProfile(){
   SharedPreferences p=StudentProfileActivity.prefs(activity);JSONObject j=new JSONObject();
   try{j.put("name",p.getString("name",""));j.put("photo",StudentProfileActivity.currentPhoto(activity));
       j.put("share",p.getBoolean("share",false));
       if(p.getBoolean("share",false)){
         j.put("profile_id",p.getString("profile_id",""));j.put("profile_token",p.getString("profile_token",""));
       }
   }catch(Exception ignored){}
   return j.toString();
 }
}
