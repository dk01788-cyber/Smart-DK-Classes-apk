# Admin App v1.3.0 – Category-wise Chapters

अब Chapter केवल Videos category तक सीमित नहीं है।

Flow:
- App Structure -> Chapters -> Class चुनें -> Subject चुनें -> Category चुनें -> Chapter नाम डालें -> Add Chapter.
- PDF/Study Content में Category select करने के बाद उसी category के chapters dropdown में दिखेंगे।
- Video में भी Class -> Subject -> Category -> Chapter (optional) select होगा।
- Move To में destination category बदलने पर उसी category के chapters दिखेंगे।
- Chapter Edit/Hide/Show/Lock/Delete पहले की तरह उपलब्ध है।

Backend schema में अलग बदलाव की जरूरत नहीं है क्योंकि content_structure में category scope पहले से मौजूद है।
