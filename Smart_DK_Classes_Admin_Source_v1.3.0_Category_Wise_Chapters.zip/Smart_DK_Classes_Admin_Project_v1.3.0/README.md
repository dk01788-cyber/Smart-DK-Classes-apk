# Smart DK Classes Admin App v1.3.0

Private Android admin application for Smart DK Classes.

## Included
- Email/mobile + password admin login using existing Supabase Auth
- Admin-role verification using profiles.is_admin
- Fingerprint/biometric unlock of an already verified saved session
- Add PDF/study content using Class -> Subject -> Category -> Chapter -> Content
- Separate chapter-wise video publishing
- Home video selection is manual only; Shorts URLs are blocked
- Home video order control using sort_order
- Manage/edit/publish/unpublish/delete content
- App Only / Website Only / Both placement
- Custom category manager (device-local category list; category value is saved to content records)
- Vacancy updates
- Website APK upload panel (uses existing backend setup)
- Change password

Application ID: com.smartdkclasses.adm
Public student app can remain installed at the same time.

This app uses the existing Smart DK Classes Supabase project. Backend RLS policies must allow authenticated admins to write app_content and public-content storage.


## v1.2.0 Category/Structure Safety Controls
- Class, Subject, Category and Chapter: Edit, Hide/Show, Lock/Unlock, safe Delete.
- Locked structure items cannot be renamed, deleted, or have placement/order changed until unlocked.
- Add Class / Subject / Category / Chapter from dropdown-driven Structure Manager.
- Manage Content keeps Edit, Hide/Show, Move To and Delete.
- Shared Supabase backend remains the single source for the compatible public app and later website sync.


## v1.3.0 Category-wise Chapters
- Chapter is no longer limited to the Videos category.
- Admin can create a chapter inside any selected Class -> Subject -> Category.
- Add PDF/Study Content shows only chapters from the selected category.
- Add Video now uses Class -> Subject -> Category -> Chapter (optional).
- Move Content also moves to any category and any chapter belonging to that category.
- Structure Manager tab is now generic Chapters, with a required Category selector.
