package com.smartdkclasses.app;

import org.json.JSONObject;

public class StructureItem {
    public String id = "";
    public String itemType = "";
    public String name = "";
    public String className = "";
    public String subject = "";
    public String category = "";
    public String systemKey = "";
    public int sortOrder = 0;

    public static StructureItem fromJson(JSONObject o) {
        StructureItem item = new StructureItem();
        item.id = o.optString("id", "");
        item.itemType = o.optString("item_type", "");
        item.name = o.optString("name", "");
        item.className = o.optString("class_name", "");
        item.subject = o.optString("subject", "");
        item.category = o.optString("category", "");
        item.systemKey = o.optString("system_key", "");
        item.sortOrder = o.optInt("sort_order", 0);
        return item;
    }
}
