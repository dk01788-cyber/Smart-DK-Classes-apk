package com.smartdkclasses.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class VideoActivity extends Activity {
    private static final int BLUE = Color.rgb(7, 91, 216);
    private WebView webView;
    private String youtubeUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        youtubeUrl = getIntent().getStringExtra("url");
        String title = getIntent().getStringExtra("title");
        if (title == null || title.trim().isEmpty()) title = "Video Class";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), dp(6), dp(10), dp(6));
        header.setBackgroundColor(BLUE);

        Button back = new Button(this);
        back.setText("‹");
        back.setTextSize(28);
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(52), dp(52)));

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(17);
        heading.setMaxLines(2);
        header.addView(heading, new LinearLayout.LayoutParams(0, dp(58), 1f));
        root.addView(header);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.setBackgroundColor(Color.BLACK);
        root.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Button youtube = new Button(this);
        youtube.setText("View on YouTube");
        youtube.setTextColor(Color.WHITE);
        youtube.setTextSize(15);
        youtube.setAllCaps(false);
        youtube.setBackgroundColor(BLUE);
        youtube.setOnClickListener(v -> openOnYouTube());
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        buttonParams.setMargins(dp(14), dp(10), dp(14), dp(12));
        root.addView(youtube, buttonParams);

        setContentView(root);
        loadVideo();
    }

    private void loadVideo() {
        String id = extractYouTubeId(youtubeUrl);
        if (id.isEmpty()) {
            Toast.makeText(this, "Video link unavailable", Toast.LENGTH_LONG).show();
            return;
        }
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1'>"
                + "<style>html,body{margin:0;background:#000;height:100%;overflow:hidden}iframe{position:absolute;inset:0;width:100%;height:100%;border:0}</style>"
                + "</head><body><iframe src='https://www.youtube.com/embed/" + id
                + "?playsinline=1&rel=0' allow='accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture' allowfullscreen></iframe>"
                + "</body></html>";
        webView.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null);
    }

    private void openOnYouTube() {
        if (youtubeUrl == null || youtubeUrl.trim().isEmpty()) {
            Toast.makeText(this, "YouTube link unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(youtubeUrl.trim())));
        } catch (Exception e) {
            Toast.makeText(this, "Could not open YouTube", Toast.LENGTH_SHORT).show();
        }
    }

    private String extractYouTubeId(String url) {
        if (url == null) return "";
        String value = url.trim();
        try {
            Uri uri = Uri.parse(value);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
            if (host.contains("youtu.be")) {
                String path = uri.getPath();
                if (path != null && path.length() > 1) return cleanId(path.substring(1));
            }
            if (host.contains("youtube.com")) {
                String v = uri.getQueryParameter("v");
                if (v != null && !v.trim().isEmpty()) return cleanId(v);
                String path = uri.getPath() == null ? "" : uri.getPath();
                String[] prefixes = {"/shorts/", "/embed/", "/live/"};
                for (String prefix : prefixes) {
                    if (path.startsWith(prefix)) return cleanId(path.substring(prefix.length()));
                }
            }
        } catch (Exception ignored) {}
        return "";
    }

    private String cleanId(String value) {
        if (value == null) return "";
        String id = value;
        int slash = id.indexOf('/');
        if (slash >= 0) id = id.substring(0, slash);
        int q = id.indexOf('?');
        if (q >= 0) id = id.substring(0, q);
        int amp = id.indexOf('&');
        if (amp >= 0) id = id.substring(0, amp);
        return id.replaceAll("[^A-Za-z0-9_-]", "");
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
