package com.smartdkclasses.app;

import android.net.Uri;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class ContentRepository {
    public static final String SUPABASE_URL = "https://pmayishujtcwsvzedzwe.supabase.co";
    public static final String SUPABASE_KEY = "sb_publishable_L9CjjODFruFmi6-lFYx4Tw_md1JdMLU";

    private ContentRepository() {}

    public static List<ContentItem> fetchPublishedAppContent() throws Exception {
        String endpoint = SUPABASE_URL
                + "/rest/v1/app_content?select=*&is_published=eq.true"
                + "&display_target=in.(app,both)&order=sort_order.desc,created_at.desc";
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(endpoint).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("apikey", SUPABASE_KEY);
            conn.setRequestProperty("Accept", "application/json");
            int code = conn.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            String body = readAll(stream);
            if (code < 200 || code >= 300) {
                throw new Exception("Content server error (" + code + ")");
            }
            JSONArray arr = new JSONArray(body);
            List<ContentItem> items = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                items.add(ContentItem.fromJson(arr.getJSONObject(i)));
            }
            return items;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }


    public static List<StructureItem> fetchVisibleAppStructure() throws Exception {
        String endpoint = SUPABASE_URL
                + "/rest/v1/content_structure?select=*&is_visible=eq.true"
                + "&display_target=in.(app,both)&order=sort_order.asc,created_at.asc";
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(endpoint).openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("apikey", SUPABASE_KEY);
            conn.setRequestProperty("Accept", "application/json");
            int code = conn.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            String body = readAll(stream);
            if (code < 200 || code >= 300) throw new Exception("Structure server error (" + code + ")");
            JSONArray arr = new JSONArray(body);
            List<StructureItem> items = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) items.add(StructureItem.fromJson(arr.getJSONObject(i)));
            return items;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    public static String resolveContentUrl(ContentItem item) {
        if (item == null) return "";
        if (item.filePath != null && !item.filePath.trim().isEmpty()) {
            if (item.filePath.startsWith("http://") || item.filePath.startsWith("https://")) {
                return item.filePath;
            }
            String[] parts = item.filePath.split("/");
            StringBuilder encoded = new StringBuilder();
            for (int i = 0; i < parts.length; i++) {
                if (i > 0) encoded.append('/');
                encoded.append(Uri.encode(parts[i]));
            }
            return SUPABASE_URL + "/storage/v1/object/public/public-content/" + encoded;
        }
        return item.externalUrl == null ? "" : item.externalUrl;
    }
}
