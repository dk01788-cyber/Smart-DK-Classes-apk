package com.smartdkclasses.app;

import org.json.JSONObject;

import java.util.Locale;

public class ContentItem {
    public String id = "";
    public String contentType = "";
    public String title = "";
    public String className = "";
    public String subject = "";
    public String category = "";
    public String chapterName = "";
    public String description = "";
    public String filePath = "";
    public String externalUrl = "";
    public String youtubeUrl = "";
    public boolean showOnHome = false;

    public static ContentItem fromJson(JSONObject o) {
        ContentItem item = new ContentItem();
        item.id = o.optString("id", "");
        item.contentType = o.optString("content_type", "");
        item.title = o.optString("title", "Untitled");
        item.className = o.optString("class_name", "");
        item.subject = o.optString("subject", "");
        item.category = firstNonEmpty(
                o.optString("category", ""),
                o.optString("content_category", "")
        );
        item.chapterName = firstNonEmpty(
                o.optString("chapter_name", ""),
                o.optString("chapter", "")
        );
        item.description = o.optString("description", "");
        item.filePath = o.optString("file_path", "");
        item.externalUrl = o.optString("external_url", "");
        item.youtubeUrl = o.optString("youtube_url", "");
        item.showOnHome = o.optBoolean("show_on_home", false);
        return item;
    }

    private static String firstNonEmpty(String a, String b) {
        if (a != null && !a.trim().isEmpty()) return a.trim();
        return b == null ? "" : b.trim();
    }

    public boolean isPdf() {
        String t = normalizedType();
        return "pdf".equals(t)
                || "note".equals(t)
                || "handwritten_note".equals(t)
                || "model_paper".equals(t)
                || "question_paper".equals(t)
                || "question_bank".equals(t)
                || "previous_year_paper".equals(t)
                || "important_question".equals(t)
                || "formula_sheet".equals(t)
                || "revision_sheet".equals(t)
                || "practice_set".equals(t)
                || "worksheet".equals(t);
    }

    public boolean isVideo() {
        return "video".equals(normalizedType());
    }

    public boolean isVacancy() {
        return "vacancy".equals(normalizedType());
    }

    private String normalizedType() {
        return contentType == null ? "" : contentType.trim().toLowerCase(Locale.ROOT);
    }

    public String displayCategory() {
        if (category != null && !category.trim().isEmpty()) {
            return normalizeCategory(category);
        }

        String t = normalizedType();
        if (isVideo()) return "Videos";
        if ("handwritten_note".equals(t)) return "Handwritten Notes";
        if ("note".equals(t) || "pdf".equals(t)) {
            String lowerTitle = title == null ? "" : title.toLowerCase(Locale.ROOT);
            if (lowerTitle.contains("handwritten") || lowerTitle.contains("हस्तलिखित")) return "Handwritten Notes";
            if (lowerTitle.contains("formula") || lowerTitle.contains("सूत्र") || lowerTitle.contains("revision")) return "Formula / Revision Sheet";
            return "Notes";
        }
        if ("question_bank".equals(t) || "question_paper".equals(t)) return "Question Bank";
        if ("model_paper".equals(t)) return "Model Papers";
        if ("previous_year_paper".equals(t)) return "Previous Year Papers";
        if ("important_question".equals(t)) return "Important Questions";
        if ("formula_sheet".equals(t) || "revision_sheet".equals(t)) return "Formula / Revision Sheet";
        if ("practice_set".equals(t) || "worksheet".equals(t)) return "Practice Sets / Worksheets";
        return "Study Material";
    }

    public static String normalizeCategory(String value) {
        if (value == null) return "";
        String trimmed = value.trim();
        if (trimmed.isEmpty()) return "";
        String key = trimmed.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        if (key.equals("video") || key.equals("videos") || key.equals("chapter videos") || key.equals("chapter-wise videos") || key.equals("chapter wise videos")) return "Videos";
        if (key.equals("handwritten") || key.equals("handwritten note") || key.equals("handwritten notes")) return "Handwritten Notes";
        if (key.equals("note") || key.equals("notes")) return "Notes";
        if (key.equals("question bank") || key.equals("question papers") || key.equals("question paper")) return "Question Bank";
        if (key.equals("model paper") || key.equals("model papers")) return "Model Papers";
        if (key.equals("previous year paper") || key.equals("previous year papers") || key.equals("pyq") || key.equals("pyqs")) return "Previous Year Papers";
        if (key.equals("important question") || key.equals("important questions")) return "Important Questions";
        if (key.equals("formula") || key.equals("formula sheet") || key.equals("revision") || key.equals("revision sheet")) return "Formula / Revision Sheet";
        if (key.equals("practice set") || key.equals("practice sets") || key.equals("worksheet") || key.equals("worksheets")) return "Practice Sets / Worksheets";
        return trimmed;
    }

    public String searchableText() {
        return (title + " " + className + " " + subject + " " + displayCategory() + " " + chapterName + " " + description + " " + contentType).toLowerCase(Locale.ROOT);
    }

    public static String normalizeSubject(String value) {
        if (value == null) return "";
        String trimmed = value.trim();
        if (trimmed.isEmpty()) return "";
        String key = trimmed.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        if ("math".equals(key) || "maths".equals(key) || "mathematics".equals(key)) return "Mathematics";
        if ("science".equals(key)) return "Science";
        if ("physics".equals(key)) return "Physics";
        if ("chemistry".equals(key)) return "Chemistry";
        if ("biology".equals(key)) return "Biology";
        if ("english".equals(key)) return "English";
        if ("hindi".equals(key)) return "Hindi";
        if ("social science".equals(key) || "social studies".equals(key) || "sst".equals(key)) return "Social Science";
        return trimmed;
    }
}
