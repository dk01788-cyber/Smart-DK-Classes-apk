-- Smart DK Classes public app hierarchy support (v1.2.0)
-- Safe migration: existing content continues to work because both fields are optional.

alter table public.app_content
  add column if not exists category text,
  add column if not exists chapter_name text;

comment on column public.app_content.category is
  'Content category inside Class -> Subject, e.g. Handwritten Notes, Notes, Question Bank, Model Papers, Previous Year Papers, Important Questions, Formula / Revision Sheet, Practice Sets / Worksheets, Videos.';

comment on column public.app_content.chapter_name is
  'Optional chapter label, mainly used to group teaching videos chapter-wise inside a subject.';

-- No change to existing RLS is required for public reads if app_content already permits
-- published public content to be selected. The private Admin app will write these fields.
