# Smart DK Classes — Public Android App v1.2.1

This is the student/public Android app source. The Admin Panel has been intentionally removed from the public application and will be maintained as a separate private admin app.

## Final public navigation
- Home
- Classes
- Search
- Downloads

## Home
Home contains only the Smart DK Classes header, global search, the locked banner, Class 9/10/11/12 cards, and video classes manually selected by the admin through `app_content.show_on_home`.

There is no Latest PDFs section and there is no automatic YouTube RSS/channel import. Shorts therefore cannot appear automatically on Home.

## Study-content hierarchy
`Class -> Subject -> Category -> Content`

Supported/fallback category labels include:
- Handwritten Notes
- Notes
- Question Bank
- Model Papers
- Previous Year Papers
- Important Questions
- Formula / Revision Sheet
- Practice Sets / Worksheets
- Videos

The optional `category` field allows the future private Admin app to create/manage category labels without rebuilding the public app. The optional `chapter_name` field groups teaching videos chapter-wise inside a subject.

## Videos
There is no Videos item in the bottom navigation. Videos remain available through Subject -> Videos, chapter-wise lists, Home-selected video classes, and global search. YouTube teaching videos open inside the app in `VideoActivity` through an embedded YouTube player. A clear **View on YouTube** button lets the student open the same video in YouTube. Video downloading is not included.

## PDFs and downloads
PDFs open in the existing in-app PDF viewer. The student can save a PDF to app-private storage and open it later from Downloads. No broad external-storage permission is required.

## Backend
The app continues to use the existing Smart DK Classes Supabase `app_content` source and respects `display_target in (app,both)` plus `is_published = true`.

Run `SUPABASE_CONTENT_HIERARCHY_v1.2.0.sql` once when the new category/chapter controls are added to the private Admin app.

## Version
- applicationId: `com.smartdkclasses.app`
- versionCode: `10`
- versionName: `1.2.1`


## v1.2.3 Dynamic Video Chapters
Only video chapters containing published videos are visible. Empty chapter cards are hidden automatically.

## v1.3.0 Dynamic Admin Structure
Public app also reads `content_structure` so Admin can add/rename/hide Class Cards, Subjects, Categories and Video Chapters centrally. Hidden parent structure hides its content from navigation, Home and Search. Chapter cards still require at least one published video.
