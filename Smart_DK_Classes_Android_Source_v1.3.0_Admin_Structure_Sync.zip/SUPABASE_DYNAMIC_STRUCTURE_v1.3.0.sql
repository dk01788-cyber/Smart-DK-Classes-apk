-- Smart DK Classes dynamic Class / Subject / Category / Chapter structure
-- This migration has already been applied to the connected Smart DK Classes Supabase project.

alter table public.app_content add column if not exists chapter_name text;

create table if not exists public.content_structure (
  id uuid primary key default gen_random_uuid(),
  item_type text not null check (item_type in ('class','subject','category','chapter')),
  name text not null,
  class_name text,
  subject text,
  category text,
  system_key text,
  is_visible boolean not null default true,
  display_target text not null default 'both' check (display_target in ('app','website','both')),
  sort_order integer not null default 0,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists content_structure_scope_unique
on public.content_structure (item_type,coalesce(class_name,''),coalesce(subject,''),coalesce(category,''),lower(name));
create index if not exists content_structure_lookup_idx
on public.content_structure (item_type,class_name,subject,category,is_visible,sort_order);

alter table public.content_structure enable row level security;
-- Policies on the live project allow public reads of visible rows and admin-only writes.
