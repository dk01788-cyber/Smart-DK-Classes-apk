package com.smartdkclasses.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7,91,216));
        getWindow().setNavigationBarColor(Color.WHITE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AppBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void js(String script) {
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    public class AppBridge {
        @JavascriptInterface
        public void openYoutube() {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@smartdkclasses"));
            startActivity(i);
        }

        @JavascriptInterface
        public void openUrl(String url) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Link could not be opened", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface
        public void biometric() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    Executor executor = getMainExecutor();
                    CancellationSignal cancel = new CancellationSignal();
                    BiometricPrompt prompt = new BiometricPrompt.Builder(MainActivity.this)
                            .setTitle("Unlock Admin Panel")
                            .setSubtitle("Use your device fingerprint / biometric")
                            .setDescription("Smart DK Classes secure admin access")
                            .setNegativeButton("Use Password", executor, (dialog, which) -> js("window.onBiometricFallback && window.onBiometricFallback();"))
                            .build();
                    prompt.authenticate(cancel, executor, new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            super.onAuthenticationSucceeded(result);
                            js("window.onBiometricSuccess && window.onBiometricSuccess();");
                        }
                        @Override
                        public void onAuthenticationError(int errorCode, CharSequence errString) {
                            super.onAuthenticationError(errorCode, errString);
                            js("window.onBiometricError && window.onBiometricError('" + errString.toString().replace("'","\\'") + "');");
                        }
                    });
                } else {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Biometric unavailable")
                            .setMessage("This Android version does not support the demo biometric prompt. Use password fallback.")
                            .setPositiveButton("OK", null)
                            .show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
