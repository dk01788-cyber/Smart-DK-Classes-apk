# Smart DK Classes — Demo Android App

Locked blue-white theme with DK Sir photo, public student content, no student login, public PDF view/download design, YouTube link, protected Admin Panel UI, Add PDF demo, Change Password screen, and Android biometric/fingerprint unlock demo.

## Build
Java 17 + Android SDK 35 are required.

Local: `gradle assembleDebug`

GitHub Actions: push to `main` or run **Build Demo APK** manually, then download the `Smart-DK-Classes-Demo-APK` artifact.

> This is a functional offline UI demo. Admin-added PDF records are stored only in localStorage on the device. Final Supabase backend/auth/storage is not connected in this demo.
