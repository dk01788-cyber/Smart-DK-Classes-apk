package com.smartdkclasses.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.text.InputType;
import android.util.Base64;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Inline Home-page question form with optional photo attachment; public users can INSERT, never SELECT. */
public final class QueryFormView {
    public static final int PICK_QUERY_PHOTO_REQUEST = 7194;
    private static final int BLUE = Color.rgb(7, 91, 216);
    private static final int DARK = Color.rgb(16, 35, 63);
    private static final int MUTED = Color.rgb(103, 123, 146);
    private static final String PRIVACY = "https://smart-dk-classes-web.pages.dev/privacy-policy.html";
    private final Activity activity;
    private EditText nameField, contactField, questionField;
    private ImageView photoPreview;
    private TextView photoStatus;
    private Button removePhotoBtn;
    private Button sendButton;
    private String selectedPhotoDataUrl = "";
    private long lastSendElapsed = 0L;

    public QueryFormView(Activity activity) {
        this.activity = activity;
    }

    public View build() {
        LinearLayout page = new LinearLayout(activity);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(8), dp(4), dp(8), dp(16));

        TextView intro = text("पढ़ाई से जुड़ा कोई सवाल है? लिखकर या फ़ोटो भेजें। नाम और प्रश्न (या फ़ोटो) जरूरी हैं।", 13, MUTED, false);
        intro.setPadding(0, 0, 0, dp(6));
        page.addView(intro);

        nameField = field(page, "आपका नाम *", "नाम लिखें", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS, false);
        contactField = field(page, "मोबाइल नंबर या ईमेल आईडी", "मोबाइल नंबर या ईमेल आईडी लिखें", InputType.TYPE_CLASS_TEXT, false);
        questionField = field(page, "आपका प्रश्न / Description *", "अपना प्रश्न विस्तार से लिखें (या नीचे फ़ोटो चुनें)...", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES, true);

        // Optional Photo Question Section
        TextView photoLabel = text("प्रश्न की फ़ोटो (Optional)", 14, DARK, true);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, -2);
        plp.topMargin = dp(12);
        page.addView(photoLabel, plp);

        LinearLayout photoBox = new LinearLayout(activity);
        photoBox.setOrientation(LinearLayout.HORIZONTAL);
        photoBox.setGravity(Gravity.CENTER_VERTICAL);
        photoBox.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable boxBg = new GradientDrawable();
        boxBg.setColor(Color.rgb(244, 248, 255));
        boxBg.setCornerRadius(dp(12));
        boxBg.setStroke(dp(1), Color.rgb(194, 214, 247));
        photoBox.setBackground(boxBg);

        photoPreview = new ImageView(activity);
        photoPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photoPreview.setBackground(rounded(Color.WHITE));
        if (Build.VERSION.SDK_INT >= 21) photoPreview.setClipToOutline(true);
        photoPreview.setImageResource(android.R.drawable.ic_menu_camera);
        LinearLayout.LayoutParams pvLp = new LinearLayout.LayoutParams(dp(74), dp(74));
        pvLp.rightMargin = dp(10);
        photoBox.addView(photoPreview, pvLp);

        LinearLayout photoRight = new LinearLayout(activity);
        photoRight.setOrientation(LinearLayout.VERTICAL);

        photoStatus = text("किताब या कॉपी के सवाल की फ़ोटो चुनें", 12, MUTED, false);
        LinearLayout.LayoutParams psLp = new LinearLayout.LayoutParams(-1, -2);
        psLp.bottomMargin = dp(8);
        photoRight.addView(photoStatus, psLp);

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        Button pickBtn = new Button(activity);
        pickBtn.setText("📷 फ़ोटो चुनें");
        pickBtn.setAllCaps(false);
        pickBtn.setTextSize(12);
        pickBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        pickBtn.setTextColor(Color.WHITE);
        pickBtn.setBackground(roundedColor(BLUE, 10, 0, 0));
        pickBtn.setPadding(dp(10), 0, dp(10), 0);
        pickBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            activity.startActivityForResult(Intent.createChooser(i, "सवाल की फ़ोटो चुनें"), PICK_QUERY_PHOTO_REQUEST);
        });
        LinearLayout.LayoutParams pkLp = new LinearLayout.LayoutParams(0, dp(38), 1.2f);
        pkLp.rightMargin = dp(6);
        btnRow.addView(pickBtn, pkLp);

        removePhotoBtn = new Button(activity);
        removePhotoBtn.setText("हटाएँ");
        removePhotoBtn.setAllCaps(false);
        removePhotoBtn.setTextSize(12);
        removePhotoBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        removePhotoBtn.setTextColor(Color.rgb(190, 24, 54));
        removePhotoBtn.setBackground(roundedColor(Color.rgb(255, 235, 238), 10, Color.rgb(252, 165, 165), 1));
        removePhotoBtn.setPadding(dp(8), 0, dp(8), 0);
        removePhotoBtn.setVisibility(View.GONE);
        removePhotoBtn.setOnClickListener(v -> clearPhoto());
        btnRow.addView(removePhotoBtn, new LinearLayout.LayoutParams(0, dp(38), 0.8f));

        photoRight.addView(btnRow, new LinearLayout.LayoutParams(-1, -2));
        photoBox.addView(photoRight, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(-1, -2);
        pbLp.topMargin = dp(6);
        page.addView(photoBox, pbLp);

        TextView privacy = text("सवाल और फ़ोटो सीधे Admin तक जाएँगे; सार्वजनिक नहीं दिखेंगे। संपर्क के लिए चाहें तो मोबाइल नंबर या ईमेल आईडी लिखें। कृपया OTP या पासवर्ड न लिखें।", 12, MUTED, false);
        privacy.setPadding(0, dp(14), 0, dp(6));
        page.addView(privacy);

        TextView policy = text("Privacy Policy देखें ↗", 12, BLUE, true);
        policy.setPadding(0, dp(5), 0, dp(5));
        policy.setOnClickListener(v -> {
            try { activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(PRIVACY))); }
            catch (Exception ex) { Toast.makeText(activity, "Privacy Policy नहीं खुल सकी।", Toast.LENGTH_SHORT).show(); }
        });
        page.addView(policy);

        sendButton = new Button(activity);
        sendButton.setText("प्रश्न भेजें / Submit");
        sendButton.setAllCaps(false);
        sendButton.setTextColor(Color.WHITE);
        sendButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        sendButton.setBackground(rounded(BLUE));
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        buttonLp.topMargin = dp(12);
        page.addView(sendButton, buttonLp);
        sendButton.setOnClickListener(v -> submit());
        return page;
    }

    public void handlePhotoResult(int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return;
        try (InputStream in = activity.getContentResolver().openInputStream(data.getData())) {
            Bitmap original = BitmapFactory.decodeStream(in);
            if (original == null) throw new Exception("Invalid image");
            int maxDim = 800;
            float scale = Math.min(1f, (float) maxDim / Math.max(original.getWidth(), original.getHeight()));
            Bitmap scaled = Bitmap.createScaledBitmap(
                    original,
                    Math.max(1, (int) (original.getWidth() * scale)),
                    Math.max(1, (int) (original.getHeight() * scale)),
                    true);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            scaled.compress(Bitmap.CompressFormat.JPEG, 72, baos);
            byte[] bytes = baos.toByteArray();
            if (bytes.length > 220_000) {
                baos.reset();
                scaled.compress(Bitmap.CompressFormat.JPEG, 52, baos);
                bytes = baos.toByteArray();
            }
            selectedPhotoDataUrl = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
            if (photoPreview != null) photoPreview.setImageBitmap(scaled);
            if (photoStatus != null) {
                photoStatus.setText("✓ फ़ोटो चुन ली गई (" + Math.max(1, bytes.length / 1024) + " KB)");
                photoStatus.setTextColor(Color.rgb(21, 128, 61));
            }
            if (removePhotoBtn != null) removePhotoBtn.setVisibility(View.VISIBLE);
        } catch (Exception e) {
            Toast.makeText(activity, "फ़ोटो लोड नहीं हो सकी, दूसरी फ़ोटो चुनें।", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearPhoto() {
        selectedPhotoDataUrl = "";
        if (photoPreview != null) photoPreview.setImageResource(android.R.drawable.ic_menu_camera);
        if (photoStatus != null) {
            photoStatus.setText("किताब या कॉपी के सवाल की फ़ोटो चुनें");
            photoStatus.setTextColor(MUTED);
        }
        if (removePhotoBtn != null) removePhotoBtn.setVisibility(View.GONE);
    }

    private EditText field(LinearLayout page, String label, String hint, int type, boolean multiline) {
        TextView caption = text(label, 14, DARK, true);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, -2);
        labelLp.topMargin = dp(12);
        page.addView(caption, labelLp);
        EditText box = new EditText(activity);
        box.setHint(hint);
        box.setTextSize(14);
        box.setTextColor(DARK);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.setInputType(type);
        box.setBackground(rounded(Color.WHITE));
        if (multiline) { box.setMinLines(4); box.setGravity(Gravity.TOP | Gravity.START); }
        else box.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, multiline ? -2 : dp(52));
        lp.topMargin = dp(5);
        page.addView(box, lp);
        return box;
    }

    private GradientDrawable rounded(int color) {
        return roundedColor(color, 10, Color.rgb(218, 231, 245), 1);
    }

    private GradientDrawable roundedColor(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) bg.setStroke(dp(strokeDp), strokeColor);
        return bg;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(activity);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(int n) {
        return Math.round(n * activity.getResources().getDisplayMetrics().density);
    }

    private void submit() {
        final String name = nameField.getText().toString().trim().replaceAll("\\s+", " ");
        final String contact = contactField.getText().toString().trim();
        final String email = contact.contains("@") ? contact : "";
        final String mobile = contact.isEmpty() || !email.isEmpty() ? "" : contact.replaceAll("[ -]", "");
        String rawQuestion = questionField.getText().toString().trim();
        final boolean hasPhoto = selectedPhotoDataUrl != null && !selectedPhotoDataUrl.isEmpty();
        if (name.length() < 2 || name.length() > 100) { nameField.setError("नाम 2–100 अक्षर में लिखें"); nameField.requestFocus(); return; }
        if (!hasPhoto && (rawQuestion.length() < 10 || rawQuestion.length() > 3000)) {
            questionField.setError("प्रश्न 10–3000 अक्षर में लिखें या नीचे फ़ोटो चुनें");
            questionField.requestFocus();
            return;
        }
        if (hasPhoto && rawQuestion.isEmpty()) rawQuestion = "[फ़ोटो प्रश्न]";
        if (rawQuestion.length() > 3000) { questionField.setError("प्रश्न 3000 अक्षर से कम रखें"); questionField.requestFocus(); return; }
        final String question = rawQuestion;
        if (!email.isEmpty() && (email.length() > 254 || !Patterns.EMAIL_ADDRESS.matcher(email).matches())) { contactField.setError("सही ईमेल आईडी लिखें या खाली छोड़ दें"); contactField.requestFocus(); return; }
        if (!mobile.isEmpty() && !mobile.matches("\\+?[0-9]{7,15}")) { contactField.setError("सही मोबाइल नंबर लिखें या खाली छोड़ दें"); contactField.requestFocus(); return; }
        if (lastSendElapsed != 0L && SystemClock.elapsedRealtime() - lastSendElapsed < 30_000L) {
            Toast.makeText(activity, "कृपया कुछ समय बाद दोबारा प्रश्न भेजें।", Toast.LENGTH_SHORT).show(); return;
        }
        sendButton.setEnabled(false);
        sendButton.setText("भेज रहे हैं…");
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject data = new JSONObject();
                data.put("student_name", name);
                data.put("email", email.isEmpty() ? JSONObject.NULL : email);
                data.put("mobile", mobile.isEmpty() ? JSONObject.NULL : mobile);
                data.put("question", question);
                data.put("question_image", hasPhoto ? selectedPhotoDataUrl : JSONObject.NULL);
                conn = (HttpURLConnection) new URL(ContentRepository.SUPABASE_URL + "/rest/v1/sdkc_student_queries").openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(25000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Prefer", "return=minimal");
                conn.setRequestProperty("apikey", ContentRepository.SUPABASE_KEY);
                try (OutputStream output = conn.getOutputStream()) {
                    output.write(data.toString().getBytes(StandardCharsets.UTF_8));
                }
                int status = conn.getResponseCode();
                if (status != 200 && status != 201 && status != 204) throw new Exception("HTTP " + status);
                activity.runOnUiThread(() -> {
                    lastSendElapsed = SystemClock.elapsedRealtime();
                    questionField.setText("");
                    clearPhoto();
                    sendButton.setEnabled(true);
                    sendButton.setText("प्रश्न भेजें / Submit");
                    new AlertDialog.Builder(activity).setTitle("प्रश्न भेज दिया गया ✅")
                            .setMessage("आपका प्रश्न Admin तक पहुँच गया। धन्यवाद!")
                            .setPositiveButton("ठीक है", null).show();
                });
            } catch (Exception e) {
                activity.runOnUiThread(() -> {
                    sendButton.setEnabled(true);
                    sendButton.setText("प्रश्न भेजें / Submit");
                    new AlertDialog.Builder(activity).setTitle("प्रश्न नहीं भेजा जा सका")
                            .setMessage("कृपया इंटरनेट जाँचें और दोबारा कोशिश करें।")
                            .setPositiveButton("ठीक है", null).show();
                });
            } finally { if (conn != null) conn.disconnect(); }
        }).start();
    }
}
