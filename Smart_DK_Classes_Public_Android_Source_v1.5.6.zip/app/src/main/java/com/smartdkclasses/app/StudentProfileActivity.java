package com.smartdkclasses.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Modern Design V2 student profile form with 6 course options. */
public final class StudentProfileActivity extends Activity {
    public static final String PREF = "sdkc_student_profile_v1";
    public static final String[] COURSES = {
            "Class 9", "Class 10",
            "Class 11", "Class 12",
            "Competitive Exams", "All Courses"
    };
    private static final int SELECT_PHOTO = 7001;

    private final int blue = Color.rgb(7, 91, 216);
    private final int deepIndigo = Color.rgb(15, 36, 118);
    private final int navy = Color.rgb(14, 43, 110);
    private final int ink = Color.rgb(24, 47, 83);
    private final int muted = Color.rgb(93, 112, 145);

    private EditText name, phone;
    private ImageView photo;
    private boolean editing;
    private String selectedCourse = "All Courses";
    private final List<Button> courseButtons = new ArrayList<>();

    public static SharedPreferences prefs(Activity a) {
        return a.getSharedPreferences(PREF, MODE_PRIVATE);
    }

    public static String currentName(Activity a) {
        return prefs(a).getString("name", "");
    }

    public static String currentCourse(Activity a) {
        String c = prefs(a).getString("course", "All Courses");
        return (c == null || c.trim().isEmpty()) ? "All Courses" : c.trim();
    }

    public static void setCourse(Activity a, String course) {
        if (course == null || course.trim().isEmpty()) return;
        prefs(a).edit().putString("course", course.trim()).apply();
    }

    public static String currentPhoto(Activity a) {
        try {
            File f = new File(a.getFilesDir(), "sdkc_student_avatar.jpg");
            if (!f.exists()) return "";
            try (InputStream in = new java.io.FileInputStream(f)) {
                byte[] buff = new byte[(int) Math.min(f.length(), 100000)];
                int pos = 0, n;
                while (pos < buff.length && (n = in.read(buff, pos, buff.length - pos)) > 0) pos += n;
                return "data:image/jpeg;base64," + Base64.encodeToString(buff, 0, pos, Base64.NO_WRAP);
            }
        } catch (Exception ex) {
            return "";
        }
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(10, 28, 96));
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        editing = getIntent().getBooleanExtra("edit", false);
        selectedCourse = currentCourse(this);
        draw();
    }

    private int dp(float n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable shape(int color, int radius, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private GradientDrawable hGradient(int c1, int c2, int radius) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }

    private void draw() {
        SharedPreferences sp = prefs(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(238, 244, 255));

        FrameLayout root = new FrameLayout(this);

        View heroBg = new View(this);
        GradientDrawable heroGrad = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{deepIndigo, Color.rgb(24, 119, 242)});
        float r = dp(28);
        heroGrad.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        heroBg.setBackground(heroGrad);
        root.addView(heroBg, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(228)));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(12), dp(16), dp(26));

        TextView topTag = text("CLASSES 9 - 12  •  COMPETITIVE EXAMS", 11, Color.rgb(14, 30, 80), true);
        topTag.setGravity(Gravity.CENTER);
        topTag.setPadding(dp(16), dp(5), dp(16), dp(5));
        topTag.setBackground(shape(Color.rgb(255, 204, 0), 16, 0, 0));
        LinearLayout.LayoutParams tagLp = lp(-2, -2);
        tagLp.gravity = Gravity.CENTER_HORIZONTAL;
        tagLp.bottomMargin = dp(10);
        page.addView(topTag, tagLp);

        FrameLayout bannerWrap = new FrameLayout(this);
        bannerWrap.setPadding(dp(3), dp(3), dp(3), dp(3));
        bannerWrap.setBackground(shape(Color.WHITE, 20, Color.WHITE, 0));
        if (Build.VERSION.SDK_INT >= 21) bannerWrap.setElevation(dp(6));

        ImageView banner = new ImageView(this);
        banner.setScaleType(ImageView.ScaleType.CENTER_CROP);
        banner.setBackground(shape(Color.WHITE, 18, 0, 0));
        if (Build.VERSION.SDK_INT >= 21) banner.setClipToOutline(true);
        try (InputStream in = getAssets().open("images/banner.png")) {
            Bitmap b = BitmapFactory.decodeStream(in);
            if (b != null) banner.setImageBitmap(b);
        } catch (Exception ignored) {}
        bannerWrap.addView(banner, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(128)));
        LinearLayout.LayoutParams bp = lp(-1, -2);
        bp.bottomMargin = dp(12);
        page.addView(bannerWrap, bp);

        LinearLayout pillRow = new LinearLayout(this);
        pillRow.setOrientation(LinearLayout.HORIZONTAL);
        pillRow.setGravity(Gravity.CENTER);
        String[] pillLabels = {"Notes", "Mock Tests", "Videos", "Papers"};
        int[] pillBgs = {
                Color.rgb(219, 234, 254),
                Color.rgb(209, 250, 229),
                Color.rgb(254, 226, 226),
                Color.rgb(254, 243, 199)
        };
        int[] pillFgs = {
                Color.rgb(29, 78, 216),
                Color.rgb(4, 120, 87),
                Color.rgb(185, 28, 28),
                Color.rgb(180, 83, 9)
        };
        for (int i = 0; i < pillLabels.length; i++) {
            TextView p = text(pillLabels[i], 11, pillFgs[i], true);
            p.setGravity(Gravity.CENTER);
            p.setPadding(dp(4), dp(6), dp(4), dp(6));
            p.setBackground(shape(pillBgs[i], 14, Color.WHITE, 1));
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i < pillLabels.length - 1) plp.rightMargin = dp(6);
            pillRow.addView(p, plp);
        }
        LinearLayout.LayoutParams rowLp = lp(-1, -2);
        rowLp.bottomMargin = dp(14);
        page.addView(pillRow, rowLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(20));
        card.setBackground(shape(Color.WHITE, 24, Color.rgb(214, 227, 250), 1));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(6));

        View accentStrip = new View(this);
        accentStrip.setBackground(hGradient(Color.rgb(245, 158, 11), blue, 4));
        LinearLayout.LayoutParams stripLp = lp(96, 4);
        stripLp.gravity = Gravity.CENTER_HORIZONTAL;
        stripLp.bottomMargin = dp(14);
        card.addView(accentStrip, stripLp);

        TextView welcome = text(editing ? "Edit Your Profile" : "Student Registration", 21, navy, true);
        welcome.setGravity(Gravity.CENTER);
        card.addView(welcome, lp(-1, -2));

        TextView subtitle = text(
                editing ? "Update your details or switch course" : "Quick setup to unlock your course",
                13, muted, false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subp = lp(-1, -2);
        subp.topMargin = dp(5);
        subp.bottomMargin = dp(16);
        card.addView(subtitle, subp);

        // Compact Horizontal Photo Card
        LinearLayout photoPanel = new LinearLayout(this);
        photoPanel.setOrientation(LinearLayout.HORIZONTAL);
        photoPanel.setGravity(Gravity.CENTER_VERTICAL);
        photoPanel.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable photoBg = hGradient(Color.rgb(238, 245, 255), Color.rgb(245, 240, 255), 18);
        photoBg.setStroke(dp(1), Color.rgb(208, 224, 252));
        photoPanel.setBackground(photoBg);

        FrameLayout avatarRing = new FrameLayout(this);
        avatarRing.setPadding(dp(3), dp(3), dp(3), dp(3));
        avatarRing.setBackground(hGradient(Color.rgb(245, 158, 11), blue, 40));

        photo = new ImageView(this);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setBackground(shape(Color.rgb(224, 236, 255), 36, Color.WHITE, 2));
        if (Build.VERSION.SDK_INT >= 21) photo.setClipToOutline(true);
        avatarRing.addView(photo, new FrameLayout.LayoutParams(dp(64), dp(64)));
        renderPhoto();

        LinearLayout.LayoutParams ringLp = lp(-2, -2);
        ringLp.rightMargin = dp(12);
        photoPanel.addView(avatarRing, ringLp);

        LinearLayout photoRight = new LinearLayout(this);
        photoRight.setOrientation(LinearLayout.VERTICAL);
        photoRight.addView(text("Profile Photo (Optional)", 14, ink, true));
        TextView photoSub = text("Saved only on your phone", 11, muted, false);
        LinearLayout.LayoutParams psubLp = lp(-1, -2);
        psubLp.topMargin = dp(2);
        psubLp.bottomMargin = dp(8);
        photoRight.addView(photoSub, psubLp);

        LinearLayout photoBtns = new LinearLayout(this);
        photoBtns.setOrientation(LinearLayout.HORIZONTAL);

        Button pick = new Button(this);
        pick.setText("Choose Photo");
        pick.setAllCaps(false);
        pick.setTextSize(12);
        pick.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        pick.setTextColor(Color.WHITE);
        pick.setPadding(dp(10), 0, dp(10), 0);
        pick.setBackground(hGradient(blue, Color.rgb(59, 130, 246), 18));
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, "Select profile photo"), SELECT_PHOTO);
        });
        LinearLayout.LayoutParams pickLp = new LinearLayout.LayoutParams(0, dp(34), 1.3f);
        pickLp.rightMargin = dp(6);
        photoBtns.addView(pick, pickLp);

        Button removeBtn = new Button(this);
        removeBtn.setText("Remove");
        removeBtn.setAllCaps(false);
        removeBtn.setTextSize(12);
        removeBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        removeBtn.setTextColor(Color.rgb(190, 24, 54));
        removeBtn.setPadding(dp(8), 0, dp(8), 0);
        removeBtn.setBackground(shape(Color.rgb(255, 235, 238), 18, Color.rgb(252, 165, 165), 1));
        removeBtn.setOnClickListener(v -> {
            new File(getFilesDir(), "sdkc_student_avatar.jpg").delete();
            renderPhoto();
        });
        LinearLayout.LayoutParams remLp = new LinearLayout.LayoutParams(0, dp(34), 0.9f);
        photoBtns.addView(removeBtn, remLp);

        photoRight.addView(photoBtns, lp(-1, -2));
        photoPanel.addView(photoRight, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout.LayoutParams phlp = lp(-1, -2);
        phlp.bottomMargin = dp(16);
        card.addView(photoPanel, phlp);

        // Full Name
        card.addView(fieldLabel("Full Name *"));
        name = input("Enter your full name", sp.getString("name", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        card.addView(badgedInput("👤", Color.rgb(219, 234, 254), blue, name), lp(-1, 52));

        card.addView(new View(this), lp(1, 12));

        // Mobile Number
        card.addView(fieldLabel("Mobile Number *"));
        phone = input("Enter 10-digit mobile number", sp.getString("mobile", ""),
                InputType.TYPE_CLASS_NUMBER);
        phone.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        card.addView(badgedInput("+91", Color.rgb(209, 250, 229), Color.rgb(4, 120, 87), phone), lp(-1, 52));

        card.addView(new View(this), lp(1, 14));

        // Select Course / Class * (6 Options in 2x3 Grid)
        card.addView(fieldLabel("Select Course / Class *"));
        LinearLayout courseBox = new LinearLayout(this);
        courseBox.setOrientation(LinearLayout.VERTICAL);
        courseBox.setPadding(dp(10), dp(10), dp(10), dp(10));
        courseBox.setBackground(shape(Color.rgb(255, 251, 235), 16, Color.rgb(245, 158, 11), 1));
        courseButtons.clear();

        for (int i = 0; i < COURSES.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = 0; j < 2 && (i + j) < COURSES.length; j++) {
                final String cName = COURSES[i + j];
                Button cb = new Button(this);
                cb.setText(cName);
                cb.setAllCaps(false);
                cb.setTextSize(12);
                cb.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                cb.setPadding(dp(6), 0, dp(6), 0);
                cb.setOnClickListener(v -> {
                    selectedCourse = cName;
                    refreshCourseButtons();
                });
                courseButtons.add(cb);
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, dp(42), 1f);
                if (j == 0) clp.rightMargin = dp(8);
                row.addView(cb, clp);
            }
            LinearLayout.LayoutParams rlp = lp(-1, -2);
            if (i + 2 < COURSES.length) rlp.bottomMargin = dp(8);
            courseBox.addView(row, rlp);
        }
        refreshCourseButtons();
        card.addView(courseBox, lp(-1, -2));

        // Trust Pill
        TextView trust = text("No OTP  •  No Password  •  Instant Free Access", 11, Color.rgb(15, 118, 110), true);
        trust.setGravity(Gravity.CENTER);
        trust.setPadding(dp(10), dp(7), dp(10), dp(7));
        trust.setBackground(shape(Color.rgb(236, 253, 245), 16, Color.rgb(167, 243, 208), 1));
        LinearLayout.LayoutParams trLp = lp(-1, -2);
        trLp.topMargin = dp(12);
        trLp.bottomMargin = dp(12);
        card.addView(trust, trLp);

        // Notice Card
        LinearLayout noticeWrap = new LinearLayout(this);
        noticeWrap.setOrientation(LinearLayout.HORIZONTAL);
        noticeWrap.setBackground(shape(Color.rgb(255, 250, 235), 14, Color.rgb(253, 224, 138), 1));

        View amberBar = new View(this);
        amberBar.setBackground(shape(Color.rgb(245, 158, 11), 4, 0, 0));
        noticeWrap.addView(amberBar, new LinearLayout.LayoutParams(dp(5), ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout noticeText = new LinearLayout(this);
        noticeText.setOrientation(LinearLayout.VERTICAL);
        noticeText.setPadding(dp(10), dp(10), dp(12), dp(10));
        noticeText.addView(text("Profile & Course Access", 12, Color.rgb(146, 64, 14), true));
        TextView nd = text(
                "You can change your Course anytime from the Profile menu on the top-right.",
                11, Color.rgb(120, 90, 45), false);
        LinearLayout.LayoutParams ndp = lp(-1, -2);
        ndp.topMargin = dp(3);
        noticeText.addView(nd, ndp);
        noticeWrap.addView(noticeText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout.LayoutParams np = lp(-1, -2);
        np.bottomMargin = dp(16);
        card.addView(noticeWrap, np);

        // Submit Button
        Button save = new Button(this);
        save.setText(editing ? "✓  Save Changes" : "Start Learning Now  ➜");
        save.setAllCaps(false);
        save.setTextSize(16);
        save.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        save.setTextColor(Color.WHITE);
        save.setBackground(hGradient(blue, Color.rgb(109, 40, 217), 16));
        if (Build.VERSION.SDK_INT >= 21) save.setElevation(dp(4));
        card.addView(save, lp(-1, 54));
        save.setOnClickListener(v -> save());

        if (editing) {
            TextView back = text("Back to Home", 14, blue, true);
            back.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams backp = lp(-1, 42);
            backp.topMargin = dp(6);
            card.addView(back, backp);
            back.setOnClickListener(v -> finish());
        }

        page.addView(card, lp(-1, -2));

        TextView footer = text("SMART DK CLASSES  •  Learn • Practice • Succeed", 11, Color.rgb(112, 130, 159), true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = lp(-1, -2);
        fp.topMargin = dp(14);
        page.addView(footer, fp);

        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        scroll.addView(root);
        setContentView(scroll);
    }

    private void refreshCourseButtons() {
        for (int i = 0; i < courseButtons.size(); i++) {
            Button cb = courseButtons.get(i);
            String label = COURSES[i];
            boolean selected = label.equalsIgnoreCase(selectedCourse);
            if (selected) {
                cb.setBackground(shape(blue, 12, blue, 1));
                cb.setTextColor(Color.WHITE);
            } else {
                cb.setBackground(shape(Color.WHITE, 12, Color.rgb(190, 212, 248), 1));
                cb.setTextColor(ink);
            }
        }
    }

    private TextView fieldLabel(String s) {
        TextView t = text(s, 13, ink, true);
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.bottomMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }

    private EditText input(String hint, String value, int type) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextSize(14);
        e.setTextColor(ink);
        e.setHintTextColor(Color.rgb(135, 151, 176));
        e.setHint(hint);
        e.setInputType(type);
        e.setText(value);
        e.setBackground(null);
        e.setPadding(dp(10), 0, dp(12), 0);
        return e;
    }

    private LinearLayout badgedInput(String badgeText, int badgeBg, int badgeFg, EditText field) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(6), dp(6), dp(6));
        row.setBackground(shape(Color.rgb(248, 251, 255), 14, Color.rgb(190, 212, 248), 1));

        TextView badge = text(badgeText, 13, badgeFg, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(shape(badgeBg, 10, 0, 0));
        row.addView(badge, lp(42, 38));
        row.addView(field, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        return row;
    }

    private void renderPhoto() {
        try {
            Bitmap b = BitmapFactory.decodeFile(new File(getFilesDir(), "sdkc_student_avatar.jpg").getAbsolutePath());
            if (b != null) {
                photo.setImageBitmap(b);
                return;
            }
        } catch (Exception ignored) {}
        photo.setImageResource(android.R.drawable.ic_menu_camera);
    }

    @Override
    protected void onActivityResult(int r, int c, Intent data) {
        super.onActivityResult(r, c, data);
        if (r != SELECT_PHOTO || c != RESULT_OK || data == null) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            Bitmap original = BitmapFactory.decodeStream(in);
            if (original == null) throw new Exception("Invalid picture");
            int max = 320;
            float scale = Math.min(1f, (float) max / Math.max(original.getWidth(), original.getHeight()));
            Bitmap small = Bitmap.createScaledBitmap(
                    original,
                    Math.max(1, (int) (original.getWidth() * scale)),
                    Math.max(1, (int) (original.getHeight() * scale)),
                    true);
            try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "sdkc_student_avatar.jpg"))) {
                small.compress(Bitmap.CompressFormat.JPEG, 80, out);
            }
            renderPhoto();
        } catch (Exception e) {
            Toast.makeText(this, "Photo नहीं चुनी जा सकी।", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (!editing && !prefs(this).getBoolean("initialized", false)) finishAffinity();
        else super.onBackPressed();
    }

    private void save() {
        String n = name.getText().toString().trim();
        String m = phone.getText().toString().trim();
        if (n.length() < 2) {
            name.setError("Please enter your name");
            return;
        }
        if (!m.matches("[0-9]{10}")) {
            phone.setError("Enter a 10-digit mobile number");
            return;
        }
        SharedPreferences sp = prefs(this);
        String id = sp.getString("profile_id", "");
        String token = sp.getString("profile_token", "");
        if (id.isEmpty()) id = UUID.randomUUID().toString();
        if (token.isEmpty()) token = UUID.randomUUID().toString();
        sp.edit()
                .putString("name", n)
                .putString("mobile", m)
                .putString("course", selectedCourse)
                .putString("profile_id", id)
                .putString("profile_token", token)
                .putBoolean("share", true)
                .putBoolean("initialized", true)
                .apply();
        ProfileSync.sync(this);
        setResult(RESULT_OK);
        finish();
    }
}
