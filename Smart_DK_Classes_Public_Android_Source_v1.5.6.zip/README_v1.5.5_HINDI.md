# Smart DK Classes Public App v1.5.5 (versionCode 31)

## मुख्य बदलाव
1. **Force Update पॉपअप (नए फ़ीचर्स के साथ):**
   - नया वर्ज़न आते ही बिना Later/Skip या Back विकल्प वाला अनिवार्य अपडेट पॉपअप दिखेगा।
   - पॉपअप में **नए फ़ीचर्स (What's New)** भी दिखेंगे (Supabase `site_settings.android_apk_notes` या डिफ़ॉल्ट फ़ीचर लिस्ट से)।
2. **नया आकर्षक Student Registration फ़ॉर्म + 6 कोर्स विकल्प:**
   - `Class 9`, `Class 10`, `Class 11`, `Class 12`, `Competitive Exams`, और `All Courses`।
3. **कोर्स के अनुसार होम स्क्रीन फ़िल्टर:**
   - `Competitive Exams` चुनने पर `Academic Classes (9–12)` कार्ड छिप जाता है और बाकी सभी कार्ड्स दिखते हैं।
   - `Class 9–12` चुनने पर सीधे वही चुनी हुई क्लास दिखती है।
   - `All Courses` चुनने पर पूरा ऐप दिखता है।
4. **ऊपर दाईं ओर प्रोफ़ाइल आइकन और नया मेनू:**
   - फ़ोटो न होने पर नाम का पहला अक्षर (Initial) दिखता है।
   - टैप करने पर नाम, नंबर, चुना हुआ कोर्स, पेंसिल (`✎`) एडिट आइकन, **`Courses`**, **`Go to Website`** (`https://smart-dk-classes-web.pages.dev/`), और **`Logout`** विकल्प खुलते हैं।
