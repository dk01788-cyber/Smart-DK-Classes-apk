# Smart DK Classes Public App v1.5.4 — Force Update (अनिवार्य अपडेट)

## क्या बदला गया है
1. **अनिवार्य अपडेट पॉपअप (Force Update Dialog):**
   - ऐप खुलते ही (`onCreate` और `onResume` पर) Supabase के `site_settings` टेबल से `android_app_version`, `android_apk_notes` और `android_apk_path` की जाँच होती है।
   - अगर सर्वर पर मौजूद वर्ज़न यूज़र के इंस्टॉल किए गए ऐप वर्ज़न से नया है (जैसे यूज़र के पास `1.5.4` है और आपने `1.5.5` डाल दिया), तो तुरंत एक **नॉन-कैंसेलेबल पॉपअप** दिखेगा।
   - इसमें कोई **Later / Skip** बटन नहीं है, बाहर टैप करने या **Back बटन** दबाने से यह बंद नहीं होगा, और **Update Now** पर क्लिक करने पर भी पॉपअप बना रहेगा ताकि बिना नया वर्ज़न इंस्टॉल किए कोई ऐप आगे न चला सके।
2. **Google Play Immediate Update:**
   - Play Store से इंस्टॉल किए गए ऐप के लिए `AppUpdateType.FLEXIBLE` को बदलकर `AppUpdateType.IMMEDIATE` कर दिया गया है, ताकि Play Store अपडेट आने पर भी यूज़र बिना अपडेट किए ऐप न चला सकें।

## भविष्य में अपडेट कैसे ट्रिगर करें
- जब भी आप नया APK बनाएँ (जैसे `1.5.5`), तो अपने **Admin Panel** या **Supabase (`site_settings.android_app_version`)** में नया वर्ज़न नंबर (जैसे `1.5.5`) अपडेट कर दें।
- पुराने वर्ज़न (`1.5.4`) वाले सभी यूज़र्स को तुरंत Force Update पॉपअप दिखने लगेगा।

Application ID: `com.smartdkclasses.app`
Version: `1.5.4` (versionCode 30)
