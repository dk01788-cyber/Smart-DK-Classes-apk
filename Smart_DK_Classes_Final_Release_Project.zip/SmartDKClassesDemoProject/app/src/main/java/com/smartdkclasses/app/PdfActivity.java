package com.smartdkclasses.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.graphics.pdf.PdfRenderer;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class PdfActivity extends Activity {
    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private PdfRenderer.Page currentPage;
    private Bitmap currentBitmap;
    private ImageView imageView;
    private TextView statusView;
    private TextView pageView;
    private Button prevButton;
    private Button nextButton;
    private int pageIndex = 0;
    private File tempFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(Color.rgb(7, 91, 216));
        getWindow().setNavigationBarColor(Color.WHITE);

        String title = getIntent().getStringExtra("title");
        String url = getIntent().getStringExtra("url");
        buildUi(title == null || title.trim().isEmpty() ? "PDF Viewer" : title);

        if (url == null || url.trim().isEmpty()) {
            statusView.setText("PDF link unavailable.");
            return;
        }
        downloadAndOpen(url);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private void buildUi(String title) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(244, 247, 251));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(10), dp(8), dp(12), dp(8));
        header.setBackgroundColor(Color.rgb(7, 91, 216));

        Button back = new Button(this);
        back.setText("‹");
        back.setTextSize(28);
        back.setTextColor(Color.WHITE);
        back.setBackground(new ColorDrawable(Color.TRANSPARENT));
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(52), dp(52)));

        TextView titleView = text(title, 18, Color.WHITE);
        titleView.setMaxLines(2);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        titleView.setTypeface(null, android.graphics.Typeface.BOLD);
        header.addView(titleView, new LinearLayout.LayoutParams(0, dp(58), 1f));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        statusView = text("Loading PDF…", 14, Color.rgb(70, 88, 110));
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(10), dp(10), dp(10), dp(10));
        root.addView(statusView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(229, 234, 240));
        imageView = new ImageView(this);
        imageView.setAdjustViewBounds(true);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setPadding(dp(8), dp(8), dp(8), dp(8));
        scroll.addView(imageView, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(dp(10), dp(8), dp(10), dp(10));
        controls.setBackgroundColor(Color.WHITE);

        prevButton = new Button(this);
        prevButton.setText("‹ Previous");
        prevButton.setEnabled(false);
        prevButton.setOnClickListener(v -> showPage(pageIndex - 1));
        controls.addView(prevButton, new LinearLayout.LayoutParams(0, dp(48), 1f));

        pageView = text("—", 14, Color.rgb(25, 50, 80));
        pageView.setGravity(Gravity.CENTER);
        pageView.setTypeface(null, android.graphics.Typeface.BOLD);
        controls.addView(pageView, new LinearLayout.LayoutParams(dp(95), dp(48)));

        nextButton = new Button(this);
        nextButton.setText("Next ›");
        nextButton.setEnabled(false);
        nextButton.setOnClickListener(v -> showPage(pageIndex + 1));
        controls.addView(nextButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(controls, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    private void downloadAndOpen(String pdfUrl) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL u = new URL(pdfUrl);
                conn = (HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(45000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("Accept", "application/pdf,*/*");
                conn.connect();
                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);

                tempFile = new File(getCacheDir(), "viewer_" + System.currentTimeMillis() + ".pdf");
                try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(tempFile)) {
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }

                descriptor = ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY);
                renderer = new PdfRenderer(descriptor);
                if (renderer.getPageCount() <= 0) throw new Exception("Empty PDF");
                runOnUiThread(() -> {
                    statusView.setText("");
                    showPage(0);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    statusView.setText("PDF open नहीं हो पाया. Internet check करके फिर try करें.");
                    Toast.makeText(PdfActivity.this, "PDF could not be opened", Toast.LENGTH_SHORT).show();
                });
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private void showPage(int index) {
        if (renderer == null || index < 0 || index >= renderer.getPageCount()) return;
        try {
            if (currentPage != null) {
                currentPage.close();
                currentPage = null;
            }
            if (currentBitmap != null) {
                currentBitmap.recycle();
                currentBitmap = null;
            }

            pageIndex = index;
            currentPage = renderer.openPage(index);
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            int targetWidth = Math.max(800, Math.min(1600, screenWidth * 2));
            float ratio = (float) currentPage.getHeight() / (float) currentPage.getWidth();
            int targetHeight = Math.max(1, Math.round(targetWidth * ratio));
            currentBitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
            currentBitmap.eraseColor(Color.WHITE);
            currentPage.render(currentBitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            imageView.setImageBitmap(currentBitmap);
            pageView.setText((pageIndex + 1) + " / " + renderer.getPageCount());
            prevButton.setEnabled(pageIndex > 0);
            nextButton.setEnabled(pageIndex < renderer.getPageCount() - 1);
        } catch (Exception e) {
            Toast.makeText(this, "Page could not be rendered", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { if (currentPage != null) currentPage.close(); } catch (Exception ignored) {}
        try { if (renderer != null) renderer.close(); } catch (Exception ignored) {}
        try { if (descriptor != null) descriptor.close(); } catch (Exception ignored) {}
        if (currentBitmap != null) currentBitmap.recycle();
        if (tempFile != null && tempFile.exists()) tempFile.delete();
    }
}
