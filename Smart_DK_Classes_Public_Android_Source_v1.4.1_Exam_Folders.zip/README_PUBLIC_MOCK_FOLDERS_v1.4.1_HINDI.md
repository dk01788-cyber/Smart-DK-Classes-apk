# Smart DK Classes – Public Android App v1.4.1

## बदलाव

- Home का **Mock Test** कार्ड अब Android के अंदर **Exam Folder Browser** खोलता है।
- मुख्य Mock Test → अलग Exam Folder (UPSSSC PET, SSC, Railway आदि) → उस Folder के Published Sets → Start Test।
- Folder और टेस्ट Supabase (`sdkc_cards` तथा `sdkc_mock_tests`) से पढ़े जाते हैं। Admin से बनाया गया नया Folder स्वतः दिखाई देता है; नए APK की जरूरत नहीं होती, बशर्ते विद्यार्थी ने यह v1.4.1 या नया ऐप इंस्टॉल किया हो।
- पुराने Published, लेकिन किसी Folder से न जुड़े Tests को **अन्य Mock Tests** में दिखाया जाता है; टेस्ट गायब नहीं होते।
- केवल `is_published = true` वाले Tests विद्यार्थियों को दिखाई देते हैं। Draft नहीं दिखते।
- Question Player, Timer, Final Submit, Instant Result और Answer Review मौजूदा `/mock-tests.html?test=<UUID>` वेब-पेज में ही चलते हैं। यह ऐप उसी साझा Supabase का इस्तेमाल करता है।
- पुराने Class, Subject, Category, PDF, Video, Banner, Search, Downloads और नीले-सफेद Home के डिजाइन में कोई बदलाव नहीं किया गया।

## महत्वपूर्ण

- नया फोल्डर बनाते समय Admin App में उसका `parent_id` Mock Test hub/card रखें और `card_type` `folder` हो। संबंधित Mock Test का `card_id` उस folder के UUID से जुड़ा होना चाहिए।
- PET का Folder और मौजूदा PET tests पहले ही backend में जुड़े पाए गए हैं। Future Exams के Folder केवल Admin से Publish करने पर दिखाई देंगे।
- Student login की जरूरत नहीं।
- Release Version: `versionName=1.4.1`, `versionCode=17`। Publish करने से पहले जाँचें कि Play/Indus वितरण में इस app के लिए कोई अधिक versionCode पहले से न हो।
- ZIP में Android Source है, तैयार APK नहीं। GitHub Actions के Automatic APK Builder में यह ZIP डालकर Build करें। पुरानी Signing Key से बने Signed Release APK से ही पुराने ऐप को Update करें।
- Browser Test Page उपलब्ध रहना जरूरी है: https://smart-dk-classes-web.pages.dev/mock-tests.html

## QA टेस्ट

1. Public App Home → Mock Test → UPSSSC PET: Set 01/Set 02 (Published) दिखाई दें, 4 Draft न दिखें।
2. PET Set पर टैप करें → प्रश्न लोड हों → Final Submit → Result → सही/गलत/छोड़े गए Review।
3. Admin में नया Exam Folder जोड़ें, उसमें Published Test लिंक करें → Public App फिर से खोलें → नया Folder अलग दिखे।
4. नए फोल्डर में पुराने PET Sets न दिखें।
5. पुराने Class, PDF, Download और बाकी Home Tabs पहले की तरह काम करें।
