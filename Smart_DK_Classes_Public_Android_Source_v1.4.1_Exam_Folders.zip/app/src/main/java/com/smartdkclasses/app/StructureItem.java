package com.smartdkclasses.app;

import org.json.JSONObject;

public class StructureItem {
    public String id = "";
    public String itemType = "";
    public String name = "";
    public String className = "";
    public String subject = "";
    public String category = "";
    public String systemKey = "";
    public int sortOrder = 0;
    public String bgMode = "solid";
    public String bgColor = "";
    public String gradientColor = "#0f766e";
    public String bgImage = "";

    public static StructureItem fromJson(JSONObject o) {
        StructureItem item = new StructureItem();
        item.id = o.optString("id", "");
        item.itemType = o.optString("item_type", "");
        item.name = o.optString("name", "");
        item.className = o.optString("class_name", "");
        item.subject = o.optString("subject", "");
        item.category = o.optString("category", "");
        item.systemKey = o.optString("system_key", "");
        item.sortOrder = o.optInt("sort_order", 0);
        item.bgMode = o.optString("sdkc_background_mode", "solid");
        item.bgColor = o.isNull("sdkc_background_color") ? "" : o.optString("sdkc_background_color", "");
        item.gradientColor = o.optString("sdkc_gradient_color", "#0f766e");
        item.bgImage = o.isNull("sdkc_background_image") ? "" : o.optString("sdkc_background_image", "");
        return item;
    }
}
