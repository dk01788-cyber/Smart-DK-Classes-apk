package com.smartdkclasses.app;

import org.json.JSONObject;

public class CustomCard {
    public String id = "";
    public String title = "";
    public String cardType = "folder";
    public String bgMode = "solid";
    public String bgColor = "#2563eb";
    public String gradientColor = "#0f766e";
    public String bgImage = "";
    public int sortOrder = 999;

    public static CustomCard fromJson(JSONObject o) {
        CustomCard c = new CustomCard();
        c.id = o.optString("id", "");
        c.title = o.optString("title", "");
        c.cardType = o.optString("card_type", "folder");
        c.bgMode = o.optString("background_mode", "solid");
        c.bgColor = o.optString("background_color", "#2563eb");
        c.gradientColor = o.optString("gradient_color", "#0f766e");
        c.bgImage = o.optString("background_image", "");
        c.sortOrder = o.optInt("sort_order", 999);
        return c;
    }
}
