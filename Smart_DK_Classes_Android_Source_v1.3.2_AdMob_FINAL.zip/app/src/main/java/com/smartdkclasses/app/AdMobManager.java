package com.smartdkclasses.app;

import android.app.Activity;
import android.content.Context;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public final class AdMobManager {
    private static InterstitialAd interstitialAd;
    private static boolean loading;

    private AdMobManager() {}

    public static synchronized void preloadInterstitial(Context context) {
        if (interstitialAd != null || loading) return;
        String adUnitId = context.getString(R.string.admob_interstitial_ad_unit_id).trim();
        if (adUnitId.isEmpty()) return;

        loading = true;
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(context.getApplicationContext(), adUnitId, request,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(InterstitialAd ad) {
                        synchronized (AdMobManager.class) {
                            loading = false;
                            interstitialAd = ad;
                        }
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError error) {
                        synchronized (AdMobManager.class) {
                            loading = false;
                            interstitialAd = null;
                        }
                    }
                });
    }

    public static void showBeforePdf(Activity activity, Runnable onContinue) {
        InterstitialAd ad;
        synchronized (AdMobManager.class) {
            ad = interstitialAd;
            interstitialAd = null;
        }

        if (ad == null) {
            loadAndShow(activity, onContinue);
            return;
        }
        show(activity, ad, onContinue);
    }

    private static void loadAndShow(Activity activity, Runnable onContinue) {
        String adUnitId = activity.getString(R.string.admob_interstitial_ad_unit_id).trim();
        if (adUnitId.isEmpty()) {
            onContinue.run();
            return;
        }

        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(activity, adUnitId, request, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(InterstitialAd ad) {
                if (activity.isFinishing() || activity.isDestroyed()) {
                    onContinue.run();
                    preloadInterstitial(activity.getApplicationContext());
                    return;
                }
                show(activity, ad, onContinue);
            }

            @Override
            public void onAdFailedToLoad(LoadAdError error) {
                onContinue.run();
                preloadInterstitial(activity.getApplicationContext());
            }
        });
    }

    private static void show(Activity activity, InterstitialAd ad, Runnable onContinue) {
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            private boolean continued;

            private void continueOnce() {
                if (continued) return;
                continued = true;
                onContinue.run();
                preloadInterstitial(activity.getApplicationContext());
            }

            @Override
            public void onAdDismissedFullScreenContent() {
                continueOnce();
            }

            @Override
            public void onAdFailedToShowFullScreenContent(AdError adError) {
                continueOnce();
            }
        });

        try {
            ad.show(activity);
        } catch (Exception ignored) {
            onContinue.run();
            preloadInterstitial(activity.getApplicationContext());
        }
    }
}
