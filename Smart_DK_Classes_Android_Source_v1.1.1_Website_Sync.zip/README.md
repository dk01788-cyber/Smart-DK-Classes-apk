# Smart DK Classes — Indus Re-submission Source (v1.1.1)

This source is the corrected Android project prepared after the Indus Appstore rejection that described the earlier build as a website converted into an app.

## Main architecture change
- The public/student experience is now native Android Java UI in `MainActivity.java`.
- The previous full-app WebView shell has been removed.
- Only the protected Admin Panel uses a local WebView (`admin.html`) because it is an internal management interface, not the public app experience.

## Public app features
- Native Home screen and locked blue-white Smart DK Classes branding.
- Classes 9, 10, 11, 12 and subject navigation.
- Native global search over published app content.
- Native PDFs/Notes, Model Papers and Question Papers lists.
- PDF **Open**: opens online PDF directly in the in-app Android PDF viewer.
- PDF **Download**: saves an offline copy in app-private storage.
- **My Downloads** screen: open/delete downloaded PDFs without requiring external storage permission.
- Native Videos list with YouTube links.
- Native Vacancy Updates list.
- Loading, empty-state, retry/error handling.
- Android back navigation handled by native screens.

## PDF security / storage
- Online PDFs are cached only while being viewed.
- Downloaded PDFs are stored under the app's private files directory (`files/pdfs`).
- No broad storage permission is requested.
- PDF viewer uses `FLAG_SECURE` to block screenshots/screen recording where Android supports it.

## Admin login — intentionally unchanged
The existing admin authentication flow remains:
- Email ID or registered mobile number
- Password
- Supabase admin-role verification (`profiles.is_admin`)
- Fingerprint/biometric unlock for a previously verified admin session
- Change Password option

The Admin Panel still supports PDF upload/link, videos, vacancies, Home visibility, App/Website/Both visibility, publish/unpublish, delete, and password change.

## Version
- applicationId: `com.smartdkclasses.app`
- versionCode: `2`
- versionName: `1.1.0`

## Important
No APK has been built as part of this source-only correction step. Build/sign the APK only after final review of the code/features.


## App ↔ Website shared admin sync
- Android Admin Panel is linked to the same Supabase `app_content` source used by the Cloudflare Pages website.
- Default publish target remains **App + Website (Both)**.
- Admin may still select **App Only**, **Website Only**, or **App + Website** per item.
- PDFs/Notes, Model Papers, Question Papers, Videos and Vacancy updates published as `both` are consumed by both products.
- Admin Dashboard now includes **App + Website Sync** status, **Check Sync**, and **Open Website**.
- Website target configured for the existing Cloudflare Pages deployment: `https://smart-dk-classes-web.pages.dev`.
- Login process is unchanged.
