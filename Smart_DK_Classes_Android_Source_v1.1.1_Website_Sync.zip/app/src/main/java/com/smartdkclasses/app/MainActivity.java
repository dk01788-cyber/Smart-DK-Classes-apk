package com.smartdkclasses.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(7, 91, 216);
    private static final int NAVY = Color.rgb(5, 55, 125);
    private static final int BG = Color.rgb(244, 248, 253);
    private static final int TEXT = Color.rgb(16, 35, 63);
    private static final int MUTED = Color.rgb(103, 123, 146);
    private static final int BORDER = Color.rgb(222, 233, 244);

    private FrameLayout contentHost;
    private LinearLayout bottomNav;
    private final List<ContentItem> allContent = new ArrayList<>();
    private boolean loading = false;
    private String activeBottom = "home";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        buildAppShell();
        showHome();
        loadContent(false);
    }

    private void configureWindow() {
        Window w = getWindow();
        w.setStatusBarColor(BLUE);
        w.setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    private void buildAppShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        contentHost = new FrameLayout(this);
        root.addView(contentHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bottomNav = new LinearLayout(this);
        bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        bottomNav.setGravity(Gravity.CENTER);
        bottomNav.setBackgroundColor(Color.WHITE);
        bottomNav.setPadding(dp(2), dp(4), dp(2), dp(4));
        bottomNav.setElevation(dp(8));

        addNav("⌂", "Home", "home", v -> showHome());
        addNav("▣", "Classes", "classes", v -> showClasses());
        addNav("▶", "Videos", "videos", v -> showVideos());
        addNav("⇩", "PDFs", "pdfs", v -> showPdfs("all"));
        addNav("🛡", "Admin", "admin", v -> openAdmin());

        root.addView(bottomNav, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(68)));
        setContentView(root);
    }

    private void addNav(String icon, String label, String key, View.OnClickListener listener) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(2), dp(3), dp(2), dp(2));
        item.setTag(key);
        item.setOnClickListener(listener);

        TextView i = tv(icon, 20, MUTED, true);
        i.setGravity(Gravity.CENTER);
        item.addView(i, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));
        TextView t = tv(label, 11, MUTED, false);
        t.setGravity(Gravity.CENTER);
        item.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(25)));

        bottomNav.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
    }

    private void setActiveBottom(String key) {
        activeBottom = key;
        for (int x = 0; x < bottomNav.getChildCount(); x++) {
            View child = bottomNav.getChildAt(x);
            String tag = String.valueOf(child.getTag());
            boolean active = key.equals(tag);
            if (child instanceof LinearLayout) {
                LinearLayout group = (LinearLayout) child;
                for (int y = 0; y < group.getChildCount(); y++) {
                    View c = group.getChildAt(y);
                    if (c instanceof TextView) {
                        ((TextView) c).setTextColor(active ? BLUE : MUTED);
                        ((TextView) c).setTypeface(null, active ? Typeface.BOLD : Typeface.NORMAL);
                    }
                }
            }
        }
    }

    private void replaceContent(View view) {
        contentHost.removeAllViews();
        contentHost.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private ScrollView scroll(LinearLayout body) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        s.setBackgroundColor(BG);
        s.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return s;
    }

    private View topBar(String title) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(8), dp(14), dp(8));
        bar.setBackgroundColor(BLUE);

        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        setAssetImage(logo, "images/logo.png");
        GradientDrawable logoBg = round(Color.WHITE, 10, 0, 0);
        logo.setBackground(logoBg);
        logo.setPadding(dp(3), dp(3), dp(3), dp(3));
        bar.addView(logo, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout words = vertical();
        words.setPadding(dp(10), 0, 0, 0);
        TextView titleView = tv(title, 19, Color.WHITE, true);
        words.addView(titleView);
        TextView sub = tv("Learn • Practice • Grow", 11, Color.rgb(225, 239, 255), false);
        words.addView(sub);
        bar.addView(words, new LinearLayout.LayoutParams(0, dp(50), 1f));
        return bar;
    }

    private void showHome() {
        setActiveBottom("home");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(topBar("Smart DK Classes"));

        ImageView banner = new ImageView(this);
        banner.setAdjustViewBounds(true);
        banner.setScaleType(ImageView.ScaleType.CENTER_CROP);
        setAssetImage(banner, "images/banner.png");
        body.addView(banner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(205)));

        LinearLayout searchBox = card(12);
        searchBox.setPadding(dp(12), dp(9), dp(12), dp(9));
        EditText search = new EditText(this);
        search.setHint("Search PDFs, videos, class, subject...");
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setBackground(round(Color.rgb(247, 250, 254), 24, BORDER, 1));
        search.setPadding(dp(16), dp(10), dp(16), dp(10));
        searchBox.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        body.addView(searchBox);

        LinearLayout dynamic = vertical();
        body.addView(dynamic);
        renderHomeSections(dynamic, "");
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderHomeSections(dynamic, String.valueOf(s));
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        replaceContent(scroll(body));
    }

    private void renderHomeSections(LinearLayout dynamic, String query) {
        dynamic.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (!q.isEmpty()) {
            addSectionTitle(dynamic, "Search Results", null, null);
            List<ContentItem> result = new ArrayList<>();
            for (ContentItem item : allContent) {
                if (item.searchableText().contains(q)) result.add(item);
            }
            if (result.isEmpty()) addEmpty(dynamic, loading ? "Loading content..." : "No matching content found.");
            else for (ContentItem item : result) dynamic.addView(contentRow(item));
            return;
        }

        addSectionTitle(dynamic, "Choose Class", null, null);
        LinearLayout classes = horizontalGrid();
        String[] classNames = {"Class 9", "Class 10", "Class 11", "Class 12"};
        int[] colors = {Color.rgb(20, 153, 255), Color.rgb(27, 173, 115), Color.rgb(255, 151, 37), Color.rgb(129, 70, 224)};
        for (int i = 0; i < classNames.length; i++) {
            final String c = classNames[i];
            Button b = classButton(c, colors[i]);
            b.setOnClickListener(v -> showClassDetail(c, null));
            classes.addView(b, new LinearLayout.LayoutParams(0, dp(78), 1f));
            if (i < classNames.length - 1) spacer(classes, 8, 1);
        }
        addPadded(dynamic, classes);

        addSectionTitle(dynamic, "Study Material", null, null);
        LinearLayout row1 = horizontalGrid();
        row1.addView(tile("📕", "PDFs / Notes", "Free study material", v -> showPdfs("all")), new LinearLayout.LayoutParams(0, dp(88), 1f));
        spacer(row1, 10, 1);
        row1.addView(tile("📝", "Question Papers", "Practice papers", v -> showPdfs("question_paper")), new LinearLayout.LayoutParams(0, dp(88), 1f));
        addPadded(dynamic, row1);
        LinearLayout row2 = horizontalGrid();
        row2.addView(tile("📗", "Model Papers", "Exam practice", v -> showPdfs("model_paper")), new LinearLayout.LayoutParams(0, dp(88), 1f));
        spacer(row2, 10, 1);
        row2.addView(tile("▶", "Video Lectures", "Concept based", v -> showVideos()), new LinearLayout.LayoutParams(0, dp(88), 1f));
        addPadded(dynamic, row2);

        LinearLayout utilRow = horizontalGrid();
        utilRow.addView(tile("📣", "Vacancy Updates", "Latest notifications", v -> showVacancies()), new LinearLayout.LayoutParams(0, dp(88), 1f));
        spacer(utilRow, 10, 1);
        utilRow.addView(tile("⬇", "Downloads", "Saved inside this app", v -> openDownloads()), new LinearLayout.LayoutParams(0, dp(88), 1f));
        addPadded(dynamic, utilRow);

        addSectionTitle(dynamic, "Latest PDFs", "View All ›", v -> showPdfs("all"));
        int addedPdf = 0;
        for (ContentItem item : allContent) {
            if (item.isPdf() && item.showOnHome) {
                dynamic.addView(contentRow(item));
                addedPdf++;
                if (addedPdf >= 3) break;
            }
        }
        if (addedPdf == 0) addEmpty(dynamic, loading ? "Loading PDFs..." : "No PDF published on Home yet.");

        addSectionTitle(dynamic, "Latest Videos", "YouTube ›", v -> openUrl("https://youtube.com/@smartdkclasses"));
        int addedVideo = 0;
        for (ContentItem item : allContent) {
            if (item.isVideo() && item.showOnHome) {
                dynamic.addView(contentRow(item));
                addedVideo++;
                if (addedVideo >= 4) break;
            }
        }
        if (addedVideo == 0) {
            dynamic.addView(simpleActionCard("▶", "Smart DK Classes", "Official YouTube channel", "Open", v -> openUrl("https://youtube.com/@smartdkclasses")));
        }

        if (!loading && allContent.isEmpty()) {
            addEmpty(dynamic, "No content is published yet. Pulling content requires internet.");
            Button retry = button("Retry", BLUE, Color.WHITE);
            retry.setOnClickListener(v -> loadContent(true));
            LinearLayout wrap = card(14);
            wrap.addView(retry, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
            dynamic.addView(wrap);
        }
    }

    private void showClasses() {
        setActiveBottom("classes");
        LinearLayout body = vertical();
        body.addView(topBar("Classes & Subjects"));
        body.setBackgroundColor(BG);
        addSectionTitle(body, "Choose Class", null, null);
        String[] names = {"Class 9", "Class 10", "Class 11", "Class 12"};
        int[] colors = {Color.rgb(20, 153, 255), Color.rgb(27, 173, 115), Color.rgb(255, 151, 37), Color.rgb(129, 70, 224)};
        for (int i = 0; i < names.length; i++) {
            final String name = names[i];
            Button b = button(name, colors[i], Color.WHITE);
            b.setTextSize(18);
            b.setOnClickListener(v -> showClassDetail(name, null));
            LinearLayout wrap = card(8);
            wrap.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(68)));
            body.addView(wrap);
        }
        replaceContent(scroll(body));
    }

    private void showClassDetail(String className, String preselectedSubject) {
        activeBottom = "classes";
        setActiveBottom("classes");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(simpleHeader(className, this::showClasses));

        addSectionTitle(body, "Subjects", null, null);
        LinearLayout subjectsWrap = vertical();
        List<String> subjects = subjectsFor(className);
        for (int i = 0; i < subjects.size(); i += 2) {
            LinearLayout row = horizontalGrid();
            String s1 = subjects.get(i);
            Button b1 = button(s1, i % 4 == 0 ? BLUE : Color.rgb(21, 158, 112), Color.WHITE);
            b1.setOnClickListener(v -> showClassDetail(className, s1));
            row.addView(b1, new LinearLayout.LayoutParams(0, dp(54), 1f));
            spacer(row, 8, 1);
            if (i + 1 < subjects.size()) {
                String s2 = subjects.get(i + 1);
                Button b2 = button(s2, i % 4 == 0 ? Color.rgb(238, 88, 103) : Color.rgb(129, 70, 224), Color.WHITE);
                b2.setOnClickListener(v -> showClassDetail(className, s2));
                row.addView(b2, new LinearLayout.LayoutParams(0, dp(54), 1f));
            } else {
                View filler = new View(this);
                row.addView(filler, new LinearLayout.LayoutParams(0, dp(54), 1f));
            }
            subjectsWrap.addView(row);
            spacer(subjectsWrap, 1, 8);
        }
        addPadded(body, subjectsWrap);

        String heading = preselectedSubject == null ? "All Content" : preselectedSubject;
        addSectionTitle(body, heading, preselectedSubject == null ? null : "Show All", preselectedSubject == null ? null : v -> showClassDetail(className, null));
        int count = 0;
        for (ContentItem item : allContent) {
            if (!className.equalsIgnoreCase(item.className)) continue;
            if (preselectedSubject != null && !preselectedSubject.equalsIgnoreCase(item.subject)) continue;
            body.addView(contentRow(item));
            count++;
        }
        if (count == 0) addEmpty(body, loading ? "Loading content..." : "No content available for this selection yet.");
        replaceContent(scroll(body));
    }

    private List<String> subjectsFor(String className) {
        Set<String> set = new LinkedHashSet<>();
        if ("Class 9".equals(className) || "Class 10".equals(className)) {
            set.addAll(Arrays.asList("Mathematics", "Science", "English", "Hindi", "Social Science"));
        } else {
            set.addAll(Arrays.asList("Mathematics", "Physics", "Chemistry", "Biology", "English", "Hindi"));
        }
        for (ContentItem item : allContent) {
            if (className.equalsIgnoreCase(item.className) && item.subject != null && !item.subject.trim().isEmpty()) {
                set.add(item.subject.trim());
            }
        }
        return new ArrayList<>(set);
    }

    private void showPdfs(String filter) {
        setActiveBottom("pdfs");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(topBar("PDFs / Notes"));

        LinearLayout quick = horizontalGrid();
        Button all = chip("All", "all".equals(filter));
        all.setOnClickListener(v -> showPdfs("all"));
        Button notes = chip("Notes", "note".equals(filter));
        notes.setOnClickListener(v -> showPdfs("note"));
        Button models = chip("Model", "model_paper".equals(filter));
        models.setOnClickListener(v -> showPdfs("model_paper"));
        Button questions = chip("Questions", "question_paper".equals(filter));
        questions.setOnClickListener(v -> showPdfs("question_paper"));
        quick.addView(all, new LinearLayout.LayoutParams(0, dp(42), 1f)); spacer(quick, 5, 1);
        quick.addView(notes, new LinearLayout.LayoutParams(0, dp(42), 1f)); spacer(quick, 5, 1);
        quick.addView(models, new LinearLayout.LayoutParams(0, dp(42), 1f)); spacer(quick, 5, 1);
        quick.addView(questions, new LinearLayout.LayoutParams(0, dp(42), 1f));
        addPadded(body, quick);

        Button downloads = button("⬇  My Downloads", Color.rgb(232, 244, 255), BLUE);
        downloads.setOnClickListener(v -> openDownloads());
        LinearLayout dw = card(4);
        dw.addView(downloads, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        body.addView(dw);

        int count = 0;
        for (ContentItem item : allContent) {
            if (!item.isPdf()) continue;
            if (!"all".equals(filter) && !filter.equals(item.contentType)) continue;
            body.addView(contentRow(item));
            count++;
        }
        if (count == 0) addEmpty(body, loading ? "Loading PDFs..." : "No matching PDF available yet.");
        replaceContent(scroll(body));
    }

    private void showVideos() {
        setActiveBottom("videos");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(topBar("Video Classes"));
        int count = 0;
        for (ContentItem item : allContent) {
            if (item.isVideo()) {
                body.addView(contentRow(item));
                count++;
            }
        }
        if (count == 0) {
            addEmpty(body, loading ? "Loading videos..." : "No videos added yet.");
            body.addView(simpleActionCard("▶", "Smart DK Classes", "Open official YouTube channel", "YouTube", v -> openUrl("https://youtube.com/@smartdkclasses")));
        }
        replaceContent(scroll(body));
    }

    private void showVacancies() {
        setActiveBottom("");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(simpleHeader("Vacancy Updates", this::showHome));
        int count = 0;
        for (ContentItem item : allContent) {
            if (item.isVacancy()) {
                body.addView(contentRow(item));
                count++;
            }
        }
        if (count == 0) addEmpty(body, loading ? "Loading vacancy updates..." : "No vacancy update available yet.");
        replaceContent(scroll(body));
    }

    private View simpleHeader(String title, Runnable backAction) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), dp(8), dp(14), dp(8));
        header.setBackgroundColor(BLUE);
        Button back = button("‹", Color.TRANSPARENT, Color.WHITE);
        back.setTextSize(28);
        back.setOnClickListener(v -> backAction.run());
        header.addView(back, new LinearLayout.LayoutParams(dp(52), dp(52)));
        TextView t = tv(title, 19, Color.WHITE, true);
        t.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(t, new LinearLayout.LayoutParams(0, dp(52), 1f));
        return header;
    }

    private View contentRow(ContentItem item) {
        LinearLayout row = card(8);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(11), dp(10), dp(11), dp(10));

        TextView icon = tv(item.isVideo() ? "▶" : item.isVacancy() ? "📣" : "📄", 24, item.isVideo() ? Color.rgb(230, 28, 60) : BLUE, true);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(54)));

        LinearLayout words = vertical();
        words.setPadding(dp(6), 0, dp(6), 0);
        TextView title = tv(item.title, 14, TEXT, true);
        title.setMaxLines(2);
        words.addView(title);
        String meta = (item.className == null ? "" : item.className);
        if (item.subject != null && !item.subject.trim().isEmpty()) meta += (meta.isEmpty() ? "" : " • ") + item.subject;
        if (item.isVacancy() && item.description != null && !item.description.trim().isEmpty()) meta = item.description;
        TextView sub = tv(meta, 11, MUTED, false);
        sub.setMaxLines(2);
        words.addView(sub);
        row.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (item.isPdf()) {
            LinearLayout actions = vertical();
            Button open = button("Open", Color.rgb(232, 244, 255), BLUE);
            open.setTextSize(11);
            open.setOnClickListener(v -> openPdfOnline(item));
            actions.addView(open, new LinearLayout.LayoutParams(dp(82), dp(38)));
            spacer(actions, 1, 5);
            Button download = button("Download", BLUE, Color.WHITE);
            download.setTextSize(10);
            download.setOnClickListener(v -> downloadPdf(item));
            actions.addView(download, new LinearLayout.LayoutParams(dp(82), dp(38)));
            row.addView(actions);
        } else if (item.isVideo()) {
            Button watch = button("Watch", BLUE, Color.WHITE);
            watch.setOnClickListener(v -> openUrl(firstNonEmpty(item.youtubeUrl, item.externalUrl)));
            row.addView(watch, new LinearLayout.LayoutParams(dp(82), dp(42)));
        } else if (item.isVacancy()) {
            String url = item.externalUrl;
            if (url != null && !url.trim().isEmpty()) {
                Button open = button("Open", BLUE, Color.WHITE);
                open.setOnClickListener(v -> openUrl(url));
                row.addView(open, new LinearLayout.LayoutParams(dp(82), dp(42)));
            }
        }
        return row;
    }

    private View simpleActionCard(String iconText, String titleText, String subtitle, String actionText, View.OnClickListener listener) {
        ContentItem fake = new ContentItem();
        LinearLayout row = card(8);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView icon = tv(iconText, 24, Color.rgb(230, 28, 60), true);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(50)));
        LinearLayout words = vertical();
        words.setPadding(dp(8), 0, dp(8), 0);
        words.addView(tv(titleText, 14, TEXT, true));
        words.addView(tv(subtitle, 11, MUTED, false));
        row.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button action = button(actionText, BLUE, Color.WHITE);
        action.setOnClickListener(listener);
        row.addView(action, new LinearLayout.LayoutParams(dp(84), dp(42)));
        return row;
    }

    private void openPdfOnline(ContentItem item) {
        String url = ContentRepository.resolveContentUrl(item);
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "PDF link unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, PdfActivity.class);
        i.putExtra("url", url);
        i.putExtra("title", item.title);
        startActivity(i);
    }

    private void downloadPdf(ContentItem item) {
        String url = ContentRepository.resolveContentUrl(item);
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "PDF link unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        AlertDialog wait = new AlertDialog.Builder(this)
                .setTitle("Downloading PDF")
                .setMessage("Please wait…")
                .setCancelable(false)
                .create();
        wait.show();

        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(45000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("Accept", "application/pdf,*/*");
                conn.connect();
                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);

                File dir = new File(getFilesDir(), "pdfs");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Storage unavailable");
                String clean = safeFileName(item.title);
                if (!clean.toLowerCase(Locale.ROOT).endsWith(".pdf")) clean += ".pdf";
                File out = new File(dir, System.currentTimeMillis() + "__" + clean);
                try (InputStream in = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(out)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
                }
                runOnUiThread(() -> {
                    wait.dismiss();
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Downloaded")
                            .setMessage("PDF is saved inside Smart DK Classes and will be available in My Downloads.")
                            .setPositiveButton("Open Downloads", (d, which) -> openDownloads())
                            .setNegativeButton("OK", null)
                            .show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    wait.dismiss();
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Download failed")
                            .setMessage("Internet connection or PDF link may be unavailable. Please try again.")
                            .setPositiveButton("Retry", (d, which) -> downloadPdf(item))
                            .setNegativeButton("Cancel", null)
                            .show();
                });
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private String safeFileName(String title) {
        String value = title == null || title.trim().isEmpty() ? "document" : title.trim();
        value = value.replaceAll("[\\\\/:*?\"<>|]+", "_");
        if (value.length() > 100) value = value.substring(0, 100);
        return value;
    }

    private void openDownloads() {
        startActivity(new Intent(this, DownloadsActivity.class));
    }

    private void openAdmin() {
        startActivity(new Intent(this, AdminActivity.class));
    }

    private void openUrl(String url) {
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "Link unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Uri uri = Uri.parse(url.trim());
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open this link", Toast.LENGTH_SHORT).show();
        }
    }

    private String firstNonEmpty(String a, String b) {
        if (a != null && !a.trim().isEmpty()) return a;
        return b == null ? "" : b;
    }

    private void loadContent(boolean fromUser) {
        if (loading) return;
        loading = true;
        if (fromUser) Toast.makeText(this, "Refreshing content…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                List<ContentItem> fetched = ContentRepository.fetchPublishedAppContent();
                runOnUiThread(() -> {
                    allContent.clear();
                    allContent.addAll(fetched);
                    loading = false;
                    refreshVisiblePage();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    loading = false;
                    Toast.makeText(MainActivity.this, "Could not load content. Check internet and retry.", Toast.LENGTH_LONG).show();
                    refreshVisiblePage();
                });
            }
        }).start();
    }

    private void refreshVisiblePage() {
        if ("home".equals(activeBottom)) showHome();
        else if ("classes".equals(activeBottom)) showClasses();
        else if ("videos".equals(activeBottom)) showVideos();
        else if ("pdfs".equals(activeBottom)) showPdfs("all");
    }

    private void addSectionTitle(LinearLayout parent, String title, String action, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(13), dp(14), dp(6));
        TextView t = tv(title, 18, TEXT, true);
        row.addView(t, new LinearLayout.LayoutParams(0, dp(42), 1f));
        if (action != null) {
            Button a = button(action, Color.TRANSPARENT, BLUE);
            a.setTextSize(12);
            a.setOnClickListener(listener);
            row.addView(a, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)));
        }
        parent.addView(row);
    }

    private void addEmpty(LinearLayout parent, String message) {
        LinearLayout box = card(8);
        TextView t = tv(message, 13, MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(18), dp(12), dp(18));
        box.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        parent.addView(box);
    }

    private LinearLayout card(int verticalMargin) {
        LinearLayout box = vertical();
        box.setBackground(round(Color.WHITE, 14, BORDER, 1));
        box.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(14), dp(verticalMargin), dp(14), 0);
        box.setLayoutParams(lp);
        box.setElevation(dp(2));
        return box;
    }

    private void addPadded(LinearLayout parent, View child) {
        LinearLayout wrap = vertical();
        wrap.setPadding(dp(14), dp(4), dp(14), dp(4));
        wrap.addView(child, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        parent.addView(wrap);
    }

    private LinearLayout horizontalGrid() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        return row;
    }

    private void spacer(LinearLayout parent, int widthDp, int heightDp) {
        View s = new View(this);
        parent.addView(s, new LinearLayout.LayoutParams(dp(widthDp), dp(heightDp)));
    }

    private Button classButton(String text, int color) {
        Button b = button(text, color, Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        return b;
    }

    private View tile(String iconText, String title, String subtitle, View.OnClickListener listener) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(10), dp(8), dp(10), dp(8));
        tile.setBackground(round(Color.WHITE, 14, BORDER, 1));
        tile.setElevation(dp(2));
        tile.setOnClickListener(listener);
        TextView icon = tv(iconText, 23, BLUE, true);
        icon.setGravity(Gravity.CENTER);
        tile.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(50)));
        LinearLayout words = vertical();
        words.setPadding(dp(6), 0, 0, 0);
        words.addView(tv(title, 13, TEXT, true));
        words.addView(tv(subtitle, 10, MUTED, false));
        tile.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return tile;
    }

    private Button chip(String text, boolean selected) {
        Button b = button(text, selected ? BLUE : Color.rgb(237, 243, 249), selected ? Color.WHITE : TEXT);
        b.setTextSize(11);
        b.setAllCaps(false);
        return b;
    }

    private Button button(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(fg);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTypeface(null, Typeface.BOLD);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(round(bg, 10, 0, 0));
        return b;
    }

    private TextView tv(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int fill, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private void setAssetImage(ImageView view, String path) {
        try (InputStream in = getAssets().open(path)) {
            view.setImageBitmap(BitmapFactory.decodeStream(in));
        } catch (Exception ignored) {}
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (!"home".equals(activeBottom)) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }
}
