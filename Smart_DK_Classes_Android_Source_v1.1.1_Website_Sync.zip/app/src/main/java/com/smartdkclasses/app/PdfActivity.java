package com.smartdkclasses.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import android.graphics.pdf.PdfRenderer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class PdfActivity extends Activity {
    private static final int BLUE = Color.rgb(7, 91, 216);

    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private PdfRenderer.Page currentPage;
    private Bitmap currentBitmap;
    private ImageView imageView;
    private TextView statusView;
    private TextView pageView;
    private Button prevButton;
    private Button nextButton;
    private Button retryButton;
    private int pageIndex = 0;
    private float zoom = 1f;
    private File tempFile;
    private boolean deleteOnClose = false;
    private String sourceUrl;
    private String sourcePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(BLUE);
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        String title = getIntent().getStringExtra("title");
        sourceUrl = getIntent().getStringExtra("url");
        sourcePath = getIntent().getStringExtra("path");
        buildUi(title == null || title.trim().isEmpty() ? "PDF Viewer" : title);

        if (sourcePath != null && !sourcePath.trim().isEmpty()) {
            openLocal(new File(sourcePath));
        } else if (sourceUrl != null && !sourceUrl.trim().isEmpty()) {
            downloadAndOpen(sourceUrl);
        } else {
            showError("PDF link unavailable.");
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private void buildUi(String title) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(244, 247, 251));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), dp(7), dp(12), dp(7));
        header.setBackgroundColor(BLUE);

        Button back = new Button(this);
        back.setText("‹");
        back.setTextSize(28);
        back.setTextColor(Color.WHITE);
        back.setBackground(new ColorDrawable(Color.TRANSPARENT));
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(52), dp(52)));

        TextView titleView = text(title, 17, Color.WHITE);
        titleView.setMaxLines(2);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        titleView.setTypeface(null, Typeface.BOLD);
        header.addView(titleView, new LinearLayout.LayoutParams(0, dp(58), 1f));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER);
        statusRow.setPadding(dp(10), dp(6), dp(10), dp(6));
        statusView = text("Loading PDF…", 13, Color.rgb(70, 88, 110));
        statusView.setGravity(Gravity.CENTER);
        statusRow.addView(statusView, new LinearLayout.LayoutParams(0, dp(38), 1f));
        retryButton = new Button(this);
        retryButton.setText("Retry");
        retryButton.setTextSize(12);
        retryButton.setTextColor(Color.WHITE);
        retryButton.setBackground(rounded(BLUE, 9));
        retryButton.setVisibility(View.GONE);
        retryButton.setOnClickListener(v -> retryOpen());
        statusRow.addView(retryButton, new LinearLayout.LayoutParams(dp(80), dp(38)));
        root.addView(statusRow);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(229, 234, 240));
        imageView = new ImageView(this);
        imageView.setAdjustViewBounds(true);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setPadding(dp(8), dp(8), dp(8), dp(8));
        scroll.addView(imageView, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout zoomControls = new LinearLayout(this);
        zoomControls.setOrientation(LinearLayout.HORIZONTAL);
        zoomControls.setGravity(Gravity.CENTER);
        zoomControls.setPadding(dp(10), dp(5), dp(10), dp(3));
        zoomControls.setBackgroundColor(Color.WHITE);
        Button zoomOut = new Button(this);
        zoomOut.setText("− Zoom");
        zoomOut.setOnClickListener(v -> setZoom(Math.max(0.75f, zoom - 0.25f)));
        zoomControls.addView(zoomOut, new LinearLayout.LayoutParams(0, dp(42), 1f));
        Button zoomReset = new Button(this);
        zoomReset.setText("100%");
        zoomReset.setOnClickListener(v -> setZoom(1f));
        zoomControls.addView(zoomReset, new LinearLayout.LayoutParams(0, dp(42), 1f));
        Button zoomIn = new Button(this);
        zoomIn.setText("+ Zoom");
        zoomIn.setOnClickListener(v -> setZoom(Math.min(2.25f, zoom + 0.25f)));
        zoomControls.addView(zoomIn, new LinearLayout.LayoutParams(0, dp(42), 1f));
        root.addView(zoomControls);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(dp(10), dp(3), dp(10), dp(8));
        controls.setBackgroundColor(Color.WHITE);

        prevButton = new Button(this);
        prevButton.setText("‹ Previous");
        prevButton.setEnabled(false);
        prevButton.setOnClickListener(v -> showPage(pageIndex - 1));
        controls.addView(prevButton, new LinearLayout.LayoutParams(0, dp(48), 1f));

        pageView = text("—", 14, Color.rgb(25, 50, 80));
        pageView.setGravity(Gravity.CENTER);
        pageView.setTypeface(null, Typeface.BOLD);
        controls.addView(pageView, new LinearLayout.LayoutParams(dp(95), dp(48)));

        nextButton = new Button(this);
        nextButton.setText("Next ›");
        nextButton.setEnabled(false);
        nextButton.setOnClickListener(v -> showPage(pageIndex + 1));
        controls.addView(nextButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(controls);

        setContentView(root);
    }

    private void retryOpen() {
        retryButton.setVisibility(View.GONE);
        statusView.setText("Loading PDF…");
        closeRenderer();
        if (sourcePath != null && !sourcePath.trim().isEmpty()) openLocal(new File(sourcePath));
        else if (sourceUrl != null && !sourceUrl.trim().isEmpty()) downloadAndOpen(sourceUrl);
    }

    private void openLocal(File file) {
        try {
            if (!file.exists() || file.length() == 0) throw new Exception("File not found");
            tempFile = file;
            deleteOnClose = false;
            descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(descriptor);
            if (renderer.getPageCount() <= 0) throw new Exception("Empty PDF");
            statusView.setText("");
            retryButton.setVisibility(View.GONE);
            showPage(0);
        } catch (Exception e) {
            showError("Saved PDF could not be opened.");
        }
    }

    private void downloadAndOpen(String pdfUrl) {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL u = new URL(pdfUrl);
                conn = (HttpURLConnection) u.openConnection();
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(45000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("Accept", "application/pdf,*/*");
                conn.connect();
                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);

                tempFile = new File(getCacheDir(), "viewer_" + System.currentTimeMillis() + ".pdf");
                deleteOnClose = true;
                try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(tempFile)) {
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }

                descriptor = ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY);
                renderer = new PdfRenderer(descriptor);
                if (renderer.getPageCount() <= 0) throw new Exception("Empty PDF");
                runOnUiThread(() -> {
                    statusView.setText("");
                    retryButton.setVisibility(View.GONE);
                    showPage(0);
                });
            } catch (Exception e) {
                runOnUiThread(() -> showError("PDF open नहीं हो पाया। Internet check करके Retry करें."));
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private void showError(String text) {
        statusView.setText(text);
        retryButton.setVisibility(View.VISIBLE);
        Toast.makeText(this, "PDF could not be opened", Toast.LENGTH_SHORT).show();
    }

    private void setZoom(float value) {
        zoom = value;
        if (renderer != null) showPage(pageIndex);
    }

    private void showPage(int index) {
        if (renderer == null || index < 0 || index >= renderer.getPageCount()) return;
        try {
            if (currentPage != null) {
                currentPage.close();
                currentPage = null;
            }
            if (currentBitmap != null) {
                currentBitmap.recycle();
                currentBitmap = null;
            }

            pageIndex = index;
            currentPage = renderer.openPage(index);
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            int targetWidth = Math.max(800, Math.min(2200, Math.round(screenWidth * 2f * zoom)));
            float ratio = (float) currentPage.getHeight() / (float) currentPage.getWidth();
            int targetHeight = Math.max(1, Math.round(targetWidth * ratio));
            currentBitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
            currentBitmap.eraseColor(Color.WHITE);
            currentPage.render(currentBitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            imageView.setImageBitmap(currentBitmap);
            imageView.setScaleType(ImageView.ScaleType.CENTER);
            pageView.setText((pageIndex + 1) + " / " + renderer.getPageCount());
            prevButton.setEnabled(pageIndex > 0);
            nextButton.setEnabled(pageIndex < renderer.getPageCount() - 1);
        } catch (OutOfMemoryError e) {
            zoom = 1f;
            Toast.makeText(this, "Zoom reduced for this page", Toast.LENGTH_SHORT).show();
            showPage(index);
        } catch (Exception e) {
            Toast.makeText(this, "Page could not be rendered", Toast.LENGTH_SHORT).show();
        }
    }

    private void closeRenderer() {
        try { if (currentPage != null) currentPage.close(); } catch (Exception ignored) {}
        currentPage = null;
        try { if (renderer != null) renderer.close(); } catch (Exception ignored) {}
        renderer = null;
        try { if (descriptor != null) descriptor.close(); } catch (Exception ignored) {}
        descriptor = null;
        if (currentBitmap != null) {
            currentBitmap.recycle();
            currentBitmap = null;
        }
        if (deleteOnClose && tempFile != null && tempFile.exists()) tempFile.delete();
        tempFile = null;
    }

    @Override
    protected void onDestroy() {
        closeRenderer();
        super.onDestroy();
    }
}
