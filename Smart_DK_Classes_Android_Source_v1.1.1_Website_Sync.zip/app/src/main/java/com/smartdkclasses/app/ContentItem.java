package com.smartdkclasses.app;

import org.json.JSONObject;

public class ContentItem {
    public String id = "";
    public String contentType = "";
    public String title = "";
    public String className = "";
    public String subject = "";
    public String description = "";
    public String filePath = "";
    public String externalUrl = "";
    public String youtubeUrl = "";
    public boolean showOnHome = false;

    public static ContentItem fromJson(JSONObject o) {
        ContentItem item = new ContentItem();
        item.id = o.optString("id", "");
        item.contentType = o.optString("content_type", "");
        item.title = o.optString("title", "Untitled");
        item.className = o.optString("class_name", "");
        item.subject = o.optString("subject", "");
        item.description = o.optString("description", "");
        item.filePath = o.optString("file_path", "");
        item.externalUrl = o.optString("external_url", "");
        item.youtubeUrl = o.optString("youtube_url", "");
        item.showOnHome = o.optBoolean("show_on_home", false);
        return item;
    }

    public boolean isPdf() {
        return "pdf".equals(contentType)
                || "note".equals(contentType)
                || "model_paper".equals(contentType)
                || "question_paper".equals(contentType);
    }

    public boolean isVideo() {
        return "video".equals(contentType);
    }

    public boolean isVacancy() {
        return "vacancy".equals(contentType);
    }

    public String searchableText() {
        return (title + " " + className + " " + subject + " " + description + " " + contentType).toLowerCase();
    }
}
