package com.smartdkclasses.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(7, 91, 216);
    private static final int BG = Color.rgb(244, 248, 253);
    private static final int TEXT = Color.rgb(16, 35, 63);
    private static final int MUTED = Color.rgb(103, 123, 146);
    private static final int BORDER = Color.rgb(222, 233, 244);

    private FrameLayout contentHost;
    private LinearLayout bottomNav;
    private AdView bannerAdView;
    private final List<ContentItem> allContent = new ArrayList<>();
    private final List<StructureItem> allStructure = new ArrayList<>();
    private final List<CustomCard> homeCustomCards = new ArrayList<>();
    private boolean loading = false;
    private String activeBottom = "home";
    private long lastContentRefreshElapsed = 0L;
    private static final long CONTENT_REFRESH_INTERVAL_MS = 60_000L;
    private static final long UPDATE_PROMPT_INTERVAL_MS = 12L * 60 * 60 * 1000;
    private static final int PLAY_UPDATE_REQUEST = 7192;
    private static final int PROFILE_REQUEST = 7193;
    private AppUpdateManager appUpdateManager;
    private boolean updatePromptOpen = false;
    private boolean restartPromptOpen = false;
    private AlertDialog forcedUpdateDialog = null;
    private final InstallStateUpdatedListener updateListener = state -> {
        if (state.installStatus() == InstallStatus.DOWNLOADED) {
            runOnUiThread(this::showCompleteUpdateDialog);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        buildAppShell();
        showHome();
        loadContent(false);
        if (!StudentProfileActivity.prefs(this).getBoolean("initialized",false)) {
            startActivityForResult(new Intent(this,StudentProfileActivity.class),PROFILE_REQUEST);
        }
        // Google Play's flexible update flow; only triggers for eligible Play installs.
        appUpdateManager = AppUpdateManagerFactory.create(this);
        appUpdateManager.registerListener(updateListener);
        checkForcedUpdate();
    }

    private void configureWindow() {
        Window w = getWindow();
        w.setStatusBarColor(BLUE);
        w.setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    private void buildAppShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        contentHost = new FrameLayout(this);
        root.addView(contentHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        FrameLayout bannerHost = new FrameLayout(this);
        bannerHost.setBackgroundColor(Color.WHITE);
        bannerAdView = new AdView(this);
        bannerAdView.setAdSize(AdSize.BANNER);
        bannerAdView.setAdUnitId(getString(R.string.admob_banner_ad_unit_id));
        bannerAdView.setVisibility(View.GONE);
        bannerAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                bannerAdView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(LoadAdError error) {
                bannerAdView.setVisibility(View.GONE);
            }
        });
        FrameLayout.LayoutParams bannerLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        bannerHost.addView(bannerAdView, bannerLp);
        root.addView(bannerHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bannerAdView.loadAd(new AdRequest.Builder().build());

        bottomNav = new LinearLayout(this);
        bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        bottomNav.setGravity(Gravity.CENTER);
        bottomNav.setBackgroundColor(Color.WHITE);
        bottomNav.setPadding(dp(2), dp(4), dp(2), dp(4));
        bottomNav.setElevation(dp(8));

        addNav("⌂", "Home", "home", v -> showHome());
        addNav("▣", "Classes", "classes", v -> showClasses());
        addNav("⌕", "Search", "search", v -> showSearch());
        addNav("⇩", "Downloads", "downloads", v -> openDownloads());

        root.addView(bottomNav, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(68)));
        setContentView(root);
    }

    private void addNav(String icon, String label, String key, View.OnClickListener listener) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(2), dp(3), dp(2), dp(2));
        item.setTag(key);
        item.setOnClickListener(listener);

        TextView i = tv(icon, 20, MUTED, true);
        i.setGravity(Gravity.CENTER);
        item.addView(i, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));
        TextView t = tv(label, 11, MUTED, false);
        t.setGravity(Gravity.CENTER);
        item.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(25)));

        bottomNav.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
    }

    private void setActiveBottom(String key) {
        activeBottom = key;
        for (int x = 0; x < bottomNav.getChildCount(); x++) {
            View child = bottomNav.getChildAt(x);
            String tag = String.valueOf(child.getTag());
            boolean active = key.equals(tag);
            if (child instanceof LinearLayout) {
                LinearLayout group = (LinearLayout) child;
                for (int y = 0; y < group.getChildCount(); y++) {
                    View c = group.getChildAt(y);
                    if (c instanceof TextView) {
                        ((TextView) c).setTextColor(active ? BLUE : MUTED);
                        ((TextView) c).setTypeface(null, active ? Typeface.BOLD : Typeface.NORMAL);
                    }
                }
            }
        }
    }

    private void replaceContent(View view) {
        contentHost.removeAllViews();
        contentHost.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private ScrollView scroll(LinearLayout body) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        s.setBackgroundColor(BG);
        s.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return s;
    }

    private View topBar(String title) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(8), dp(14), dp(8));
        bar.setBackgroundColor(BLUE);

        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        setAssetImage(logo, "images/logo.png");
        logo.setBackground(round(Color.WHITE, 10, 0, 0));
        logo.setPadding(dp(3), dp(3), dp(3), dp(3));
        bar.addView(logo, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout words = vertical();
        words.setPadding(dp(10), 0, 0, 0);
        words.addView(tv(title, 19, Color.WHITE, true));
        words.addView(tv("Learn • Practice • Grow", 11, Color.rgb(225, 239, 255), false));
        bar.addView(words, new LinearLayout.LayoutParams(0, dp(50), 1f));

        View avatarBtn = createProfileAvatar(38, true);
        avatarBtn.setContentDescription("Student Profile");
        avatarBtn.setOnClickListener(v -> showProfileMenuDialog());
        LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        avLp.leftMargin = dp(8);
        bar.addView(avatarBtn, avLp);
        return bar;
    }

    private EditText addSearchBox(LinearLayout body, String hint) {
        LinearLayout searchBox = card(10);
        searchBox.setPadding(dp(12), dp(9), dp(12), dp(9));
        EditText search = new EditText(this);
        search.setHint(hint);
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setBackground(round(Color.rgb(247, 250, 254), 24, BORDER, 1));
        search.setPadding(dp(16), dp(10), dp(16), dp(10));
        searchBox.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        body.addView(searchBox);
        return search;
    }

    private void showHome() {
        setActiveBottom("home");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(topBar("Smart DK Classes"));

        EditText search = addSearchBox(body, "Search notes, model papers, videos...");

        ImageView banner = new ImageView(this);
        banner.setAdjustViewBounds(true);
        banner.setScaleType(ImageView.ScaleType.CENTER_CROP);
        setAssetImage(banner, "images/banner.png");
        LinearLayout bannerWrap = card(6);
        bannerWrap.setPadding(0, 0, 0, 0);
        bannerWrap.addView(banner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(205)));
        body.addView(bannerWrap);

        LinearLayout dynamic = vertical();
        body.addView(dynamic);
        renderHome(dynamic, "");

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderHome(dynamic, String.valueOf(s));
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        replaceContent(scroll(body));
    }

    private void renderHome(LinearLayout dynamic, String query) {
        dynamic.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (!q.isEmpty()) {
            renderSearchResults(dynamic, q);
            return;
        }

        addSectionTitle(dynamic, "Explore Classes & Sections", null, null);
        addHomeCardGrid(dynamic);

        addSectionTitle(dynamic, "Selected Video Classes", null, null);
        List<ContentItem> featured = featuredHomeVideos(4);
        if (featured.isEmpty()) {
            addEmpty(dynamic, loading ? "Loading selected videos..." : "No video is selected for Home yet.");
        } else {
            for (ContentItem item : featured) dynamic.addView(contentRow(item));
        }

        if (!loading && allContent.isEmpty()) {
            addEmpty(dynamic, "No content is published yet.");
            Button retry = button("Retry", BLUE, Color.WHITE);
            retry.setOnClickListener(v -> loadContent(true));
            LinearLayout wrap = card(8);
            wrap.addView(retry, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
            dynamic.addView(wrap);
        }

        // The student question form is the LAST section of the scrollable Home page.
        // No Query menu, separate tab, or new Activity is needed.
        addSectionTitle(dynamic, "अपना प्रश्न पूछें", null, null);
        LinearLayout questionCard = card(8);
        questionCard.addView(new QueryFormView(this).build(),
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));
        dynamic.addView(questionCard);
    }

    private void openProfile() {
        Intent i = new Intent(this, StudentProfileActivity.class);
        i.putExtra("edit", true);
        startActivityForResult(i, PROFILE_REQUEST);
    }

    private View createProfileAvatar(int sizeDp, boolean onBlueHeader) {
        FrameLayout wrap = new FrameLayout(this);
        int bgColor = onBlueHeader ? Color.WHITE : BLUE;
        int txtColor = onBlueHeader ? BLUE : Color.WHITE;
        int strokeColor = onBlueHeader ? Color.WHITE : Color.rgb(194, 214, 247);
        wrap.setBackground(round(bgColor, sizeDp, strokeColor, 2));
        if (Build.VERSION.SDK_INT >= 21) wrap.setClipToOutline(true);

        File avatarFile = new File(getFilesDir(), "sdkc_student_avatar.jpg");
        Bitmap bmp = avatarFile.exists() ? BitmapFactory.decodeFile(avatarFile.getAbsolutePath()) : null;
        if (bmp != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(bmp);
            wrap.addView(iv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            String rawName = StudentProfileActivity.currentName(this);
            String initial = "S";
            if (rawName != null && !rawName.trim().isEmpty()) {
                initial = rawName.trim().substring(0, 1).toUpperCase(Locale.ROOT);
            }
            TextView letter = tv(initial, Math.max(14, sizeDp / 2 - 1), txtColor, true);
            letter.setGravity(Gravity.CENTER);
            wrap.addView(letter, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        return wrap;
    }

    private void showProfileMenuDialog() {
        if (isFinishing() || isDestroyed()) return;
        LinearLayout box = vertical();
        box.setPadding(dp(20), dp(20), dp(20), dp(18));
        box.setBackground(round(Color.WHITE, 20, BORDER, 1));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        View av = createProfileAvatar(52, false);
        LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(dp(52), dp(52));
        avLp.rightMargin = dp(12);
        header.addView(av, avLp);

        LinearLayout info = vertical();
        String displayName = StudentProfileActivity.currentName(this);
        info.addView(tv(displayName.isEmpty() ? "Student" : displayName, 17, TEXT, true));
        String mobile = StudentProfileActivity.prefs(this).getString("mobile", "");
        if (!mobile.isEmpty()) {
            info.addView(tv("+91 " + mobile, 13, MUTED, false));
        }
        String course = StudentProfileActivity.currentCourse(this);
        TextView courseBadge = tv("Course: " + course, 11, BLUE, true);
        courseBadge.setPadding(dp(8), dp(3), dp(8), dp(3));
        courseBadge.setBackground(round(Color.rgb(219, 234, 254), 10, BLUE, 1));
        LinearLayout.LayoutParams cbLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cbLp.topMargin = dp(4);
        info.addView(courseBadge, cbLp);

        header.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView editPencil = tv("✎", 19, BLUE, true);
        editPencil.setGravity(Gravity.CENTER);
        editPencil.setContentDescription("Edit Profile");
        editPencil.setBackground(round(Color.rgb(238, 245, 255), 10, Color.rgb(194, 214, 247), 1));
        LinearLayout.LayoutParams penLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        penLp.leftMargin = dp(8);
        header.addView(editPencil, penLp);

        box.addView(header);

        View divider = new View(this);
        divider.setBackgroundColor(BORDER);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        divLp.topMargin = dp(14);
        divLp.bottomMargin = dp(14);
        box.addView(divider, divLp);

        Button coursesBtn = button("Courses", Color.rgb(238, 245, 255), BLUE);
        coursesBtn.setTextSize(14);
        coursesBtn.setBackground(round(Color.rgb(238, 245, 255), 12, Color.rgb(194, 214, 247), 1));
        box.addView(coursesBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        Button webBtn = button("Go to Website", BLUE, Color.WHITE);
        webBtn.setTextSize(14);
        LinearLayout.LayoutParams webLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        webLp.topMargin = dp(10);
        box.addView(webBtn, webLp);

        Button logoutBtn = new Button(this);
        logoutBtn.setText("Logout");
        logoutBtn.setAllCaps(false);
        logoutBtn.setTextSize(14);
        logoutBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logoutBtn.setTextColor(Color.rgb(190, 24, 54));
        logoutBtn.setBackground(round(Color.rgb(255, 235, 238), 12, Color.rgb(252, 165, 165), 1));
        LinearLayout.LayoutParams loLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        loLp.topMargin = dp(10);
        box.addView(logoutBtn, loLp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(box)
                .create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        editPencil.setOnClickListener(v -> {
            dialog.dismiss();
            openProfile();
        });
        coursesBtn.setOnClickListener(v -> {
            dialog.dismiss();
            showCoursePickerDialog();
        });
        webBtn.setOnClickListener(v -> {
            dialog.dismiss();
            try {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://smart-dk-classes-web.pages.dev/")));
            } catch (Exception ex) {
                Toast.makeText(this, "Browser उपलब्ध नहीं है।", Toast.LENGTH_SHORT).show();
            }
        });
        logoutBtn.setOnClickListener(v -> {
            dialog.dismiss();
            confirmLogout();
        });
        dialog.show();
    }

    private void showCoursePickerDialog() {
        if (isFinishing() || isDestroyed()) return;
        String current = StudentProfileActivity.currentCourse(this);
        int checked = 5;
        for (int i = 0; i < StudentProfileActivity.COURSES.length; i++) {
            if (StudentProfileActivity.COURSES[i].equalsIgnoreCase(current)) {
                checked = i;
                break;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle("अपना कोर्स चुनें (Courses)")
                .setSingleChoiceItems(StudentProfileActivity.COURSES, checked, (d, which) -> {
                    String chosen = StudentProfileActivity.COURSES[which];
                    StudentProfileActivity.setCourse(this, chosen);
                    d.dismiss();
                    Toast.makeText(this, "Course updated: " + chosen, Toast.LENGTH_SHORT).show();
                    if ("classes".equals(activeBottom)) showClasses();
                    else showHome();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void confirmLogout() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("क्या आप वाकई Logout करना चाहते हैं?")
                .setPositiveButton("Logout", (d, w) -> {
                    StudentProfileActivity.prefs(this).edit().clear().apply();
                    new File(getFilesDir(), "sdkc_student_avatar.jpg").delete();
                    startActivityForResult(new Intent(this, StudentProfileActivity.class), PROFILE_REQUEST);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
       super.onActivityResult(requestCode,resultCode,data);
       if(requestCode==PROFILE_REQUEST && resultCode==RESULT_OK) showHome();
       if(requestCode==PLAY_UPDATE_REQUEST && resultCode!=RESULT_OK) checkPlayUpdate();
    }

    private void showClasses() {
        setActiveBottom("classes");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(topBar("Academic Classes"));
        addSectionTitle(body, "Choose Class (9–12)", null, null);
        addClassList(body);
        replaceContent(scroll(body));
    }

    private void addClassList(LinearLayout body) {
        String selectedCourse = StudentProfileActivity.currentCourse(this);
        List<String> names = new ArrayList<>();
        for(String name:visibleClasses()) {
            if(name!=null && name.trim().matches("(?i)^(?:Class|कक्षा)\\s*(?:9|10|11|12)$")) {
                if ("All Courses".equalsIgnoreCase(selectedCourse)) {
                    names.add(name);
                } else if (selectedCourse.equalsIgnoreCase(name.trim())) {
                    names.add(name);
                }
            }
        }
        if ("Competitive Exams".equalsIgnoreCase(selectedCourse)) {
            addEmpty(body, "आपने Competitive Exams चुना है। अगर Academic Classes देखना चाहते हैं, तो Profile > Courses से All Courses या अपनी Class चुनें।");
            return;
        }
        int[] colors = {Color.rgb(20,153,255),Color.rgb(27,173,115),Color.rgb(255,151,37),Color.rgb(129,70,224),Color.rgb(232,82,107),Color.rgb(0,148,136)};
        for (int i = 0; i < names.size(); i++) {
            final String name = names.get(i);
            Button b = button(name, colors[i % colors.length], Color.WHITE);
            b.setTextSize(18);
            b.setOnClickListener(v -> showClassSubjects(name));
            LinearLayout wrap = card(8);
            wrap.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(68)));
            body.addView(wrap);
        }
        if (names.isEmpty()) addEmpty(body, "No class card is currently visible.");
    }

    private void showClassSubjects(String className) {
        activeBottom = "classes";
        setActiveBottom("classes");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(simpleHeader(className, this::showClasses));
        addSectionTitle(body, "Subjects", null, null);

        List<String> subjects = subjectsFor(className);
        if (subjects.isEmpty()) {
            addEmpty(body, loading ? "Loading subjects..." : "No subject content is published for this class yet.");
        } else {
            addSubjectGrid(body, className, subjects);
        }
        replaceContent(scroll(body));
    }

    private void addSubjectGrid(LinearLayout parent, String className, List<String> subjects) {
        for (int i = 0; i < subjects.size(); i += 2) {
            LinearLayout row = horizontalGrid();
            String s1 = subjects.get(i);
            Button b1 = button(s1, i % 4 == 0 ? BLUE : Color.rgb(21, 158, 112), Color.WHITE);
            styleStructureCard(b1,"subject",className,null,null,s1);
            b1.setOnClickListener(v -> showSubjectCategories(className, s1));
            row.addView(b1, new LinearLayout.LayoutParams(0, dp(58), 1f));
            spacer(row, 8, 1);
            if (i + 1 < subjects.size()) {
                String s2 = subjects.get(i + 1);
                Button b2 = button(s2, i % 4 == 0 ? Color.rgb(238, 88, 103) : Color.rgb(129, 70, 224), Color.WHITE);
                styleStructureCard(b2,"subject",className,null,null,s2);
                b2.setOnClickListener(v -> showSubjectCategories(className, s2));
                row.addView(b2, new LinearLayout.LayoutParams(0, dp(58), 1f));
            } else {
                row.addView(new View(this), new LinearLayout.LayoutParams(0, dp(58), 1f));
            }
            addPadded(parent, row);
        }
    }

    private void showSubjectCategories(String className, String subject) {
        activeBottom = "classes";
        setActiveBottom("classes");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(simpleHeader(subject, () -> showClassSubjects(className)));
        addSectionTitle(body, className + " • " + subject, null, null);

        List<String> categories = categoriesFor(className, subject);
        if (categories.isEmpty()) {
            addEmpty(body, loading ? "Loading categories..." : "No content category is available yet.");
        } else {
            List<View> tiles = new ArrayList<>();
            for (String category : categories) {
                boolean videoShelf = isVideoCategoryLabel(className, subject, category);
                String icon = videoShelf ? "▶" : categoryIcon(category);
                String subtitle = videoShelf ? "Chapter-wise video classes" : categorySubtitle(category);
                View ct = categoryTile(icon, category, subtitle,
                        v -> showCategoryContent(className, subject, category));
                styleStructureCard(ct,"category",className,subject,null,category);
                tiles.add(ct);
            }
            addTileGrid(body, tiles);
        }
        replaceContent(scroll(body));
    }

    private void showCategoryContent(String className, String subject, String category) {
        activeBottom = "classes";
        setActiveBottom("classes");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(simpleHeader(category, () -> showSubjectCategories(className, subject)));

        List<ContentItem> matches = contentFor(className, subject, category);
        boolean videoCategory = false;
        for (ContentItem m : matches) if (m.isVideo()) { videoCategory = true; break; }
        if (!videoCategory && structureManaged()) {
            for (StructureItem x : allStructure) {
                if (!"category".equalsIgnoreCase(x.itemType)) continue;
                if (!same(x.className, className) || !same(ContentItem.normalizeSubject(x.subject), ContentItem.normalizeSubject(subject))) continue;
                if (same(x.name, category) && "videos".equalsIgnoreCase(x.systemKey)) { videoCategory = true; break; }
            }
        }
        if (videoCategory) {
            renderVideoCategory(body, className, subject, matches);
        } else {
            addSectionTitle(body, className + " • " + subject, null, null);
            if (matches.isEmpty()) addEmpty(body, loading ? "Loading content..." : "No content is available in this category yet.");
            else for (ContentItem item : matches) body.addView(contentRow(item));
        }
        replaceContent(scroll(body));
    }

    private void renderVideoCategory(LinearLayout body, String className, String subject, List<ContentItem> videos) {
        addSectionTitle(body, "Chapter-wise Videos", null, null);
        TextView hint = tv("Only chapters that currently have published videos are shown here.", 12, MUTED, false);
        hint.setPadding(dp(16), 0, dp(16), dp(8));
        body.addView(hint);

        List<String> chapters = chaptersFor(videos);
        List<View> chapterTiles = new ArrayList<>();
        int index = 0;
        for (String chapter : chapters) {
            int count = 0;
            for (ContentItem item : videos) {
                if (chapterMatches(chapter, item.chapterName)) count++;
            }
            // Empty chapter cards are never rendered. A chapter appears automatically
            // as soon as at least one published video is assigned to it by Admin.
            if (count <= 0) continue;
            final String chapterName = chapter;
            String subtitle = count + (count == 1 ? " video" : " videos");
            View chTile = chapterTile(chapter, subtitle, index++,
                    v -> showChapterVideos(className, subject, chapterName));
            styleStructureCard(chTile,"chapter",className,subject,null,chapter);
            chapterTiles.add(chTile);
        }
        if (!chapterTiles.isEmpty()) addTileGrid(body, chapterTiles);
    }

    private void showChapterVideos(String className, String subject, String chapter) {
        activeBottom = "classes";
        setActiveBottom("classes");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(simpleHeader(chapter, () -> showCategoryContent(className, subject, videoCategoryLabel(className, subject))));
        addSectionTitle(body, className + " • " + subject + " • " + chapter, null, null);
        int count = 0;
        for (ContentItem item : contentFor(className, subject, videoCategoryLabel(className, subject))) {
            if (chapterMatches(chapter, item.chapterName)) {
                body.addView(contentRow(item));
                count++;
            }
        }
        // No empty-state message is shown for chapter videos. Empty chapter cards
        // are hidden before navigation, so normally this screen always has content.
        replaceContent(scroll(body));
    }

    private void showSearch() {
        setActiveBottom("search");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(topBar("Search"));
        EditText search = addSearchBox(body, "Search all notes, papers and videos...");
        LinearLayout results = vertical();
        body.addView(results);
        addEmpty(results, "Type a title, subject, chapter or category to search.");

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                results.removeAllViews();
                String q = String.valueOf(s).trim().toLowerCase(Locale.ROOT);
                if (q.isEmpty()) addEmpty(results, "Type a title, subject, chapter or category to search.");
                else renderSearchResults(results, q);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        replaceContent(scroll(body));
    }

    private void renderSearchResults(LinearLayout parent, String q) {
        addSectionTitle(parent, "Search Results", null, null);
        int count = 0;
        for (ContentItem item : allContent) {
            if (item.searchableText().contains(q)) {
                parent.addView(contentRow(item));
                count++;
            }
        }
        if (count == 0) addEmpty(parent, loading ? "Loading content..." : "No matching content found.");
    }

    private void showVideos() {
        setActiveBottom("videos");
        LinearLayout body = vertical();
        body.setBackgroundColor(BG);
        body.addView(topBar("Video Classes"));

        int total = 0;
        String[] classes = {"Class 9", "Class 10", "Class 11", "Class 12"};
        for (String className : classes) {
            List<ContentItem> classVideos = new ArrayList<>();
            for (ContentItem item : allContent) {
                if (item.isVideo() && className.equalsIgnoreCase(item.className)) classVideos.add(item);
            }
            if (classVideos.isEmpty()) continue;
            addSectionTitle(body, className, null, null);
            for (ContentItem item : classVideos) {
                body.addView(contentRow(item));
                total++;
            }
        }

        List<ContentItem> other = new ArrayList<>();
        for (ContentItem item : allContent) {
            if (!item.isVideo()) continue;
            boolean known = false;
            for (String className : classes) if (className.equalsIgnoreCase(item.className)) known = true;
            if (!known) other.add(item);
        }
        if (!other.isEmpty()) {
            addSectionTitle(body, "Other Videos", null, null);
            for (ContentItem item : other) {
                body.addView(contentRow(item));
                total++;
            }
        }

        if (total == 0) addEmpty(body, loading ? "Loading videos..." : "No videos are published in the app yet.");
        replaceContent(scroll(body));
    }

    private List<ContentItem> featuredHomeVideos(int limit) {
        List<ContentItem> result = new ArrayList<>();
        for (ContentItem item : allContent) {
            if (item.isVideo() && item.showOnHome) {
                result.add(item);
                if (result.size() >= limit) break;
            }
        }
        return result;
    }

    private List<String> subjectsFor(String className) {
        if (structureManaged()) {
            List<String> result = new ArrayList<>();
            for (StructureItem x : allStructure) {
                if (!"subject".equalsIgnoreCase(x.itemType)) continue;
                if (!same(x.className, className)) continue;
                String v = ContentItem.normalizeSubject(x.name);
                if (!v.isEmpty() && !containsIgnoreCase(result, v)) result.add(v);
            }
            return result;
        }
        Set<String> published = new LinkedHashSet<>();
        for (ContentItem item : allContent) {
            if (!className.equalsIgnoreCase(item.className) || item.isVacancy()) continue;
            String subject = ContentItem.normalizeSubject(item.subject);
            if (!subject.isEmpty()) published.add(subject);
        }
        List<String> ordered = new ArrayList<>();
        String[] preferred = {"Mathematics", "Science", "Physics", "Chemistry", "Biology", "English", "Hindi", "Social Science"};
        for (String subject : preferred) if (published.remove(subject)) ordered.add(subject);
        ordered.addAll(published);
        return ordered;
    }

    private List<String> categoriesFor(String className, String subject) {
        // Public app rule: never show an empty category card. A category becomes
        // visible automatically as soon as it has at least one published item.
        if (structureManaged()) {
            List<String> result = new ArrayList<>();
            for (StructureItem x : allStructure) {
                if (!"category".equalsIgnoreCase(x.itemType)) continue;
                if (!same(x.className, className)) continue;
                if (!same(ContentItem.normalizeSubject(x.subject), ContentItem.normalizeSubject(subject))) continue;
                String label = x.name == null ? "" : x.name.trim();
                if (label.isEmpty()) continue;
                if (!hasPublishedContentForCategory(className, subject, label, x.systemKey)) continue;
                if (!containsIgnoreCase(result, label)) result.add(label);
            }
            return result;
        }

        Set<String> published = new LinkedHashSet<>();
        for (ContentItem item : allContent) {
            if (!className.equalsIgnoreCase(item.className)) continue;
            if (!ContentItem.normalizeSubject(subject).equalsIgnoreCase(ContentItem.normalizeSubject(item.subject))) continue;
            if (item.isVacancy()) continue;
            published.add(item.displayCategory());
        }
        List<String> ordered = new ArrayList<>();
        String[] preferred = {"Handwritten Notes", "Notes", "Question Bank", "Model Papers", "Previous Year Papers", "Important Questions", "Formula / Revision Sheet", "Practice Sets / Worksheets", "Videos"};
        for (String category : preferred) {
            if (published.remove(category)) ordered.add(category);
        }
        ordered.addAll(published);
        return ordered;
    }

    private boolean hasPublishedContentForCategory(String className, String subject, String category, String systemKey) {
        boolean videoShelf = "videos".equalsIgnoreCase(systemKey)
                || "Videos".equalsIgnoreCase(ContentItem.normalizeCategory(category));
        for (ContentItem item : allContent) {
            if (!className.equalsIgnoreCase(item.className)) continue;
            if (!ContentItem.normalizeSubject(subject).equalsIgnoreCase(ContentItem.normalizeSubject(item.subject))) continue;
            if (item.isVacancy()) continue;
            if (videoShelf) {
                if (item.isVideo()) return true;
            } else if (ContentItem.normalizeCategory(category)
                    .equalsIgnoreCase(ContentItem.normalizeCategory(item.displayCategory()))) {
                return true;
            }
        }
        return false;
    }

    private List<ContentItem> contentFor(String className, String subject, String category) {
        List<ContentItem> result = new ArrayList<>();
        String wantedCategory = ContentItem.normalizeCategory(category);
        boolean videoShelf = isVideoCategoryLabel(className, subject, category);
        for (ContentItem item : allContent) {
            if (!className.equalsIgnoreCase(item.className)) continue;
            if (!ContentItem.normalizeSubject(subject).equalsIgnoreCase(ContentItem.normalizeSubject(item.subject))) continue;
            if (videoShelf) {
                if (!item.isVideo()) continue;
            } else if (!wantedCategory.equalsIgnoreCase(ContentItem.normalizeCategory(item.displayCategory()))) {
                continue;
            }
            result.add(item);
        }
        return result;
    }

    private List<String> chaptersFor(List<ContentItem> videos) {
        List<String> available = new ArrayList<>();
        for (ContentItem item : videos) {
            String chapter = item.chapterName == null ? "" : item.chapterName.trim();
            if (chapter.isEmpty()) continue;
            if (!containsIgnoreCase(available, chapter)) available.add(chapter);
        }
        if (!structureManaged()) return available;
        List<String> ordered = new ArrayList<>();
        String className = videos.isEmpty() ? "" : videos.get(0).className;
        String subject = videos.isEmpty() ? "" : videos.get(0).subject;
        for (StructureItem x : allStructure) {
            if (!"chapter".equalsIgnoreCase(x.itemType)) continue;
            if (!same(x.className, className)) continue;
            if (!same(ContentItem.normalizeSubject(x.subject), ContentItem.normalizeSubject(subject))) continue;
            for (String chapter : available) {
                if (same(x.name, chapter) && !containsIgnoreCase(ordered, chapter)) ordered.add(chapter);
            }
        }
        return ordered;
    }

    private boolean chapterMatches(String displayChapter, String itemChapter) {
        String a = displayChapter == null ? "" : displayChapter.trim();
        String b = itemChapter == null ? "" : itemChapter.trim();
        if (a.equalsIgnoreCase(b)) return true;
        int an = chapterNumber(a);
        int bn = chapterNumber(b);
        return an > 0 && an == bn;
    }

    private int chapterNumber(String value) {
        if (value == null) return -1;
        String digits = value.replaceAll("[^0-9]", " ").trim();
        if (digits.isEmpty()) return -1;
        String first = digits.split("\\s+")[0];
        try { return Integer.parseInt(first); }
        catch (Exception ignored) { return -1; }
    }

    private String categoryIcon(String category) {
        String c = ContentItem.normalizeCategory(category);
        if ("Videos".equals(c)) return "▶";
        if ("Model Papers".equals(c)) return "▤";
        if ("Question Bank".equals(c) || "Important Questions".equals(c)) return "?";
        if ("Formula / Revision Sheet".equals(c)) return "ƒ";
        if ("Practice Sets / Worksheets".equals(c)) return "✓";
        return "▧";
    }

    private String categorySubtitle(String category) {
        String c = ContentItem.normalizeCategory(category);
        if ("Videos".equals(c)) return "Chapter-wise video classes";
        if ("Handwritten Notes".equals(c)) return "Handwritten study notes";
        if ("Notes".equals(c)) return "Chapter and topic notes";
        if ("Question Bank".equals(c)) return "Practice question bank";
        if ("Model Papers".equals(c)) return "Exam model papers";
        if ("Previous Year Papers".equals(c)) return "Previous board papers";
        if ("Important Questions".equals(c)) return "Important exam questions";
        if ("Formula / Revision Sheet".equals(c)) return "Quick revision material";
        if ("Practice Sets / Worksheets".equals(c)) return "Practice worksheets";
        return "Study material";
    }

    private View simpleHeader(String title, Runnable backAction) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), dp(8), dp(14), dp(8));
        header.setBackgroundColor(BLUE);
        Button back = button("‹", Color.TRANSPARENT, Color.WHITE);
        back.setTextSize(28);
        back.setOnClickListener(v -> backAction.run());
        header.addView(back, new LinearLayout.LayoutParams(dp(52), dp(52)));
        TextView t = tv(title, 19, Color.WHITE, true);
        t.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(t, new LinearLayout.LayoutParams(0, dp(52), 1f));
        return header;
    }

    private View contentRow(ContentItem item) {
        LinearLayout row = card(8);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(11), dp(10), dp(11), dp(10));

        TextView icon = tv(item.isVideo() ? "▶" : item.isVacancy() ? "!" : "▧", 24,
                item.isVideo() ? Color.rgb(230, 28, 60) : BLUE, true);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(54)));

        LinearLayout words = vertical();
        words.setPadding(dp(6), 0, dp(6), 0);
        TextView title = tv(item.title, 14, TEXT, true);
        title.setMaxLines(2);
        words.addView(title);

        String meta = item.className == null ? "" : item.className;
        String subject = ContentItem.normalizeSubject(item.subject);
        if (!subject.isEmpty()) meta += (meta.isEmpty() ? "" : " • ") + subject;
        if (item.chapterName != null && !item.chapterName.trim().isEmpty()) meta += (meta.isEmpty() ? "" : " • ") + item.chapterName.trim();
        if (!item.isVacancy() && item.displayCategory() != null && !item.displayCategory().trim().isEmpty()) meta += (meta.isEmpty() ? "" : " • ") + item.displayCategory();
        TextView sub = tv(meta, 11, MUTED, false);
        sub.setMaxLines(2);
        words.addView(sub);
        row.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (item.isPdf()) {
            LinearLayout actions = vertical();
            Button open = button("Open", Color.rgb(232, 244, 255), BLUE);
            open.setTextSize(11);
            open.setOnClickListener(v -> openPdfOnline(item));
            actions.addView(open, new LinearLayout.LayoutParams(dp(82), dp(38)));
            spacer(actions, 1, 5);
            Button download = button("Download", BLUE, Color.WHITE);
            download.setTextSize(10);
            download.setOnClickListener(v -> downloadPdf(item));
            actions.addView(download, new LinearLayout.LayoutParams(dp(82), dp(38)));
            row.addView(actions);
        } else if (item.isVideo()) {
            Button watch = button("Watch", BLUE, Color.WHITE);
            watch.setOnClickListener(v -> openVideo(item));
            row.addView(watch, new LinearLayout.LayoutParams(dp(82), dp(42)));
        } else if (item.isVacancy()) {
            String url = item.externalUrl;
            if (url != null && !url.trim().isEmpty()) {
                Button open = button("Open", BLUE, Color.WHITE);
                open.setOnClickListener(v -> openUrl(url));
                row.addView(open, new LinearLayout.LayoutParams(dp(82), dp(42)));
            }
        }
        return row;
    }

    private View simpleActionCard(String iconText, String titleText, String subtitle, String actionText, View.OnClickListener listener) {
        LinearLayout row = card(8);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(12), dp(10));
        TextView icon = tv(iconText, 24, Color.rgb(230, 28, 60), true);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(50)));
        LinearLayout words = vertical();
        words.setPadding(dp(8), 0, dp(8), 0);
        words.addView(tv(titleText, 14, TEXT, true));
        words.addView(tv(subtitle, 11, MUTED, false));
        row.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button action = button(actionText, BLUE, Color.WHITE);
        action.setOnClickListener(listener);
        row.addView(action, new LinearLayout.LayoutParams(dp(84), dp(42)));
        return row;
    }

    private void openVideo(ContentItem item) {
        String url = firstNonEmpty(item.youtubeUrl, item.externalUrl);
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "Video link unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, VideoActivity.class);
        i.putExtra("url", url);
        i.putExtra("title", item.title);
        startActivity(i);
    }

    private void openPdfOnline(ContentItem item) {
        String url = ContentRepository.resolveContentUrl(item);
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "PDF link unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, PdfActivity.class);
        i.putExtra("url", url);
        i.putExtra("title", item.title);
        startActivity(i);
    }

    private void downloadPdf(ContentItem item) {
        String url = ContentRepository.resolveContentUrl(item);
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "PDF link unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        AlertDialog wait = new AlertDialog.Builder(this)
                .setTitle("Downloading PDF")
                .setMessage("Please wait…")
                .setCancelable(false)
                .create();
        wait.show();

        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(45000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("Accept", "application/pdf,*/*");
                conn.connect();
                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) throw new Exception("HTTP " + code);

                File dir = new File(getFilesDir(), "pdfs");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Storage unavailable");
                String clean = safeFileName(item.title);
                if (!clean.toLowerCase(Locale.ROOT).endsWith(".pdf")) clean += ".pdf";
                File out = new File(dir, System.currentTimeMillis() + "__" + clean);
                try (InputStream in = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(out)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
                }
                runOnUiThread(() -> {
                    wait.dismiss();
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Downloaded")
                            .setMessage("PDF is saved inside Smart DK Classes and is available in Downloads.")
                            .setPositiveButton("Open Downloads", (d, which) -> openDownloads())
                            .setNegativeButton("OK", null)
                            .show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    wait.dismiss();
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Download failed")
                            .setMessage("Internet connection or PDF link may be unavailable. Please try again.")
                            .setPositiveButton("Retry", (d, which) -> downloadPdf(item))
                            .setNegativeButton("Cancel", null)
                            .show();
                });
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    private String safeFileName(String title) {
        String value = title == null || title.trim().isEmpty() ? "document" : title.trim();
        value = value.replaceAll("[\\\\/:*?\"<>|]+", "_");
        if (value.length() > 100) value = value.substring(0, 100);
        return value;
    }

    private void openDownloads() {
        setActiveBottom("downloads");
        startActivity(new Intent(this, DownloadsActivity.class));
    }

    private void openUrl(String url) {
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "Link unavailable", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url.trim())));
        } catch (Exception e) {
            Toast.makeText(this, "Could not open this link", Toast.LENGTH_SHORT).show();
        }
    }

    private String firstNonEmpty(String a, String b) {
        if (a != null && !a.trim().isEmpty()) return a;
        return b == null ? "" : b;
    }

    private void loadContent(boolean fromUser) {
        if (loading) return;
        loading = true;
        lastContentRefreshElapsed = SystemClock.elapsedRealtime();
        if (fromUser) Toast.makeText(this, "Refreshing content…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                List<ContentItem> fetched = ContentRepository.fetchPublishedAppContent();
                List<StructureItem> fetchedStructure = ContentRepository.fetchVisibleAppStructure();
                try { fetched.addAll(ContentRepository.fetchAcademicMaterials()); }
                catch (Exception ignored) { /* optional until schema migration deploy */ }
                List<CustomCard> fetchedCards;
                try { fetchedCards = ContentRepository.fetchHomeCards(); }
                catch (Exception ignored) { fetchedCards = new ArrayList<>(); }
                final List<CustomCard> loadedCards = fetchedCards;
                runOnUiThread(() -> {
                    homeCustomCards.clear();
                    homeCustomCards.addAll(loadedCards);
                    allStructure.clear();
                    allStructure.addAll(fetchedStructure);
                    allContent.clear();
                    for (ContentItem item : fetched) {
                        item.subject = ContentItem.normalizeSubject(item.subject);
                        if (isUsableContent(item) && isContentPathVisible(item)) allContent.add(item);
                    }
                    loading = false;
                    refreshVisiblePage();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    loading = false;
                    Toast.makeText(MainActivity.this, "Could not load content. Check internet and retry.", Toast.LENGTH_LONG).show();
                    refreshVisiblePage();
                });
            }
        }).start();
    }

    private boolean isVideoCategoryLabel(String className, String subject, String category) {
        if (structureManaged()) {
            for (StructureItem x : allStructure) {
                if (!"category".equalsIgnoreCase(x.itemType)) continue;
                if (!same(x.className, className)) continue;
                if (!same(ContentItem.normalizeSubject(x.subject), ContentItem.normalizeSubject(subject))) continue;
                if (same(x.name, category) && "videos".equalsIgnoreCase(x.systemKey)) return true;
            }
        }
        return "Videos".equalsIgnoreCase(ContentItem.normalizeCategory(category));
    }

    private String videoCategoryLabel(String className, String subject) {
        if (structureManaged()) {
            for (StructureItem x : allStructure) {
                if ("category".equalsIgnoreCase(x.itemType) && same(x.className, className)
                        && same(ContentItem.normalizeSubject(x.subject), ContentItem.normalizeSubject(subject))
                        && "videos".equalsIgnoreCase(x.systemKey)) return x.name;
            }
        }
        return "Videos";
    }

    private boolean structureManaged() { return !allStructure.isEmpty(); }

    private boolean same(String a, String b) { return a != null && b != null && a.trim().equalsIgnoreCase(b.trim()); }

    private boolean containsIgnoreCase(List<String> values, String wanted) {
        for (String v : values) if (same(v, wanted)) return true;
        return false;
    }

    private List<String> visibleClasses() {
        List<String> result = new ArrayList<>();
        if (structureManaged()) {
            for (StructureItem x : allStructure) {
                if ("class".equalsIgnoreCase(x.itemType) && !x.name.trim().isEmpty() && !containsIgnoreCase(result, x.name.trim())) result.add(x.name.trim());
            }
            return result;
        }
        result.add("Class 9"); result.add("Class 10"); result.add("Class 11"); result.add("Class 12");
        return result;
    }

    private boolean visibleStructure(String type, String className, String subject, String category, String name) {
        if (!structureManaged()) return true;
        for (StructureItem x : allStructure) {
            if (!type.equalsIgnoreCase(x.itemType)) continue;
            if (className != null && !same(x.className, className)) continue;
            if (subject != null && !same(ContentItem.normalizeSubject(x.subject), ContentItem.normalizeSubject(subject))) continue;
            if (category != null && !same(ContentItem.normalizeCategory(x.category), ContentItem.normalizeCategory(category))) continue;
            if (name != null && !same(ContentItem.normalizeCategory(x.name), ContentItem.normalizeCategory(name)) && !same(x.name, name)) continue;
            return true;
        }
        return false;
    }

    private boolean isContentPathVisible(ContentItem item) {
        if (!structureManaged() || item.isVacancy()) return true;
        if (!visibleStructure("class", null, null, null, item.className)) return false;
        if (!visibleStructure("subject", item.className, null, null, ContentItem.normalizeSubject(item.subject))) return false;
        String category = item.displayCategory();
        if (!visibleStructure("category", item.className, item.subject, null, category)) return false;
        if (item.isVideo() && item.chapterName != null && !item.chapterName.trim().isEmpty()) {
            boolean chapterVisible = false;
            for (StructureItem x : allStructure) {
                if (!"chapter".equalsIgnoreCase(x.itemType)) continue;
                if (!same(x.className, item.className)) continue;
                if (!same(ContentItem.normalizeSubject(x.subject), ContentItem.normalizeSubject(item.subject))) continue;
                if (same(x.name, item.chapterName)) { chapterVisible = true; break; }
            }
            if (!chapterVisible) return false;
        }
        return true;
    }

    private void refreshVisiblePage() {
        if ("home".equals(activeBottom)) showHome();
        else if ("classes".equals(activeBottom)) showClasses();
        else if ("search".equals(activeBottom)) showSearch();
        else if ("videos".equals(activeBottom)) showVideos();
    }

    private boolean isUsableContent(ContentItem item) {
        if (item == null || item.title == null || item.title.trim().isEmpty()) return false;
        if (item.isPdf()) {
            String url = ContentRepository.resolveContentUrl(item);
            return url != null && (url.startsWith("https://") || url.startsWith("http://"));
        }
        if (item.isVideo()) {
            String url = firstNonEmpty(item.youtubeUrl, item.externalUrl);
            return url != null && (url.startsWith("https://") || url.startsWith("http://"));
        }
        if (item.isVacancy()) {
            String url = item.externalUrl == null ? "" : item.externalUrl.trim();
            return url.startsWith("https://") || url.startsWith("http://");
        }
        return false;
    }

    private static class HomeEntry {
        String title,kind,id,mode,color,gradient,image;
        int position;
        HomeEntry(String t,String k,String key,int order,String m,String c,String g,String pic) {
            title=t;kind=k;id=key;position=order;mode=m;color=c;gradient=g;image=pic;
        }
    }
    private void openExtensionPage(String page){
        Intent i = new Intent(this, ExtensionActivity.class);
        i.putExtra("page",page);startActivity(i);
    }
    private void addHomeCardGrid(LinearLayout parent){
        String selectedCourse = StudentProfileActivity.currentCourse(this);
        if ("All Courses".equalsIgnoreCase(selectedCourse)) {
            Button academic=classButton("🎓  Academic Classes  (9–12)",Color.rgb(36,95,236));
            applyCardStyle(academic,"gradient","#245fec","#5c36cf","");
            academic.setOnClickListener(v->showClasses());
            LinearLayout academicRow=horizontalGrid();
            academicRow.addView(academic,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(90)));
            addPadded(parent,academicRow);
        } else if (!"Competitive Exams".equalsIgnoreCase(selectedCourse)) {
            Button singleClass=classButton("🎓  " + selectedCourse + "  —  All Subjects",Color.rgb(36,95,236));
            applyCardStyle(singleClass,"gradient","#245fec","#5c36cf","");
            singleClass.setOnClickListener(v->showClassSubjects(selectedCourse));
            LinearLayout academicRow=horizontalGrid();
            academicRow.addView(singleClass,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(90)));
            addPadded(parent,academicRow);
        }

        List<HomeEntry> cards=new ArrayList<>();
        for(CustomCard c:homeCustomCards){
            if(c.title!=null && "General Library".equalsIgnoreCase(c.title.trim()))continue;
            cards.add(new HomeEntry(c.title,"mock-hub".equals(c.cardType)?"mock":"folder",c.id,
                c.sortOrder,c.bgMode,c.bgColor,c.gradientColor,c.bgImage));
        }
        Collections.sort(cards,Comparator.comparingInt((HomeEntry x)->x.position).thenComparing(x->x.title));
        for(int n=0;n<cards.size();n+=2){
            LinearLayout row=horizontalGrid();
            HomeEntry first=cards.get(n);
            Button a=classButton(first.title,Color.rgb(24,118,209));
            applyCardStyle(a,first.mode,first.color,first.gradient,first.image);
            a.setOnClickListener(v->clickHomeEntry(first));
            row.addView(a,new LinearLayout.LayoutParams(0,dp(78),1f));
            if(n+1<cards.size()){
                spacer(row,8,1);
                HomeEntry second=cards.get(n+1);
                Button b=classButton(second.title,Color.rgb(24,135,160));
                applyCardStyle(b,second.mode,second.color,second.gradient,second.image);
                b.setOnClickListener(v->clickHomeEntry(second));
                row.addView(b,new LinearLayout.LayoutParams(0,dp(78),1f));
            }else{row.addView(new View(this),new LinearLayout.LayoutParams(0,dp(78),1f));}
            addPadded(parent,row);
        }
    }
    private void clickHomeEntry(HomeEntry e){
        if("class".equals(e.kind)) showClassSubjects(e.title);
        else if("mock".equals(e.kind))startActivity(new Intent(this,MockTestFoldersActivity.class));
        else if("library".equals(e.kind))openExtensionPage("direct.html");
        else openExtensionPage("direct.html?folder="+e.id);
    }
    private void styleStructureCard(View view,String type,String cls,String sub,String cat,String name){
        for(StructureItem x:allStructure){
            if(!type.equalsIgnoreCase(x.itemType)||!same(x.name,name))continue;
            if(cls!=null&&!same(x.className,cls))continue;
            if(sub!=null&&!same(ContentItem.normalizeSubject(x.subject),ContentItem.normalizeSubject(sub)))continue;
            applyCardStyle(view,x.bgMode,x.bgColor,x.gradientColor,x.bgImage);return;
        }
    }
    private int parseHex(String value,int fallback){
        try { if(value!=null&&value.matches("#[0-9a-fA-F]{6}"))return Color.parseColor(value); }
        catch(Exception ignored){}
        return fallback;
    }
    private void applyCardStyle(View card,String mode,String color,String second,String image){
        int base=parseHex(color,Color.rgb(20,101,215));
        if((color==null||color.isEmpty())&&(image==null||image.isEmpty()))return;
        GradientDrawable gd;
        if("gradient".equals(mode))gd=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{base,parseHex(second,Color.rgb(15,118,110))});
        else gd=new GradientDrawable();
        if(!"gradient".equals(mode))gd.setColor(base);
        gd.setCornerRadius(dp(15));card.setBackground(gd);
        if("image".equals(mode)&&image!=null&&image.startsWith("https://")){
            new Thread(()->{
                try{
                    java.net.URL url=new java.net.URL(image);
                    java.net.HttpURLConnection con=(java.net.HttpURLConnection)url.openConnection();
                    con.setConnectTimeout(7000);con.setReadTimeout(7000);
                    Bitmap bitmap;
                    try(InputStream in=con.getInputStream()){bitmap=BitmapFactory.decodeStream(in);}
                    con.disconnect();if(bitmap==null)return;
                    runOnUiThread(()->{
                        if(isFinishing())return;
                        BitmapDrawable pic=new BitmapDrawable(getResources(),bitmap);
                        pic.setGravity(Gravity.FILL);
                        GradientDrawable overlay=new GradientDrawable();overlay.setColor(Color.argb(95,0,0,0));overlay.setCornerRadius(dp(15));
                        card.setBackground(new LayerDrawable(new Drawable[]{pic,overlay}));
                    });
                }catch(Exception ignored){}
            }).start();
        }
    }

    private void addClassGrid(LinearLayout parent) {
        List<String> classNames = visibleClasses();
        int[] colors = {Color.rgb(20,153,255),Color.rgb(27,173,115),Color.rgb(255,151,37),Color.rgb(129,70,224),Color.rgb(232,82,107),Color.rgb(0,148,136)};
        for (int i = 0; i < classNames.size(); i += 2) {
            LinearLayout row = horizontalGrid();
            String c1 = classNames.get(i);
            Button b1 = classButton(c1, colors[i % colors.length]);
            b1.setOnClickListener(v -> showClassSubjects(c1));
            row.addView(b1, new LinearLayout.LayoutParams(0, dp(78), 1f));
            if (i + 1 < classNames.size()) {
                spacer(row, 8, 1);
                String c2 = classNames.get(i + 1);
                Button b2 = classButton(c2, colors[(i + 1) % colors.length]);
                b2.setOnClickListener(v -> showClassSubjects(c2));
                row.addView(b2, new LinearLayout.LayoutParams(0, dp(78), 1f));
            }
            addPadded(parent, row);
        }
        if (classNames.isEmpty()) addEmpty(parent, "No class card is currently visible.");
    }

    private void addTileGrid(LinearLayout parent, List<View> tiles) {
        for (int i = 0; i < tiles.size(); i += 2) {
            LinearLayout row = horizontalGrid();
            row.addView(tiles.get(i), new LinearLayout.LayoutParams(0, dp(92), 1f));
            if (i + 1 < tiles.size()) {
                spacer(row, 10, 1);
                row.addView(tiles.get(i + 1), new LinearLayout.LayoutParams(0, dp(92), 1f));
            }
            addPadded(parent, row);
        }
    }

    private void addSectionTitle(LinearLayout parent, String title, String action, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(13), dp(14), dp(6));
        TextView t = tv(title, 18, TEXT, true);
        row.addView(t, new LinearLayout.LayoutParams(0, dp(42), 1f));
        if (action != null) {
            Button a = button(action, Color.TRANSPARENT, BLUE);
            a.setTextSize(12);
            a.setOnClickListener(listener);
            row.addView(a, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)));
        }
        parent.addView(row);
    }

    private void addEmpty(LinearLayout parent, String message) {
        LinearLayout box = card(8);
        TextView t = tv(message, 13, MUTED, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(18), dp(12), dp(18));
        box.addView(t, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        parent.addView(box);
    }

    private LinearLayout card(int verticalMargin) {
        LinearLayout box = vertical();
        box.setBackground(round(Color.WHITE, 14, BORDER, 1));
        box.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(14), dp(verticalMargin), dp(14), 0);
        box.setLayoutParams(lp);
        box.setElevation(dp(2));
        return box;
    }

    private void addPadded(LinearLayout parent, View child) {
        LinearLayout wrap = vertical();
        wrap.setPadding(dp(14), dp(4), dp(14), dp(4));
        wrap.addView(child, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        parent.addView(wrap);
    }

    private LinearLayout horizontalGrid() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        return row;
    }

    private void spacer(LinearLayout parent, int widthDp, int heightDp) {
        View s = new View(this);
        parent.addView(s, new LinearLayout.LayoutParams(dp(widthDp), dp(heightDp)));
    }

    private Button classButton(String text, int color) {
        Button b = button(text, color, Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        return b;
    }

    private View categoryTile(String iconText, String title, String subtitle, View.OnClickListener listener) {
        int[] palette = categoryPalette(title);
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(11), dp(9), dp(10), dp(9));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, palette);
        bg.setCornerRadius(dp(16));
        tile.setBackground(bg);
        tile.setElevation(dp(4));
        tile.setOnClickListener(listener);

        TextView icon = tv(iconText, 23, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = round(Color.argb(42, 255, 255, 255), 12, Color.argb(75, 255, 255, 255), 1);
        icon.setBackground(iconBg);
        tile.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(52)));

        LinearLayout words = vertical();
        words.setPadding(dp(8), 0, 0, 0);
        TextView titleView = tv(title, 13, Color.WHITE, true);
        titleView.setMaxLines(2);
        words.addView(titleView);
        TextView subtitleView = tv(subtitle, 10, Color.rgb(239, 246, 255), false);
        subtitleView.setMaxLines(2);
        words.addView(subtitleView);
        tile.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return tile;
    }

    private int[] categoryPalette(String category) {
        String c = ContentItem.normalizeCategory(category);
        if ("Handwritten Notes".equals(c)) return new int[]{Color.rgb(2, 132, 199), Color.rgb(37, 99, 235)};
        if ("Notes".equals(c)) return new int[]{Color.rgb(13, 148, 136), Color.rgb(5, 150, 105)};
        if ("Question Bank".equals(c)) return new int[]{Color.rgb(245, 158, 11), Color.rgb(234, 88, 12)};
        if ("Model Papers".equals(c)) return new int[]{Color.rgb(147, 51, 234), Color.rgb(109, 40, 217)};
        if ("Previous Year Papers".equals(c)) return new int[]{Color.rgb(79, 70, 229), Color.rgb(67, 56, 202)};
        if ("Important Questions".equals(c)) return new int[]{Color.rgb(244, 63, 94), Color.rgb(190, 24, 93)};
        if ("Formula / Revision Sheet".equals(c)) return new int[]{Color.rgb(8, 145, 178), Color.rgb(14, 116, 144)};
        if ("Practice Sets / Worksheets".equals(c)) return new int[]{Color.rgb(22, 163, 74), Color.rgb(21, 128, 61)};
        if ("Videos".equals(c)) return new int[]{Color.rgb(220, 38, 38), Color.rgb(190, 24, 93)};

        // Custom categories also get a stable bright palette instead of a plain white/blue card.
        int[][] custom = new int[][]{
                {Color.rgb(37, 99, 235), Color.rgb(2, 132, 199)},
                {Color.rgb(5, 150, 105), Color.rgb(13, 148, 136)},
                {Color.rgb(217, 119, 6), Color.rgb(234, 88, 12)},
                {Color.rgb(124, 58, 237), Color.rgb(147, 51, 234)},
                {Color.rgb(225, 29, 72), Color.rgb(190, 24, 93)},
                {Color.rgb(8, 145, 178), Color.rgb(30, 64, 175)}
        };
        int hash = c == null ? 0 : c.toLowerCase(Locale.ROOT).hashCode();
        if (hash == Integer.MIN_VALUE) hash = 0;
        return custom[Math.abs(hash) % custom.length];
    }

    private View chapterTile(String chapter, String subtitle, int index, View.OnClickListener listener) {
        int[][] palettes = new int[][]{
                {Color.rgb(37, 99, 235), Color.rgb(14, 165, 233)},
                {Color.rgb(16, 185, 129), Color.rgb(5, 150, 105)},
                {Color.rgb(139, 92, 246), Color.rgb(109, 40, 217)},
                {Color.rgb(249, 115, 22), Color.rgb(234, 88, 12)},
                {Color.rgb(236, 72, 153), Color.rgb(225, 29, 72)}
        };
        int[] palette = palettes[index % palettes.length];
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(10), dp(9), dp(10), dp(9));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, palette);
        bg.setCornerRadius(dp(16));
        tile.setBackground(bg);
        tile.setElevation(dp(3));
        tile.setOnClickListener(listener);

        int chapterNo = chapterNumber(chapter);
        String badgeText = chapterNo > 0 ? String.valueOf(chapterNo) : "▶";
        TextView badge = tv(badgeText, 18, Color.WHITE, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(round(Color.argb(45, 255, 255, 255), 12, Color.argb(80, 255, 255, 255), 1));
        tile.addView(badge, new LinearLayout.LayoutParams(dp(42), dp(48)));

        LinearLayout words = vertical();
        words.setPadding(dp(8), 0, 0, 0);
        TextView titleView = tv(chapter, 13, Color.WHITE, true);
        titleView.setMaxLines(1);
        words.addView(titleView);
        TextView sub = tv(subtitle, 10, Color.rgb(240, 248, 255), false);
        sub.setMaxLines(1);
        words.addView(sub);
        tile.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return tile;
    }

    private View tile(String iconText, String title, String subtitle, View.OnClickListener listener) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(10), dp(8), dp(10), dp(8));
        tile.setBackground(round(Color.WHITE, 14, BORDER, 1));
        tile.setElevation(dp(2));
        tile.setOnClickListener(listener);
        TextView icon = tv(iconText, 23, BLUE, true);
        icon.setGravity(Gravity.CENTER);
        tile.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(50)));
        LinearLayout words = vertical();
        words.setPadding(dp(6), 0, 0, 0);
        TextView titleView = tv(title, 13, TEXT, true);
        titleView.setMaxLines(2);
        words.addView(titleView);
        TextView subtitleView = tv(subtitle, 10, MUTED, false);
        subtitleView.setMaxLines(2);
        words.addView(subtitleView);
        tile.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return tile;
    }

    private Button button(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(fg);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTypeface(null, Typeface.BOLD);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(round(bg, 10, 0, 0));
        return b;
    }

    private TextView tv(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int fill, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private void setAssetImage(ImageView view, String path) {
        try (InputStream in = getAssets().open(path)) {
            view.setImageBitmap(BitmapFactory.decodeStream(in));
        } catch (Exception ignored) {}
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if ("downloads".equals(activeBottom)) setActiveBottom("home");
        // Pull fresh published content when students return to the app.
        // A short throttle prevents duplicate network requests on first launch.
        if (lastContentRefreshElapsed > 0L &&
                SystemClock.elapsedRealtime() - lastContentRefreshElapsed >= CONTENT_REFRESH_INTERVAL_MS) {
            loadContent(false);
        }
        checkForcedUpdate();
        checkPlayUpdate();
    }

    private void checkPlayUpdate() {
        if (appUpdateManager == null || updatePromptOpen) return;
        appUpdateManager.getAppUpdateInfo().addOnSuccessListener(info -> {
            if (isFinishing() || isDestroyed()) return;
            if (info.installStatus() == InstallStatus.DOWNLOADED) {
                showCompleteUpdateDialog();
                return;
            }
            boolean immediateAvailable =
                    (info.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                            || info.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS)
                    && info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE);
            if (!immediateAvailable) return;
            try {
                appUpdateManager.startUpdateFlowForResult(
                        info, AppUpdateType.IMMEDIATE, this, PLAY_UPDATE_REQUEST);
            } catch (Exception e) {
                showForcedUpdateDialog("", "Google Play Store पर ऐप का नया वर्ज़न उपलब्ध है।", "");
            }
        }).addOnFailureListener(e -> { /* Sideloaded builds may not support Play updates. */ });
    }

    private void checkForcedUpdate() {
        new Thread(() -> {
            ContentRepository.AppUpdateConfig cfg = ContentRepository.fetchAppUpdateConfig();
            if (cfg == null || cfg.version.isEmpty()) return;
            String currentVersion = getCurrentAppVersion();
            if (!isNewerVersion(cfg.version, currentVersion)) return;
            runOnUiThread(() -> showForcedUpdateDialog(cfg.version, cfg.notes, cfg.apkPath));
        }).start();
    }

    private void showForcedUpdateDialog(String latestVersion, String notes, String apkPath) {
        if (isFinishing() || isDestroyed()) return;
        if (forcedUpdateDialog != null && forcedUpdateDialog.isShowing()) return;

        String title = latestVersion == null || latestVersion.isEmpty()
                ? "नया अपडेट ज़रूरी है"
                : "नया अपडेट उपलब्ध है (v" + latestVersion + ")";
        StringBuilder msg = new StringBuilder();
        msg.append("Smart DK Classes ऐप का नया वर्ज़न आ गया है। बिना अपडेट किए आप ऐप को आगे नहीं चला सकेंगे।");
        msg.append("\n\nनए फ़ीचर्स (What's New):\n");
        if (notes != null && !notes.trim().isEmpty()) {
            msg.append(notes.trim());
        } else {
            msg.append("• नया आकर्षक स्टूडेंट प्रोफ़ाइल और कोर्स सेलेक्शन\n")
               .append("• ऊपर दाईं ओर प्रोफ़ाइल आइकन (Courses, Website, Logout)\n")
               .append("• तेज़ और बेहतर ऐप परफ़ॉर्मेंस");
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg.toString())
                .setCancelable(false)
                .setPositiveButton("Update Now", null)
                .create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.setOnKeyListener((d, keyCode, event) -> keyCode == KeyEvent.KEYCODE_BACK);
        dialog.setOnShowListener(d -> {
            Button btn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            btn.setTextColor(Color.WHITE);
            btn.setBackgroundColor(BLUE);
            btn.setOnClickListener(v -> openAppUpdatePage(apkPath));
        });
        forcedUpdateDialog = dialog;
        dialog.show();
    }

    private void openAppUpdatePage(String apkPath) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://smart-dk-classes-web.pages.dev/app-update.html")));
            return;
        } catch (Exception ignored) {}
        if (apkPath != null && !apkPath.trim().isEmpty()) {
            try {
                String url = apkPath.startsWith("http")
                        ? apkPath
                        : ContentRepository.SUPABASE_URL + "/storage/v1/object/public/app-downloads/" + Uri.encode(apkPath);
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return;
            } catch (Exception ignored) {}
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + getPackageName())));
        } catch (Exception e) {
            Toast.makeText(this, "कृपया वेबसाइट से नया अपडेट डाउनलोड करें।", Toast.LENGTH_LONG).show();
        }
    }

    private String getCurrentAppVersion() {
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            return pInfo.versionName == null ? "0" : pInfo.versionName;
        } catch (Exception e) {
            return "0";
        }
    }

    private boolean isNewerVersion(String latest, String current) {
        if (latest == null || latest.trim().isEmpty()) return false;
        String cleanLatest = latest.trim().replaceFirst("^[vV]", "").split("-")[0];
        String cleanCurrent = (current == null ? "0" : current.trim()).replaceFirst("^[vV]", "").split("-")[0];
        String[] lParts = cleanLatest.split("\\.");
        String[] cParts = cleanCurrent.split("\\.");
        int len = Math.max(lParts.length, cParts.length);
        for (int i = 0; i < len; i++) {
            int lv = parseVersionPart(i < lParts.length ? lParts[i] : "0");
            int cv = parseVersionPart(i < cParts.length ? cParts[i] : "0");
            if (lv > cv) return true;
            if (lv < cv) return false;
        }
        return false;
    }

    private int parseVersionPart(String part) {
        try {
            String digits = part.replaceAll("[^0-9]", "");
            return digits.isEmpty() ? 0 : Integer.parseInt(digits);
        } catch (Exception e) {
            return 0;
        }
    }

    private void showCompleteUpdateDialog() {
        if (restartPromptOpen || isFinishing() || isDestroyed() || appUpdateManager == null) return;
        restartPromptOpen = true;
        new AlertDialog.Builder(this)
                .setTitle("अपडेट डाउनलोड हो गया")
                .setMessage("नया Version लगाने के लिए ऐप रीस्टार्ट करें।")
                .setPositiveButton("Restart and Update", (d, w) -> {
                    restartPromptOpen = false;
                    appUpdateManager.completeUpdate();
                })
                .setNegativeButton("Later", (d, w) -> restartPromptOpen = false)
                .setOnCancelListener(d -> restartPromptOpen = false)
                .show();
    }

    @Override
    public void onBackPressed() {
        if (!"home".equals(activeBottom)) showHome();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (appUpdateManager != null) appUpdateManager.unregisterListener(updateListener);
        if (bannerAdView != null) {
            bannerAdView.destroy();
            bannerAdView = null;
        }
        super.onDestroy();
    }

}
