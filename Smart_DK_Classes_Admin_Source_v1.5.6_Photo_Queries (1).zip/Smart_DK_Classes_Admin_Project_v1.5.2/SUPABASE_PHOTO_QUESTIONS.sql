-- Smart DK Classes — Photo Questions Support (No Storage Bucket Needed)
-- Run ONCE in Supabase > SQL Editor.

begin;

alter table public.sdkc_student_queries
  add column if not exists question_image text;

commit;
