# Smart DK Classes Admin App v1.0.0

Private Android admin application for Smart DK Classes.

## Included
- Email/mobile + password admin login using existing Supabase Auth
- Admin-role verification using profiles.is_admin
- Fingerprint/biometric unlock of an already verified saved session
- Add PDF/study content using Class -> Subject -> Category -> Chapter -> Content
- Separate chapter-wise video publishing
- Home video selection is manual only; Shorts URLs are blocked
- Home video order control using sort_order
- Manage/edit/publish/unpublish/delete content
- App Only / Website Only / Both placement
- Custom category manager (device-local category list; category value is saved to content records)
- Vacancy updates
- Website APK upload panel (uses existing backend setup)
- Change password

Application ID: com.smartdkclasses.adm
Public student app can remain installed at the same time.

This app uses the existing Smart DK Classes Supabase project. Backend RLS policies must allow authenticated admins to write app_content and public-content storage.
