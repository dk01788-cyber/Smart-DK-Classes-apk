package com.smartdkclasses.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Student Registration (Photo, Name, Mobile, Password, Confirm Password, Course) & Password Login. */
public final class StudentProfileActivity extends Activity {
    public static final String PREF = "sdkc_student_profile_v1";
    public static final String[] COURSES = {
            "Class 9", "Class 10",
            "Class 11", "Class 12",
            "Competitive Exams", "All Courses"
    };
    private static final int SELECT_PHOTO = 7001;

    private final int blue = Color.rgb(7, 91, 216);
    private final int deepIndigo = Color.rgb(15, 36, 118);
    private final int navy = Color.rgb(14, 43, 110);
    private final int ink = Color.rgb(24, 47, 83);
    private final int muted = Color.rgb(93, 112, 145);

    private EditText name, phone, passwordField, confirmPasswordField;
    private EditText loginPhone, loginPassword;
    private ImageView photo;
    private Button saveBtn, loginBtn;
    private TextView tabRegBtn, tabLoginBtn;
    private LinearLayout regContainer, loginContainer;
    private boolean editing;
    private boolean loginMode = false;
    private String selectedCourse = "All Courses";
    private final List<Button> courseButtons = new ArrayList<>();

    public static SharedPreferences prefs(Activity a) {
        return a.getSharedPreferences(PREF, MODE_PRIVATE);
    }

    public static String currentName(Activity a) {
        return prefs(a).getString("name", "");
    }

    public static String currentCourse(Activity a) {
        String c = prefs(a).getString("course", "All Courses");
        return (c == null || c.trim().isEmpty()) ? "All Courses" : c.trim();
    }

    public static void setCourse(Activity a, String course) {
        if (course == null || course.trim().isEmpty()) return;
        prefs(a).edit().putString("course", course.trim()).apply();
    }

    public static String currentPhoto(Activity a) {
        try {
            File f = new File(a.getFilesDir(), "sdkc_student_avatar.jpg");
            if (!f.exists()) return "";
            try (InputStream in = new java.io.FileInputStream(f)) {
                byte[] buff = new byte[(int) Math.min(f.length(), 100000)];
                int pos = 0, n;
                while (pos < buff.length && (n = in.read(buff, pos, buff.length - pos)) > 0) pos += n;
                return "data:image/jpeg;base64," + Base64.encodeToString(buff, 0, pos, Base64.NO_WRAP);
            }
        } catch (Exception ex) {
            return "";
        }
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(10, 28, 96));
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        editing = getIntent().getBooleanExtra("edit", false);
        selectedCourse = currentCourse(this);
        draw();
    }

    private int dp(float n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable shape(int color, int radius, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private GradientDrawable hGradient(int c1, int c2, int radius) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }

    private void draw() {
        SharedPreferences sp = prefs(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(238, 244, 255));

        FrameLayout root = new FrameLayout(this);

        View heroBg = new View(this);
        GradientDrawable heroGrad = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{deepIndigo, Color.rgb(24, 119, 242)});
        float r = dp(28);
        heroGrad.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        heroBg.setBackground(heroGrad);
        root.addView(heroBg, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(228)));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(12), dp(16), dp(26));

        TextView topTag = text("CLASSES 9 - 12  •  COMPETITIVE EXAMS", 11, Color.rgb(14, 30, 80), true);
        topTag.setGravity(Gravity.CENTER);
        topTag.setPadding(dp(16), dp(5), dp(16), dp(5));
        topTag.setBackground(shape(Color.rgb(255, 204, 0), 16, 0, 0));
        LinearLayout.LayoutParams tagLp = lp(-2, -2);
        tagLp.gravity = Gravity.CENTER_HORIZONTAL;
        tagLp.bottomMargin = dp(10);
        page.addView(topTag, tagLp);

        FrameLayout bannerWrap = new FrameLayout(this);
        bannerWrap.setPadding(dp(3), dp(3), dp(3), dp(3));
        bannerWrap.setBackground(shape(Color.WHITE, 20, Color.WHITE, 0));
        if (Build.VERSION.SDK_INT >= 21) bannerWrap.setElevation(dp(6));

        ImageView banner = new ImageView(this);
        banner.setScaleType(ImageView.ScaleType.CENTER_CROP);
        banner.setBackground(shape(Color.WHITE, 18, 0, 0));
        if (Build.VERSION.SDK_INT >= 21) banner.setClipToOutline(true);
        try (InputStream in = getAssets().open("images/banner.png")) {
            Bitmap b = BitmapFactory.decodeStream(in);
            if (b != null) banner.setImageBitmap(b);
        } catch (Exception ignored) {}
        bannerWrap.addView(banner, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(124)));
        LinearLayout.LayoutParams bp = lp(-1, -2);
        bp.bottomMargin = dp(14);
        page.addView(bannerWrap, bp);

        // Main Card
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(20));
        card.setBackground(shape(Color.WHITE, 24, Color.rgb(214, 227, 250), 1));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(6));

        if (!editing) {
            // Segmented Tabs: [ New Registration ] | [ Login ]
            LinearLayout tabRow = new LinearLayout(this);
            tabRow.setOrientation(LinearLayout.HORIZONTAL);
            tabRow.setPadding(dp(4), dp(4), dp(4), dp(4));
            tabRow.setBackground(shape(Color.rgb(238, 244, 255), 16, Color.rgb(202, 219, 247), 1));

            tabRegBtn = text("New Registration", 13, Color.WHITE, true);
            tabRegBtn.setGravity(Gravity.CENTER);
            tabRegBtn.setOnClickListener(v -> switchMode(false));

            tabLoginBtn = text("Login", 13, ink, true);
            tabLoginBtn.setGravity(Gravity.CENTER);
            tabLoginBtn.setOnClickListener(v -> switchMode(true));

            tabRow.addView(tabRegBtn, new LinearLayout.LayoutParams(0, dp(40), 1f));
            tabRow.addView(tabLoginBtn, new LinearLayout.LayoutParams(0, dp(40), 1f));

            LinearLayout.LayoutParams trLp = lp(-1, -2);
            trLp.bottomMargin = dp(14);
            card.addView(tabRow, trLp);
        }

        // ---------------- REGISTRATION CONTAINER ----------------
        regContainer = new LinearLayout(this);
        regContainer.setOrientation(LinearLayout.VERTICAL);

        TextView welcome = text(editing ? "Edit Your Profile" : "Create Student Account", 20, navy, true);
        welcome.setGravity(Gravity.CENTER);
        regContainer.addView(welcome, lp(-1, -2));

        TextView subtitle = text(
                editing ? "Update your details or switch course" : "Quick setup without OTP • Set a password to login anytime",
                12, muted, false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subp = lp(-1, -2);
        subp.topMargin = dp(4);
        subp.bottomMargin = dp(14);
        regContainer.addView(subtitle, subp);

        // Compact Photo Card
        LinearLayout photoPanel = new LinearLayout(this);
        photoPanel.setOrientation(LinearLayout.HORIZONTAL);
        photoPanel.setGravity(Gravity.CENTER_VERTICAL);
        photoPanel.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable photoBg = hGradient(Color.rgb(238, 245, 255), Color.rgb(245, 240, 255), 18);
        photoBg.setStroke(dp(1), Color.rgb(208, 224, 252));
        photoPanel.setBackground(photoBg);

        FrameLayout avatarRing = new FrameLayout(this);
        avatarRing.setPadding(dp(3), dp(3), dp(3), dp(3));
        avatarRing.setBackground(hGradient(Color.rgb(245, 158, 11), blue, 40));

        photo = new ImageView(this);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setBackground(shape(Color.rgb(224, 236, 255), 36, Color.WHITE, 2));
        if (Build.VERSION.SDK_INT >= 21) photo.setClipToOutline(true);
        avatarRing.addView(photo, new FrameLayout.LayoutParams(dp(64), dp(64)));
        renderPhoto();

        LinearLayout.LayoutParams ringLp = lp(-2, -2);
        ringLp.rightMargin = dp(12);
        photoPanel.addView(avatarRing, ringLp);

        LinearLayout photoRight = new LinearLayout(this);
        photoRight.setOrientation(LinearLayout.VERTICAL);
        photoRight.addView(text("Profile Photo (Optional)", 14, ink, true));
        TextView photoSub = text("Saved only on your phone", 11, muted, false);
        LinearLayout.LayoutParams psubLp = lp(-1, -2);
        psubLp.topMargin = dp(2);
        psubLp.bottomMargin = dp(8);
        photoRight.addView(photoSub, psubLp);

        LinearLayout photoBtns = new LinearLayout(this);
        photoBtns.setOrientation(LinearLayout.HORIZONTAL);

        Button pick = new Button(this);
        pick.setText("Choose Photo");
        pick.setAllCaps(false);
        pick.setTextSize(12);
        pick.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        pick.setTextColor(Color.WHITE);
        pick.setPadding(dp(10), 0, dp(10), 0);
        pick.setBackground(hGradient(blue, Color.rgb(59, 130, 246), 18));
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(i, "Select profile photo"), SELECT_PHOTO);
        });
        LinearLayout.LayoutParams pickLp = new LinearLayout.LayoutParams(0, dp(34), 1.3f);
        pickLp.rightMargin = dp(6);
        photoBtns.addView(pick, pickLp);

        Button removeBtn = new Button(this);
        removeBtn.setText("Remove");
        removeBtn.setAllCaps(false);
        removeBtn.setTextSize(12);
        removeBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        removeBtn.setTextColor(Color.rgb(190, 24, 54));
        removeBtn.setPadding(dp(8), 0, dp(8), 0);
        removeBtn.setBackground(shape(Color.rgb(255, 235, 238), 18, Color.rgb(252, 165, 165), 1));
        removeBtn.setOnClickListener(v -> {
            new File(getFilesDir(), "sdkc_student_avatar.jpg").delete();
            renderPhoto();
        });
        LinearLayout.LayoutParams remLp = new LinearLayout.LayoutParams(0, dp(34), 0.9f);
        photoBtns.addView(removeBtn, remLp);

        photoRight.addView(photoBtns, lp(-1, -2));
        photoPanel.addView(photoRight, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout.LayoutParams phlp = lp(-1, -2);
        phlp.bottomMargin = dp(14);
        regContainer.addView(photoPanel, phlp);

        // Full Name
        regContainer.addView(fieldLabel("Full Name *"));
        name = input("Enter your full name", sp.getString("name", ""),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        regContainer.addView(badgedInput("👤", Color.rgb(219, 234, 254), blue, name), lp(-1, 50));

        regContainer.addView(new View(this), lp(1, 10));

        // Mobile Number
        regContainer.addView(fieldLabel("Mobile Number *"));
        phone = input("Enter 10-digit mobile number", sp.getString("mobile", ""),
                InputType.TYPE_CLASS_NUMBER);
        phone.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        regContainer.addView(badgedInput("+91", Color.rgb(209, 250, 229), Color.rgb(4, 120, 87), phone), lp(-1, 50));

        if (!editing) {
            regContainer.addView(new View(this), lp(1, 10));
            regContainer.addView(fieldLabel("Create Password * (Min 6 characters)"));
            passwordField = input("Enter password", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            regContainer.addView(passwordInput(passwordField), lp(-1, 50));

            regContainer.addView(new View(this), lp(1, 10));
            regContainer.addView(fieldLabel("Confirm Password *"));
            confirmPasswordField = input("Re-enter password", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            regContainer.addView(passwordInput(confirmPasswordField), lp(-1, 50));
        }

        regContainer.addView(new View(this), lp(1, 12));

        // Course Selection (6 Options)
        regContainer.addView(fieldLabel("Select Course / Class *"));
        LinearLayout courseBox = new LinearLayout(this);
        courseBox.setOrientation(LinearLayout.VERTICAL);
        courseBox.setPadding(dp(10), dp(10), dp(10), dp(10));
        courseBox.setBackground(shape(Color.rgb(255, 251, 235), 16, Color.rgb(245, 158, 11), 1));
        courseButtons.clear();

        for (int i = 0; i < COURSES.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = 0; j < 2 && (i + j) < COURSES.length; j++) {
                final String cName = COURSES[i + j];
                Button cb = new Button(this);
                cb.setText(cName);
                cb.setAllCaps(false);
                cb.setTextSize(12);
                cb.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                cb.setPadding(dp(6), 0, dp(6), 0);
                cb.setOnClickListener(v -> {
                    selectedCourse = cName;
                    refreshCourseButtons();
                });
                courseButtons.add(cb);
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, dp(40), 1f);
                if (j == 0) clp.rightMargin = dp(8);
                row.addView(cb, clp);
            }
            LinearLayout.LayoutParams rlp = lp(-1, -2);
            if (i + 2 < COURSES.length) rlp.bottomMargin = dp(8);
            courseBox.addView(row, rlp);
        }
        refreshCourseButtons();
        regContainer.addView(courseBox, lp(-1, -2));

        regContainer.addView(new View(this), lp(1, 16));

        saveBtn = new Button(this);
        saveBtn.setText(editing ? "✓  Save Changes" : "Create Account & Start  ➜");
        saveBtn.setAllCaps(false);
        saveBtn.setTextSize(15);
        saveBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        saveBtn.setTextColor(Color.WHITE);
        saveBtn.setBackground(hGradient(blue, Color.rgb(109, 40, 217), 16));
        if (Build.VERSION.SDK_INT >= 21) saveBtn.setElevation(dp(4));
        regContainer.addView(saveBtn, lp(-1, 52));
        saveBtn.setOnClickListener(v -> save());

        if (editing) {
            TextView back = text("Back to Home", 14, blue, true);
            back.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams backp = lp(-1, 42);
            backp.topMargin = dp(6);
            regContainer.addView(back, backp);
            back.setOnClickListener(v -> finish());
        }

        card.addView(regContainer, lp(-1, -2));

        // ---------------- LOGIN CONTAINER ----------------
        if (!editing) {
            loginContainer = new LinearLayout(this);
            loginContainer.setOrientation(LinearLayout.VERTICAL);
            loginContainer.setVisibility(View.GONE);

            TextView lw = text("Welcome Back!", 21, navy, true);
            lw.setGravity(Gravity.CENTER);
            loginContainer.addView(lw, lp(-1, -2));

            TextView ls = text("Login with your registered mobile & password", 13, muted, false);
            ls.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lsp = lp(-1, -2);
            lsp.topMargin = dp(5);
            lsp.bottomMargin = dp(18);
            loginContainer.addView(ls, lsp);

            loginContainer.addView(fieldLabel("Mobile Number *"));
            loginPhone = input("Enter 10-digit mobile number", "", InputType.TYPE_CLASS_NUMBER);
            loginPhone.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
            loginContainer.addView(badgedInput("+91", Color.rgb(209, 250, 229), Color.rgb(4, 120, 87), loginPhone), lp(-1, 52));

            loginContainer.addView(new View(this), lp(1, 12));

            loginContainer.addView(fieldLabel("Password *"));
            loginPassword = input("Enter your password", "", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            loginContainer.addView(passwordInput(loginPassword), lp(-1, 52));

            TextView lInfo = text("No OTP needed • Restores your Name & Course automatically", 11, Color.rgb(15, 118, 110), true);
            lInfo.setGravity(Gravity.CENTER);
            lInfo.setPadding(dp(10), dp(10), dp(10), dp(10));
            lInfo.setBackground(shape(Color.rgb(236, 253, 245), 14, Color.rgb(167, 243, 208), 1));
            LinearLayout.LayoutParams liLp = lp(-1, -2);
            liLp.topMargin = dp(16);
            liLp.bottomMargin = dp(18);
            loginContainer.addView(lInfo, liLp);

            loginBtn = new Button(this);
            loginBtn.setText("Login to Classes  ➜");
            loginBtn.setAllCaps(false);
            loginBtn.setTextSize(16);
            loginBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            loginBtn.setTextColor(Color.WHITE);
            loginBtn.setBackground(hGradient(blue, Color.rgb(109, 40, 217), 16));
            if (Build.VERSION.SDK_INT >= 21) loginBtn.setElevation(dp(4));
            loginContainer.addView(loginBtn, lp(-1, 54));
            loginBtn.setOnClickListener(v -> performLogin());

            TextView switchHint = text("New student? Tap 'New Registration' above", 12, blue, true);
            switchHint.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams shLp = lp(-1, 40);
            shLp.topMargin = dp(10);
            loginContainer.addView(switchHint, shLp);
            switchHint.setOnClickListener(v -> switchMode(false));

            card.addView(loginContainer, lp(-1, -2));
            switchMode(false);
        }

        page.addView(card, lp(-1, -2));

        TextView footer = text("SMART DK CLASSES  •  Learn • Practice • Succeed", 11, Color.rgb(112, 130, 159), true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = lp(-1, -2);
        fp.topMargin = dp(14);
        page.addView(footer, fp);

        root.addView(page, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        scroll.addView(root);
        setContentView(scroll);
    }

    private void switchMode(boolean toLogin) {
        loginMode = toLogin;
        if (regContainer != null) regContainer.setVisibility(toLogin ? View.GONE : View.VISIBLE);
        if (loginContainer != null) loginContainer.setVisibility(toLogin ? View.VISIBLE : View.GONE);
        if (tabRegBtn != null && tabLoginBtn != null) {
            if (toLogin) {
                tabRegBtn.setBackground(null);
                tabRegBtn.setTextColor(ink);
                tabLoginBtn.setBackground(shape(blue, 12, blue, 0));
                tabLoginBtn.setTextColor(Color.WHITE);
            } else {
                tabRegBtn.setBackground(shape(blue, 12, blue, 0));
                tabRegBtn.setTextColor(Color.WHITE);
                tabLoginBtn.setBackground(null);
                tabLoginBtn.setTextColor(ink);
            }
        }
    }

    private LinearLayout passwordInput(final EditText field) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(4), dp(8), dp(4));
        row.setBackground(shape(Color.rgb(248, 251, 255), 14, Color.rgb(190, 212, 248), 1));

        row.addView(field, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        final TextView toggle = text("Show", 12, blue, true);
        toggle.setPadding(dp(10), dp(6), dp(10), dp(6));
        toggle.setOnClickListener(v -> {
            boolean hidden = (field.getInputType() & InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
                    != InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;
            if (hidden) {
                field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                toggle.setText("Hide");
            } else {
                field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                toggle.setText("Show");
            }
            field.setSelection(field.getText().length());
        });
        row.addView(toggle, lp(-2, -2));
        return row;
    }

    private void refreshCourseButtons() {
        for (int i = 0; i < courseButtons.size(); i++) {
            Button cb = courseButtons.get(i);
            String label = COURSES[i];
            boolean selected = label.equalsIgnoreCase(selectedCourse);
            if (selected) {
                cb.setBackground(shape(blue, 12, blue, 1));
                cb.setTextColor(Color.WHITE);
            } else {
                cb.setBackground(shape(Color.WHITE, 12, Color.rgb(190, 212, 248), 1));
                cb.setTextColor(ink);
            }
        }
    }

    private TextView fieldLabel(String s) {
        TextView t = text(s, 13, ink, true);
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.bottomMargin = dp(5);
        t.setLayoutParams(p);
        return t;
    }

    private EditText input(String hint, String value, int type) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextSize(14);
        e.setTextColor(ink);
        e.setHintTextColor(Color.rgb(135, 151, 176));
        e.setHint(hint);
        e.setInputType(type);
        e.setText(value);
        e.setBackground(null);
        e.setPadding(dp(10), 0, dp(10), 0);
        return e;
    }

    private LinearLayout badgedInput(String badgeText, int badgeBg, int badgeFg, EditText field) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(5), dp(6), dp(5));
        row.setBackground(shape(Color.rgb(248, 251, 255), 14, Color.rgb(190, 212, 248), 1));

        TextView badge = text(badgeText, 13, badgeFg, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(shape(badgeBg, 10, 0, 0));
        row.addView(badge, lp(42, 36));
        row.addView(field, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        return row;
    }

    private void renderPhoto() {
        try {
            Bitmap b = BitmapFactory.decodeFile(new File(getFilesDir(), "sdkc_student_avatar.jpg").getAbsolutePath());
            if (b != null) {
                photo.setImageBitmap(b);
                return;
            }
        } catch (Exception ignored) {}
        photo.setImageResource(android.R.drawable.ic_menu_camera);
    }

    @Override
    protected void onActivityResult(int r, int c, Intent data) {
        super.onActivityResult(r, c, data);
        if (r != SELECT_PHOTO || c != RESULT_OK || data == null) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            Bitmap original = BitmapFactory.decodeStream(in);
            if (original == null) throw new Exception("Invalid picture");
            int max = 320;
            float scale = Math.min(1f, (float) max / Math.max(original.getWidth(), original.getHeight()));
            Bitmap small = Bitmap.createScaledBitmap(
                    original,
                    Math.max(1, (int) (original.getWidth() * scale)),
                    Math.max(1, (int) (original.getHeight() * scale)),
                    true);
            try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "sdkc_student_avatar.jpg"))) {
                small.compress(Bitmap.CompressFormat.JPEG, 80, out);
            }
            renderPhoto();
        } catch (Exception e) {
            Toast.makeText(this, "Photo नहीं चुनी जा सकी।", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (!editing && !prefs(this).getBoolean("initialized", false)) finishAffinity();
        else super.onBackPressed();
    }

    private void save() {
        final String n = name.getText().toString().trim();
        final String m = phone.getText().toString().trim();
        if (n.length() < 2) {
            name.setError("Please enter your name");
            return;
        }
        if (!m.matches("[0-9]{10}")) {
            phone.setError("Enter a 10-digit mobile number");
            return;
        }
        if (editing) {
            SharedPreferences sp = prefs(this);
            String id = sp.getString("profile_id", "");
            String token = sp.getString("profile_token", "");
            if (id.isEmpty()) id = UUID.randomUUID().toString();
            if (token.isEmpty()) token = UUID.randomUUID().toString();
            sp.edit()
                    .putString("name", n)
                    .putString("mobile", m)
                    .putString("course", selectedCourse)
                    .putString("profile_id", id)
                    .putString("profile_token", token)
                    .putBoolean("share", true)
                    .putBoolean("initialized", true)
                    .apply();
            ProfileSync.sync(this);
            setResult(RESULT_OK);
            finish();
            return;
        }

        final String pw = passwordField.getText().toString();
        final String cpw = confirmPasswordField.getText().toString();
        if (pw.length() < 6) {
            passwordField.setError("Password must be at least 6 characters");
            return;
        }
        if (!pw.equals(cpw)) {
            confirmPasswordField.setError("Passwords do not match");
            return;
        }

        final SharedPreferences sp = prefs(this);
        String existingId = sp.getString("profile_id", "");
        String existingToken = sp.getString("profile_token", "");
        final String id = existingId.isEmpty() ? UUID.randomUUID().toString() : existingId;
        final String token = existingToken.isEmpty() ? UUID.randomUUID().toString() : existingToken;

        saveBtn.setEnabled(false);
        saveBtn.setText("Creating Account...");
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("p_id", id);
                body.put("p_token", token);
                body.put("p_name", n);
                body.put("p_mobile", m);
                body.put("p_password", pw);
                body.put("p_course", selectedCourse);
                JSONObject res = callRpc("sdkc_register_student", body);
                boolean ok = res.optBoolean("ok", false);
                runOnUiThread(() -> {
                    saveBtn.setEnabled(true);
                    saveBtn.setText("Create Account & Start  ➜");
                    if (!ok) {
                        String err = res.optString("error", "Registration failed. Please try again.");
                        Toast.makeText(this, err, Toast.LENGTH_LONG).show();
                        return;
                    }
                    sp.edit()
                            .putString("name", n)
                            .putString("mobile", m)
                            .putString("course", selectedCourse)
                            .putString("profile_id", id)
                            .putString("profile_token", token)
                            .putBoolean("share", true)
                            .putBoolean("initialized", true)
                            .apply();
                    setResult(RESULT_OK);
                    finish();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    saveBtn.setEnabled(true);
                    saveBtn.setText("Create Account & Start  ➜");
                    Toast.makeText(this, "इंटरनेट की जाँच करें और दोबारा कोशिश करें।", Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void performLogin() {
        final String m = loginPhone.getText().toString().trim();
        final String pw = loginPassword.getText().toString();
        if (!m.matches("[0-9]{10}")) {
            loginPhone.setError("Enter a 10-digit mobile number");
            return;
        }
        if (pw.length() < 6) {
            loginPassword.setError("Enter your password (min 6 chars)");
            return;
        }
        loginBtn.setEnabled(false);
        loginBtn.setText("Logging in...");
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("p_mobile", m);
                body.put("p_password", pw);
                JSONObject res = callRpc("sdkc_login_student", body);
                boolean ok = res.optBoolean("ok", false);
                runOnUiThread(() -> {
                    loginBtn.setEnabled(true);
                    loginBtn.setText("Login to Classes  ➜");
                    if (!ok) {
                        String err = res.optString("error", "मोबाइल नंबर या पासवर्ड गलत है");
                        Toast.makeText(this, err, Toast.LENGTH_LONG).show();
                        return;
                    }
                    prefs(this).edit()
                            .putString("name", res.optString("name", "Student"))
                            .putString("mobile", res.optString("mobile", m))
                            .putString("course", res.optString("course", "All Courses"))
                            .putString("profile_id", res.optString("id", UUID.randomUUID().toString()))
                            .putString("profile_token", res.optString("token", UUID.randomUUID().toString()))
                            .putBoolean("share", true)
                            .putBoolean("initialized", true)
                            .apply();
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    loginBtn.setEnabled(true);
                    loginBtn.setText("Login to Classes  ➜");
                    Toast.makeText(this, "इंटरनेट की जाँच करें और दोबारा कोशिश करें।", Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private JSONObject callRpc(String rpcName, JSONObject payload) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(ContentRepository.SUPABASE_URL + "/rest/v1/rpc/" + rpcName);
            conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(15000);
            conn.setRequestProperty("apikey", ContentRepository.SUPABASE_KEY);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            StringBuilder sb = new StringBuilder();
            if (stream != null) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }
            }
            if (code < 200 || code >= 300) {
                throw new Exception("Server error (" + code + ")");
            }
            return new JSONObject(sb.toString());
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
