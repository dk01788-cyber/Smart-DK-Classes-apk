-- Smart DK Classes v1.5.7 — No-OTP Registration & Password Login
-- Run ONCE in Supabase > SQL Editor.

begin;

alter table public.sdkc_student_profiles
  add column if not exists password_hash text,
  add column if not exists course text default 'All Courses';

create or replace function public.sdkc_register_student(
  p_id uuid,
  p_token uuid,
  p_name text,
  p_mobile text,
  p_password text,
  p_course text default 'All Courses'
) returns jsonb
language plpgsql volatile security definer set search_path to '' as $$
declare
  n text := btrim(coalesce(p_name, ''));
  m text := btrim(coalesce(p_mobile, ''));
  pw text := coalesce(p_password, '');
  c text := coalesce(nullif(btrim(p_course), ''), 'All Courses');
  p_hash text;
  existing_id uuid;
begin
  if p_id is null or p_token is null then
    return jsonb_build_object('ok', false, 'error', 'Invalid profile key');
  end if;
  if char_length(n) < 2 or char_length(n) > 60 then
    return jsonb_build_object('ok', false, 'error', 'कृपया सही नाम लिखें (2-60 अक्षर)');
  end if;
  if m !~ '^[0-9]{10}$' then
    return jsonb_build_object('ok', false, 'error', 'कृपया 10 अंकों का सही मोबाइल नंबर लिखें');
  end if;
  if char_length(pw) < 6 then
    return jsonb_build_object('ok', false, 'error', 'पासवर्ड कम से कम 6 अक्षर/अंक का रखें');
  end if;

  p_hash := md5(m || ':' || pw || ':sdkc_v1');

  select id into existing_id
  from public.sdkc_student_profiles
  where mobile = m and password_hash is not null
  limit 1;

  if existing_id is not null and existing_id <> p_id then
    return jsonb_build_object('ok', false, 'error', 'यह मोबाइल नंबर पहले से रजिस्टर्ड है। कृपया Login टैब से लॉग इन करें।');
  end if;

  insert into public.sdkc_student_profiles(id, token_hash, display_name, mobile, password_hash, course)
  values(p_id, md5(p_token::text), n, m, p_hash, c)
  on conflict(id) do update
    set display_name = excluded.display_name,
        mobile = excluded.mobile,
        password_hash = excluded.password_hash,
        course = excluded.course,
        updated_at = now()
    where public.sdkc_student_profiles.token_hash = excluded.token_hash;

  return jsonb_build_object('ok', true, 'id', p_id, 'name', n, 'mobile', m, 'course', c);
end;
$$;

revoke all on function public.sdkc_register_student(uuid,uuid,text,text,text,text) from public;
grant execute on function public.sdkc_register_student(uuid,uuid,text,text,text,text) to anon, authenticated;

create or replace function public.sdkc_login_student(
  p_mobile text,
  p_password text
) returns jsonb
language plpgsql volatile security definer set search_path to '' as $$
declare
  m text := btrim(coalesce(p_mobile, ''));
  pw text := coalesce(p_password, '');
  p_hash text;
  rec record;
  new_token uuid := gen_random_uuid();
begin
  if m !~ '^[0-9]{10}$' or char_length(pw) < 6 then
    return jsonb_build_object('ok', false, 'error', 'कृपया सही 10-अंक मोबाइल नंबर और पासवर्ड डालें');
  end if;

  p_hash := md5(m || ':' || pw || ':sdkc_v1');

  select id, display_name, mobile, coalesce(nullif(btrim(course), ''), 'All Courses') as course
  into rec
  from public.sdkc_student_profiles
  where mobile = m and password_hash = p_hash
  order by updated_at desc nulls last, created_at desc
  limit 1;

  if rec.id is null then
    return jsonb_build_object('ok', false, 'error', 'मोबाइल नंबर या पासवर्ड गलत है');
  end if;

  update public.sdkc_student_profiles
  set token_hash = md5(new_token::text), updated_at = now()
  where id = rec.id;

  return jsonb_build_object(
    'ok', true,
    'id', rec.id,
    'token', new_token,
    'name', rec.display_name,
    'mobile', rec.mobile,
    'course', rec.course
  );
end;
$$;

revoke all on function public.sdkc_login_student(text,text) from public;
grant execute on function public.sdkc_login_student(text,text) to anon, authenticated;

commit;
