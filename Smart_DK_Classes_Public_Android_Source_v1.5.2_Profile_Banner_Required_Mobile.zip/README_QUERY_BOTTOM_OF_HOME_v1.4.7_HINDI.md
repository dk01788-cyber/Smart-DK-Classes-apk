# Smart DK Classes Public App v1.4.7 — Home पर नीचे Query Form

- Query नाम का अलग Bottom Menu / QueryActivity हटा दिया गया है।
- Home पर Selected Video Classes के नीचे स्क्रॉल करने से **अपना प्रश्न पूछें** Form दिखाई देता है।
- Form: नाम और प्रश्न आवश्यक; Email और Mobile दोनों optional।
- Form सीधे Supabase public.sdkc_student_queries में INSERT करता है। Public को दूसरों के प्रश्न देखने की अनुमति नहीं है।
- Admin App v1.4.2 Query Inbox जस का तस उपयोग होगा; दोबारा Admin Source बदलने की जरूरत नहीं।
- Content Auto-Refresh, Google Play In-App Update, API 36 और अन्य Public App सुविधाएँ यथावत।
- app versionName 1.4.7; versionCode 23; package com.smartdkclasses.app।
- APK/AAB का वास्तविक Build और मोबाइल पर परीक्षण बाकी है।
