package com.smartdkclasses.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.UUID;
import org.json.JSONObject;

/** Profile form with explicit data notice; name/mobile sync to Admin, photo remains local. */
public final class StudentProfileActivity extends Activity {
    public static final String PREF = "sdkc_student_profile_v1";
    private static final int SELECT_PHOTO=7001;
    private final int blue=Color.rgb(7,91,216);
    private EditText name, phone;
    private ImageView photo;
    private boolean editing;
    public static SharedPreferences prefs(Activity a){return a.getSharedPreferences(PREF,MODE_PRIVATE);}
    public static String currentName(Activity a){return prefs(a).getString("name","");}
    public static String currentPhoto(Activity a){
       try {File f=new File(a.getFilesDir(),"sdkc_student_avatar.jpg");if(!f.exists())return "";
         try(InputStream in=new java.io.FileInputStream(f)){
           byte[] buff=new byte[(int)Math.min(f.length(),100000)];int pos=0,n;
           while(pos<buff.length&&(n=in.read(buff,pos,buff.length-pos))>0)pos+=n;
           return "data:image/jpeg;base64,"+Base64.encodeToString(buff,0,pos,Base64.NO_WRAP);
         }
       }catch(Exception ex){return "";}
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(blue);
        editing=getIntent().getBooleanExtra("edit",false);draw();}
    private TextView label(String s,int size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(Color.rgb(20,50,80));return v;}
    private void draw(){SharedPreferences sp=prefs(this);
      ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(244,248,253));
      LinearLayout lay=new LinearLayout(this);lay.setOrientation(LinearLayout.VERTICAL);lay.setPadding(dp(22),dp(30),dp(22),dp(35));
      TextView title=label(editing?"My Profile":"Welcome to Smart DK Classes 👋",24);title.setTextColor(blue);title.setGravity(Gravity.CENTER);lay.addView(title);
      TextView sub=label(editing?"Edit your details anytime":"Set your profile once to personalize Home and Mock Test Result.",14);sub.setGravity(Gravity.CENTER);lay.addView(sub);
      photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setBackgroundColor(Color.rgb(225,237,250));
      LinearLayout.LayoutParams picp=new LinearLayout.LayoutParams(dp(100),dp(100));picp.gravity=Gravity.CENTER;picp.topMargin=dp(20);lay.addView(photo,picp);renderPhoto();
      Button pick=new Button(this);pick.setText("Add / Change Photo");pick.setAllCaps(false);lay.addView(pick);pick.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(i,"Select profile photo"),SELECT_PHOTO);});
      Button remove=new Button(this);remove.setText("Remove Photo");remove.setAllCaps(false);lay.addView(remove);remove.setOnClickListener(v->{new File(getFilesDir(),"sdkc_student_avatar.jpg").delete();renderPhoto();});
      lay.addView(label("Your Name *",15));name=new EditText(this);name.setSingleLine(true);name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(60)});name.setHint("Enter your name");name.setText(sp.getString("name",""));lay.addView(name);
      lay.addView(label("Mobile Number *",15));phone=new EditText(this);phone.setSingleLine(true);phone.setInputType(InputType.TYPE_CLASS_PHONE);phone.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});phone.setHint("Enter 10-digit mobile number");phone.setText(sp.getString("mobile",""));lay.addView(phone);
      TextView small=label("No OTP • No Login • Photo is optional and stays on this phone.",12);lay.addView(small);
      TextView notice=label("By tapping Continue, you agree that your name and mobile number will be saved in Smart DK Classes Admin so your profile and Mock Test results can be shown. No OTP verification is used.",13);notice.setPadding(dp(12),dp(12),dp(12),dp(12));notice.setBackgroundColor(Color.rgb(226,240,255));lay.addView(notice);
      Button save=new Button(this);save.setText(editing?"Save Changes":"Continue");save.setTextColor(Color.WHITE);save.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));lay.addView(save);save.setOnClickListener(v->save());
      if(editing){Button back=new Button(this);back.setText("Back to Home");lay.addView(back);back.setOnClickListener(v->finish());}
      scroll.addView(lay);setContentView(scroll);
    }
    private int dp(int px){return Math.round(px*getResources().getDisplayMetrics().density);}
    private void renderPhoto(){try{Bitmap b=BitmapFactory.decodeFile(new File(getFilesDir(),"sdkc_student_avatar.jpg").getAbsolutePath());if(b!=null){photo.setImageBitmap(b);return;}}catch(Exception ignored){}photo.setImageResource(android.R.drawable.ic_menu_camera);}
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r!=SELECT_PHOTO||c!=RESULT_OK||data==null)return;
       try(InputStream in=getContentResolver().openInputStream(data.getData())){
         Bitmap original=BitmapFactory.decodeStream(in);if(original==null)throw new Exception("Invalid picture");
         int max=320;float scale=Math.min(1f,(float)max/Math.max(original.getWidth(),original.getHeight()));
         Bitmap small=Bitmap.createScaledBitmap(original,Math.max(1,(int)(original.getWidth()*scale)),Math.max(1,(int)(original.getHeight()*scale)),true);
         try(FileOutputStream out=new FileOutputStream(new File(getFilesDir(),"sdkc_student_avatar.jpg"))){small.compress(Bitmap.CompressFormat.JPEG,80,out);}
         renderPhoto();
       }catch(Exception e){Toast.makeText(this,"Photo नहीं चुनी जा सकी।",Toast.LENGTH_SHORT).show();}
    }
    @Override public void onBackPressed(){if(!editing && !prefs(this).getBoolean("initialized",false))finishAffinity();else super.onBackPressed();}
    private void save(){String n=name.getText().toString().trim(),m=phone.getText().toString().trim();
      if(n.length()<2){name.setError("Please enter your name");return;}
      if(!m.matches("[0-9]{10}")){phone.setError("Enter a 10-digit mobile number");return;}
      SharedPreferences sp=prefs(this);String id=sp.getString("profile_id","");String token=sp.getString("profile_token","");
      if(id.isEmpty())id=UUID.randomUUID().toString();if(token.isEmpty())token=UUID.randomUUID().toString();
      sp.edit().putString("name",n).putString("mobile",m).putString("profile_id",id).putString("profile_token",token).putBoolean("share",true).putBoolean("initialized",true).apply();
      // The notice above explains that name/mobile are sent to the Admin profile list. Photo stays local.
      ProfileSync.sync(this);setResult(RESULT_OK);finish();
    }
}
