package com.smartdkclasses.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Native exam-folder browser. Quiz/instant result/review remains in the shared secure WebView page. */
public final class MockTestFoldersActivity extends Activity {
    private static final int BLUE=Color.rgb(7,91,216);
    private static final int BG=Color.rgb(244,248,253);
    private static final int TEXT=Color.rgb(16,35,63);
    private static final int MUTED=Color.rgb(103,123,146);
    private static final int BORDER=Color.rgb(222,233,244);
    private final List<Folder> folders=new ArrayList<>();
    private final List<MockTest> tests=new ArrayList<>();
    private final List<String> trail=new ArrayList<>();
    private final Map<String,Folder> byId=new HashMap<>();
    private LinearLayout page;
    private String hubId=null;
    private String currentFolder=null;

    static final class Folder {
        String id,title,parentId,type,bgMode,bgColor,gradientColor;
        int position;
        static Folder fromJson(JSONObject o){
            Folder f=new Folder();
            f.id=o.optString("id",""); f.title=o.optString("title","Folder");
            f.parentId=o.optString("parent_id",""); f.type=o.optString("card_type","");
            f.position=o.optInt("sort_order",999);
            f.bgMode=o.optString("background_mode","solid");
            f.bgColor=o.optString("background_color","");
            f.gradientColor=o.optString("gradient_color","");
            return f;
        }
    }
    static final class MockTest {
        String id,title,description,cardId;
        int duration,position;
        static MockTest fromJson(JSONObject o){
            MockTest t=new MockTest();
            t.id=o.optString("id","");t.title=o.optString("title","Mock Test");
            t.description=o.optString("description","");t.cardId=o.optString("card_id","");
            t.duration=o.optInt("duration_minutes",0);t.position=o.optInt("sort_order",999);
            return t;
        }
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BLUE);
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        page=new LinearLayout(this);
        page.setPadding(dp(16),dp(14),dp(16),dp(22));
        page.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(page);
        setContentView(scroll);
        showMessage("Mock Tests लोड हो रहे हैं…", false);
        load();
    }
    private static boolean validId(String s){return s!=null&&s.matches("(?i)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}");}
    private int dp(int value){return Math.round(getResources().getDisplayMetrics().density*value);}
    private GradientDrawable shape(int color){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(14));
        d.setStroke(dp(1),BORDER);return d;
    }
    private TextView text(String value,int size,int color,boolean bold){
        TextView v=new TextView(this);v.setText(value);v.setTextColor(color);v.setTextSize(size);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return v;
    }
    private LinearLayout column(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);return c;}
    private void gap(int space){View v=new View(this);page.addView(v,new LinearLayout.LayoutParams(1,dp(space)));}
    private void showMessage(String message,boolean retry){
        page.removeAllViews();
        TextView back=text("‹  वापस",16,BLUE,true);back.setPadding(0,dp(12),0,dp(20));back.setOnClickListener(v->finish());page.addView(back);
        TextView title=text("📝  Mock Test",23,TEXT,true);page.addView(title);gap(16);
        TextView txt=text(message,15,MUTED,false);page.addView(txt);
        if(retry){gap(12);Button b=new Button(this);b.setText("दोबारा प्रयास करें");b.setOnClickListener(v->{showMessage("Mock Tests लोड हो रहे हैं…",false);load();});page.addView(b);}
    }
    private static String readJson(String endpoint) throws Exception {
        HttpURLConnection conn=null;
        try {
            conn=(HttpURLConnection)new URL(endpoint).openConnection();
            conn.setRequestMethod("GET");conn.setConnectTimeout(15000);conn.setReadTimeout(20000);
            conn.setRequestProperty("apikey",ContentRepository.SUPABASE_KEY);
            conn.setRequestProperty("Accept","application/json");
            conn.setRequestProperty("Cache-Control","no-cache, no-store");
            conn.setUseCaches(false);
            int http=conn.getResponseCode();
            InputStream input=http>=200&&http<300?conn.getInputStream():conn.getErrorStream();
            StringBuilder sb=new StringBuilder();
            if(input!=null)try(BufferedReader reader=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8))){String line;while((line=reader.readLine())!=null)sb.append(line);}
            if(http<200||http>=300)throw new Exception("Server response "+http);
            return sb.toString();
        } finally {if(conn!=null)conn.disconnect();}
    }
    private void load(){
        new Thread(()->{
            try{
                String base=ContentRepository.SUPABASE_URL+"/rest/v1/";
                JSONArray rows=new JSONArray(readJson(base+"sdkc_cards?select=id,title,parent_id,card_type,sort_order,background_mode,background_color,gradient_color&is_published=eq.true&card_type=in.(mock-hub,folder)&order=sort_order.asc&limit=1000"));
                JSONArray examRows=new JSONArray(readJson(base+"sdkc_mock_tests?select=id,title,description,card_id,duration_minutes,sort_order&is_published=eq.true&order=sort_order.asc&limit=1000"));
                List<Folder> newFolders=new ArrayList<>();Map<String,Folder> newMap=new HashMap<>();String selectedHub=null;
                for(int i=0;i<rows.length();i++){
                    Folder f=Folder.fromJson(rows.getJSONObject(i));
                    if(!validId(f.id))continue;
                    newFolders.add(f);newMap.put(f.id,f);
                    if("mock-hub".equals(f.type) && (selectedHub==null||f.parentId.isEmpty()))selectedHub=f.id;
                }
                List<MockTest> newTests=new ArrayList<>();
                for(int i=0;i<examRows.length();i++){
                    MockTest t=MockTest.fromJson(examRows.getJSONObject(i));
                    if(validId(t.id))newTests.add(t);
                }
                final String hub=selectedHub;
                runOnUiThread(()->{
                    if(isFinishing()||isDestroyed())return;
                    hubId=hub;folders.clear();folders.addAll(newFolders);byId.clear();byId.putAll(newMap);
                    tests.clear();tests.addAll(newTests);render();
                });
            }catch(Exception e){runOnUiThread(()->{if(!isFinishing())showMessage("Mock Tests नहीं खुल सके। इंटरनेट कनेक्शन जाँचें।",true);});}
        }).start();
    }
    private boolean insideHub(String cardId){
        if(!validId(cardId)||hubId==null)return false;
        Set<String> seen=new HashSet<>();Folder f=byId.get(cardId);
        while(f!=null&&seen.add(f.id)){
            if(hubId.equals(f.parentId))return true;
            f=byId.get(f.parentId);
        }
        return false;
    }
    private List<Folder> children(String id){
        List<Folder> result=new ArrayList<>();
        for(Folder f:folders)if("folder".equals(f.type)&&id!=null&&id.equals(f.parentId))result.add(f);
        Collections.sort(result,Comparator.comparingInt((Folder f)->f.position).thenComparing(f->f.title));
        return result;
    }
    private List<MockTest> testsIn(String folder){
        List<MockTest> result=new ArrayList<>();
        for(MockTest t:tests){
            boolean assigned=insideHub(t.cardId);
            if(folder==null){if(!assigned && !hubIdEquals(t.cardId))result.add(t);}
            else if(folder.equals(t.cardId))result.add(t);
        }
        Collections.sort(result,Comparator.comparingInt((MockTest t)->t.position).thenComparing(t->t.title));
        return result;
    }
    private boolean hubIdEquals(String id){return hubId!=null&&hubId.equals(id);}
    private int descendantCount(String id,Set<String> seen){
        if(!seen.add(id))return 0;
        int total=testsIn(id).size();
        for(Folder child:children(id))total+=descendantCount(child.id,seen);
        return total;
    }
    private void render(){
        if(hubId==null){showMessage("Mock Test सेक्शन अभी उपलब्ध नहीं है।",true);return;}
        page.removeAllViews();
        final boolean atRoot=currentFolder==null;
        TextView back=text("‹  "+(atRoot?"Home":"सभी परीक्षाएँ"),16,BLUE,true);
        back.setPadding(dp(3),dp(10),dp(3),dp(18));
        back.setOnClickListener(v->onBackPressed());page.addView(back);
        Folder selected=byId.get(currentFolder);
        TextView header=text(atRoot?"📝  Mock Test": "📁  "+(selected==null?"अन्य Mock Tests":selected.title),23,TEXT,true);
        page.addView(header);gap(6);
        TextView sub=text(atRoot?"परीक्षा चुनें और अपना Mock Test शुरू करें।":"कोई Set चुनें। Final Submit के बाद Result और Answer Review मिलेगा।",14,MUTED,false);
        page.addView(sub);gap(18);
        if(atRoot){
            List<Folder> top=children(hubId);
            for(Folder f:top)addFolder(f,descendantCount(f.id,new HashSet<>()));
            List<MockTest> uncategorized=testsIn(null);
            // These tests were published before folders existed: never hide them.
            uncategorized.addAll(testsIn(hubId));
            if(!uncategorized.isEmpty())addOther(uncategorized.size());
            if(top.isEmpty()&&uncategorized.isEmpty()){
                page.addView(text("अभी कोई प्रकाशित Mock Test नहीं है।",14,MUTED,false));
            }
        }else if("other".equals(currentFolder)){
            List<MockTest> misc=testsIn(null);misc.addAll(testsIn(hubId));
            if(misc.isEmpty())page.addView(text("इस फोल्डर में कोई Test नहीं है।",14,MUTED,false));
            for(MockTest t:misc)addTest(t);
        }else if(selected!=null && insideHub(selected.id)){
            for(Folder f:children(selected.id))addFolder(f,descendantCount(f.id,new HashSet<>()));
            List<MockTest> current=testsIn(selected.id);
            for(MockTest t:current)addTest(t);
            if(children(selected.id).isEmpty()&&current.isEmpty())page.addView(text("इस फोल्डर में अभी कोई प्रकाशित Test नहीं है।",14,MUTED,false));
        }else{currentFolder=null;render();}
    }
    private void push(String folder){trail.add(folder);currentFolder=folder;render();}
    private void addOther(int count){
        LinearLayout card=cardContainer();
        card.addView(text("📂  अन्य Mock Tests",18,TEXT,true));
        TextView info=text(count+" टेस्ट · सेट देखें →",13,MUTED,false);info.setPadding(0,dp(6),0,0);card.addView(info);
        card.setOnClickListener(v->push("other"));page.addView(card);gap(12);
    }
    private void addFolder(Folder folder,int count){
        LinearLayout card=cardContainer();
        card.addView(text("📁  "+folder.title,18,TEXT,true));
        TextView info=text(count+" टेस्ट · सेट देखें →",13,MUTED,false);info.setPadding(0,dp(8),0,0);card.addView(info);
        // Preserve custom gradient / solid section styling where configured.
        if("gradient".equals(folder.bgMode)&&colorValid(folder.bgColor)&&colorValid(folder.gradientColor)){
            GradientDrawable gd=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.parseColor(folder.bgColor),Color.parseColor(folder.gradientColor)});
            gd.setCornerRadius(dp(14));card.setBackground(gd);
            for(int i=0;i<card.getChildCount();i++)((TextView)card.getChildAt(i)).setTextColor(Color.WHITE);
        }else if(colorValid(folder.bgColor)&&!"#2563eb".equalsIgnoreCase(folder.bgColor)){
            int color=Color.parseColor(folder.bgColor);card.setBackground(shape(color));
            int contrasting=(Color.red(color)*299+Color.green(color)*587+Color.blue(color)*114)/1000<140?Color.WHITE:TEXT;
            for(int i=0;i<card.getChildCount();i++)((TextView)card.getChildAt(i)).setTextColor(contrasting);
        }
        card.setOnClickListener(v->push(folder.id));page.addView(card);gap(12);
    }
    private static boolean colorValid(String color){return color!=null&&color.matches("#[0-9a-fA-F]{6}");}
    private LinearLayout cardContainer(){
        LinearLayout card=column();card.setPadding(dp(16),dp(15),dp(16),dp(15));
        card.setBackground(shape(Color.WHITE));card.setElevation(dp(2));
        return card;
    }
    private void addTest(MockTest t){
        LinearLayout card=cardContainer();
        card.addView(text("📝  "+t.title,17,TEXT,true));
        if(!t.description.isEmpty()){
            TextView description=text(t.description,13,MUTED,false);description.setPadding(0,dp(5),0,0);card.addView(description);
        }
        String time=t.duration>0?t.duration+" मिनट":"बिना समय सीमा";
        TextView info=text(time+"  •  Online Test",13,MUTED,false);info.setPadding(0,dp(6),0,dp(10));card.addView(info);
        TextView action=text("Start Test  →",15,BLUE,true);action.setGravity(Gravity.END);card.addView(action);
        card.setOnClickListener(v->{
            if(!validId(t.id))return;
            Intent i=new Intent(this,ExtensionActivity.class);
            i.putExtra("page","mock-tests.html?test="+t.id);
            startActivity(i);
        });page.addView(card);gap(12);
    }
    @Override public void onBackPressed(){
        if(!trail.isEmpty()){trail.remove(trail.size()-1);currentFolder=trail.isEmpty()?null:trail.get(trail.size()-1);render();}
        else super.onBackPressed();
    }
}
