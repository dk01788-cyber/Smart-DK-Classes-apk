package com.smartdkclasses.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.SystemClock;
import android.text.InputType;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Inline Home-page question form; public users can INSERT, never SELECT submissions. */
public final class QueryFormView {
    private static final int BLUE = Color.rgb(7, 91, 216);
    private static final int DARK = Color.rgb(16, 35, 63);
    private static final int MUTED = Color.rgb(103, 123, 146);
    private static final String PRIVACY = "https://smart-dk-classes-web.pages.dev/privacy-policy.html";
    private final Activity activity;
    private EditText nameField, contactField, questionField;
    private Button sendButton;
    private long lastSendElapsed = 0L;

    public QueryFormView(Activity activity) {
        this.activity = activity;
    }

    public View build() {
        LinearLayout page = new LinearLayout(activity);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(8), dp(4), dp(8), dp(16));

        TextView intro = text("पढ़ाई से जुड़ा कोई सवाल है? यहाँ लिखकर भेजें। नाम और प्रश्न जरूरी हैं।", 13, MUTED, false);
        intro.setPadding(0, 0, 0, dp(6));
        page.addView(intro);

        nameField = field(page, "आपका नाम *", "नाम लिखें", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS, false);
        contactField = field(page, "मोबाइल नंबर या ईमेल आईडी", "मोबाइल नंबर या ईमेल आईडी लिखें", InputType.TYPE_CLASS_TEXT, false);
        questionField = field(page, "आपका प्रश्न / Description *", "अपना प्रश्न विस्तार से लिखें...", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES, true);

        TextView privacy = text("सवाल सीधे Admin तक जाएगा; सार्वजनिक नहीं दिखेगा। संपर्क के लिए चाहें तो मोबाइल नंबर या ईमेल आईडी लिखें। संपर्क नहीं देने पर व्यक्तिगत जवाब भेजना संभव नहीं होगा। कृपया OTP या पासवर्ड न लिखें।", 12, MUTED, false);
        privacy.setPadding(0, dp(14), 0, dp(6));
        page.addView(privacy);

        TextView policy = text("Privacy Policy देखें ↗", 12, BLUE, true);
        policy.setPadding(0, dp(5), 0, dp(5));
        policy.setOnClickListener(v -> {
            try { activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(PRIVACY))); }
            catch (Exception ex) { Toast.makeText(activity, "Privacy Policy नहीं खुल सकी।", Toast.LENGTH_SHORT).show(); }
        });
        page.addView(policy);

        sendButton = new Button(activity);
        sendButton.setText("प्रश्न भेजें / Submit");
        sendButton.setAllCaps(false);
        sendButton.setTextColor(Color.WHITE);
        sendButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        sendButton.setBackground(rounded(BLUE));
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        buttonLp.topMargin = dp(12);
        page.addView(sendButton, buttonLp);
        sendButton.setOnClickListener(v -> submit());
        return page;
    }

    private EditText field(LinearLayout page, String label, String hint, int type, boolean multiline) {
        TextView caption = text(label, 14, DARK, true);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, -2);
        labelLp.topMargin = dp(12);
        page.addView(caption, labelLp);
        EditText box = new EditText(activity);
        box.setHint(hint);
        box.setTextSize(14);
        box.setTextColor(DARK);
        box.setPadding(dp(12), dp(10), dp(12), dp(10));
        box.setInputType(type);
        box.setBackground(rounded(Color.WHITE));
        if (multiline) { box.setMinLines(4); box.setGravity(Gravity.TOP | Gravity.START); }
        else box.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, multiline ? -2 : dp(52));
        lp.topMargin = dp(5);
        page.addView(box, lp);
        return box;
    }

    private GradientDrawable rounded(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.rgb(218, 231, 245));
        return bg;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(activity);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private int dp(int n) {
        return Math.round(n * activity.getResources().getDisplayMetrics().density);
    }

    private void submit() {
        final String name = nameField.getText().toString().trim().replaceAll("\\s+", " ");
        final String contact = contactField.getText().toString().trim();
        final String email = contact.contains("@") ? contact : "";
        final String mobile = contact.isEmpty() || !email.isEmpty() ? "" : contact.replaceAll("[ -]", "");
        final String question = questionField.getText().toString().trim();
        if (name.length() < 2 || name.length() > 100) { nameField.setError("नाम 2–100 अक्षर में लिखें"); nameField.requestFocus(); return; }
        if (question.length() < 10 || question.length() > 3000) { questionField.setError("प्रश्न 10–3000 अक्षर में लिखें"); questionField.requestFocus(); return; }
        if (!email.isEmpty() && (email.length() > 254 || !Patterns.EMAIL_ADDRESS.matcher(email).matches())) { contactField.setError("सही ईमेल आईडी लिखें या खाली छोड़ दें"); contactField.requestFocus(); return; }
        if (!mobile.isEmpty() && !mobile.matches("\\+?[0-9]{7,15}")) { contactField.setError("सही मोबाइल नंबर लिखें या खाली छोड़ दें"); contactField.requestFocus(); return; }
        if (lastSendElapsed != 0L && SystemClock.elapsedRealtime() - lastSendElapsed < 30_000L) {
            Toast.makeText(activity, "कृपया कुछ समय बाद दोबारा प्रश्न भेजें।", Toast.LENGTH_SHORT).show(); return;
        }
        sendButton.setEnabled(false);
        sendButton.setText("भेज रहे हैं…");
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject data = new JSONObject();
                data.put("student_name", name);
                data.put("email", email.isEmpty() ? JSONObject.NULL : email);
                data.put("mobile", mobile.isEmpty() ? JSONObject.NULL : mobile);
                data.put("question", question);
                conn = (HttpURLConnection) new URL(ContentRepository.SUPABASE_URL + "/rest/v1/sdkc_student_queries").openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(18000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Prefer", "return=minimal");
                conn.setRequestProperty("apikey", ContentRepository.SUPABASE_KEY);
                try (OutputStream output = conn.getOutputStream()) {
                    output.write(data.toString().getBytes(StandardCharsets.UTF_8));
                }
                int status = conn.getResponseCode();
                if (status != 200 && status != 201 && status != 204) throw new Exception("HTTP " + status);
                activity.runOnUiThread(() -> {
                    lastSendElapsed = SystemClock.elapsedRealtime();
                    questionField.setText("");
                    sendButton.setEnabled(true);
                    sendButton.setText("प्रश्न भेजें / Submit");
                    new AlertDialog.Builder(activity).setTitle("प्रश्न भेज दिया गया ✅")
                            .setMessage("आपका प्रश्न Admin तक पहुँच गया। धन्यवाद!")
                            .setPositiveButton("ठीक है", null).show();
                });
            } catch (Exception e) {
                activity.runOnUiThread(() -> {
                    sendButton.setEnabled(true);
                    sendButton.setText("प्रश्न भेजें / Submit");
                    new AlertDialog.Builder(activity).setTitle("प्रश्न नहीं भेजा जा सका")
                            .setMessage("कृपया इंटरनेट जाँचें और दोबारा कोशिश करें।")
                            .setPositiveButton("ठीक है", null).show();
                });
            } finally { if (conn != null) conn.disconnect(); }
        }).start();
    }
}
