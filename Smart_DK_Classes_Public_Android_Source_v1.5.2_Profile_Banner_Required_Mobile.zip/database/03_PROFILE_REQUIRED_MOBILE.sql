-- Smart DK Classes profile update v1.5.2
-- Run once in Supabase SQL Editor BEFORE publishing Public v1.5.2 / Admin v1.5.3.
-- Stores name + unverified 10-digit mobile for the Admin student list. Photo remains on device.
-- The profile form displays a clear data notice before Continue; no OTP is used.

begin;

alter table public.sdkc_student_profiles
  add column if not exists mobile text;

alter table public.sdkc_student_profiles
  drop constraint if exists sdkc_student_profiles_mobile_10_digits;
alter table public.sdkc_student_profiles
  add constraint sdkc_student_profiles_mobile_10_digits
  check (mobile is null or mobile ~ '^[0-9]{10}$');

create or replace function public.sdkc_save_student_profile(
  p_id uuid,
  p_token uuid,
  p_name text,
  p_mobile text,
  p_consent boolean
) returns jsonb
language plpgsql volatile security definer set search_path to '' as $$
declare
  n text;
  m text;
  result_rows int;
begin
  if p_id is null or p_token is null then raise exception 'Invalid profile key'; end if;
  if coalesce(p_consent,false)=false then
    delete from public.sdkc_student_profiles
      where id=p_id and token_hash=md5(p_token::text);
    return jsonb_build_object('consent',false,'deleted',found);
  end if;
  n := btrim(coalesce(p_name,''));
  m := btrim(coalesce(p_mobile,''));
  if char_length(n)<2 or char_length(n)>60 then raise exception 'Invalid profile name'; end if;
  if m !~ '^[0-9]{10}$' then raise exception 'Invalid 10-digit mobile number'; end if;

  insert into public.sdkc_student_profiles(id,token_hash,display_name,mobile)
  values(p_id,md5(p_token::text),n,m)
  on conflict(id) do update
    set display_name=excluded.display_name,
        mobile=excluded.mobile,
        updated_at=now()
    where public.sdkc_student_profiles.token_hash=excluded.token_hash;
  get diagnostics result_rows=row_count;
  if result_rows<>1 then raise exception 'Invalid profile key'; end if;
  return jsonb_build_object('saved',true,'verified_mobile',false);
end; $$;

revoke all on function public.sdkc_save_student_profile(uuid,uuid,text,text,boolean) from public;
grant execute on function public.sdkc_save_student_profile(uuid,uuid,text,text,boolean) to anon,authenticated;

commit;

-- Admin-only reads remain governed by the existing RLS policy on sdkc_student_profiles.
-- Never describe mobile as verified: there is deliberately no OTP verification.
