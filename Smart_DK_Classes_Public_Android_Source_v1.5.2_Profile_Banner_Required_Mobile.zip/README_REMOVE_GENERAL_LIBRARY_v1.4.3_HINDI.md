# Smart DK Classes Public App v1.4.3 — Remove General Library Home Card

- MainActivity के Home Grid से General Library कार्ड हटाया गया है।
- Admin से भविष्य में उसी नाम का Custom Card आने पर भी उसे Home में नहीं दिखाएगा।
- GK, Reasoning, Mock Test, Class 9–12, Video, Download आदि पुराने स्क्रीन बने रहेंगे।
- Previous v1.4.2 YouTube player changes preserved.
- versionCode 19 / versionName 1.4.3।
- Source ZIP को APK repo में upload करने के बाद Actions से Signed APK Build करें।
- APK install/run test अभी नहीं किया गया।
