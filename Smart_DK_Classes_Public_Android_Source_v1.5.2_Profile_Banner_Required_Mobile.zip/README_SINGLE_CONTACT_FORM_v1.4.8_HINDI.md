# Smart DK Classes v1.4.8 — एक Contact फील्ड वाला प्रश्न फॉर्म

- Public App के Home Page में सबसे नीचे "अपना प्रश्न पूछें" फॉर्म यथावत है। अलग Query Menu/Tab नहीं जोड़ा गया।
- **आपका नाम *** और **आपका प्रश्न / Description *** अनिवार्य हैं।
- **मोबाइल नंबर या ईमेल आईडी** का एक ही फील्ड है। कोई एक विवरण दे सकते हैं, या खाली छोड़ सकते हैं।
- UI पर "Optional" शब्द नहीं लिखा है।
- यदि संपर्क में @ है, तो उसे वैध Email मानकर `email` कॉलम में भेजते हैं। अन्यथा 7–15 अंकों का फोन नंबर `mobile` कॉलम में जाता है। दोनों खाली होने पर दोनों कॉलम null रहते हैं।
- विद्यार्थियों की Query पुराने `public.sdkc_student_queries` Supabase Table और Admin Inbox में ही जाएगी; नया SQL लागू नहीं करना है।
- ऐप: versionName 1.4.8, versionCode 24, compileSdk/targetSdk 36, package `com.smartdkclasses.app`।
- पुरानी सुविधाएँ, थीम, Academic Classes, Mock Tests, Video और In-App Update यथावत।
- नया Signed APK/AAB बनाने के बाद वास्तविक डिवाइस पर फॉर्म की जाँच करें।
