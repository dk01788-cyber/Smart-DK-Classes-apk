# Smart DK Classes Public v1.4.2 - YouTube Embedded Player fix

## समस्या
VideoActivity.java में `webView.loadDataWithBaseURL("https://www.youtube.com", ...)` लगाया गया था। इससे ऐप YouTube की साइट को ही iframe host बताता था और Error 152-4 आ सकता था।

## सुधार
- VideoActivity.java में असली वेबसाइट `https://smart-dk-classes-web.pages.dev/` को HTML embed का `baseURL` बनाया गया।
- iframe में `referrerpolicy=strict-origin-when-cross-origin` और सही `origin` लगाया गया।
- पुराने UI, Back और 'View on YouTube' fallback को सुरक्षित रखा गया।
- `versionCode 18`, `versionName 1.4.2`।

## इस्तेमाल
1. इस ZIP को APK वाली GitHub repository `dk01788-cyber/Smart-DK-Classes-apk` में अपलोड/Commit करें।
2. GitHub Actions में Automatic APK Builder का नया सफल Build देखें।
3. `SDKC-Public-1.4.2-Signed` Artifact डाउनलोड करके ZIP से APK निकालें।
4. यदि पुरानी APK इसी signing key से signed है तो APK अपडेट के रूप में install हो सकेगी।

## ध्यान दें
इस ZIP का Android APK build और मोबाइल playback टेस्ट यहाँ नहीं किया गया। वीडियो के owner ने embedding निषिद्ध की हो, उम्र/क्षेत्र restrictions हों, तो YouTube iframe में वीडियो अब भी न चल सकेगा; ऐसे में 'View on YouTube' विकल्प काम करेगा।
