# Smart DK Classes Public App v1.4.5 — Google Play API 36

## क्या बदला
- `app/build.gradle`: `compileSdk 36`, `targetSdk 36`, `versionCode 21`, `versionName '1.4.5'`.
- `build.gradle`: Android Gradle Plugin `8.10.1`.
- `applicationId`: `com.smartdkclasses.app` (पहले जैसा).
- `minSdk 24` (पहले जैसा).
- ऐप का UI, सामग्री, Admin App, वेबसाइट, Firebase/Supabase सेटिंग और Android Manifest नहीं बदले गए.

## GitHub पर डालें
1. इस ZIP को **बिना unzip किए** APK Repository `dk01788-cyber/Smart-DK-Classes-apk` की main शाखा की जड़ में Upload करें.
2. अलग दी गई `build-sdkc-auto-apk-FIXED.yml` को मौजूदा `.github/workflows/build-sdkc-auto-apk-FIXED.yml` में एक बार Replace करें.
3. Commit करें; GitHub Actions नए Public ZIP से Debug APK, Signed APK और Signed Release AAB बनाएगा (यदि Signing Secrets ठीक हैं).
4. Artifacts में `SDKC-Public-1.4.5-PlayStore-AAB` देखें. डाउनलोड की ZIP खोलकर **.aab** अपलोड करें.

## Play Store भेजने से पहले
- यह केवल API 36 Migration और Build तैयारी है; APK/AAB का वास्तविक Build अभी इस पर्यावरण में नहीं चला.
- Pixel/Android 16 पर layout, permission, PDF, Mock Tests, YouTube और Ads जाँचें.
- Play App Signing / Signing certificate continuity जांचें; किसी से keystore password साझा न करें.
- Existing package id और Signing Key वही रखने से Google Play पर अलग app नहीं बनता.
- Play Store के लिए Privacy Policy, Data Safety, test track और content declarations अलग से आवश्यक हैं.
