# Public App v1.4.4 – Academic Classes Home

- Home पर Class 9–12 की जगह एक फुल-विथ Academic Classes कार्ड।
- Academic Classes क्लिक करने पर 9/10/11/12, आगे Subject → Category → Content का वही रास्ता।
- GK/Reasoning/Mock Test व अन्य Admin cards अलग बने रहेंगे।
- General Library Home से हटाने वाला v1.4.3 सुधार सुरक्षित है।
- YouTube Error 152–4 patch (v1.4.2) और Mock Exam Folders (v1.4.1) सुरक्षित।
- Version code 20/name 1.4.4; signed APK build / device verification बाकी।
