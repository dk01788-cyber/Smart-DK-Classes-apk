# Smart DK Classes Public App v1.5.1 — Mock Test Folder Refresh Fix

## क्या सुधारा गया
- Mock Test screen अब published `mock-hub` और `folder` records को fresh REST request से पढ़ती है।
- HTTP cache बंद किया और query limit 1000 रखा, ताकि नए प्रकाशित exam folders पुराने APK में अटके न रहें।
- Android versionName 1.5.1 और versionCode 27 किया गया है।
- Supabase में पहले से मौजूद folders/tests को delete या overwrite नहीं किया जाता।

## जरूरी चरण
1. इस ZIP को `Smart-DK-Classes-apk` repository में root में upload करें।
2. GitHub Actions में Automatic APK Builder चलाकर Public App build करें।
3. सफल Build के Artifact से नया APK डाउनलोड करें।
4. फोन में नया APK पुराने ऐप के ऊपर install करें; पहले पुराना ऐप uninstall न करें।
5. Internet चालू करके Mock Test खोलें। अब published folders Supabase से fresh load होंगे।

## महत्वपूर्ण
यह Source ZIP है, compiled APK नहीं। नया APK build/install किए बिना फोन पर कोई बदलाव नहीं आएगा। अगर नए folders फिर भी न दिखें, तो Supabase REST API की public SELECT/RLS policy की जाँच करनी होगी।
