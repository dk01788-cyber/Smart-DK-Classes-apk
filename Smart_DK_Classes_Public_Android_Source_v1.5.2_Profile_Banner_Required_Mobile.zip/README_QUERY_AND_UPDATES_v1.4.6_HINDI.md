# Smart DK Classes v1.4.6 — Query, Content Auto-Refresh और Google Play Updates

- Public App: Bottom Navigation में Query टैब जोड़ा गया है। Name तथा Question अनिवार्य हैं। Email और Mobile दोनों वैकल्पिक हैं।
- Questions Supabase `public.sdkc_student_queries` में जमा होते हैं। Public / anon को **INSERT ONLY**, कोई SELECT अधिकार नहीं।
- Admin App v1.4.2: Dashboard → Student Queries; देखने, Resolved/New करने और Delete करने की सुविधा।
- Content Auto-Refresh: ऐप लौटने/खोलने पर; `MainActivity.onResume()` में 60 सेकंड थ्रोटल। `sdkc_cards`, content, structure आदि फिर से fetch होते हैं।
- Google Play flexible in-app update: Android Play In-App Updates 2.1.0. Google Play से इंस्टॉल किए गए ऐप पर Play Store में higher version उपलब्ध होने पर पूछेगा; Update स्वीकार करने पर Download, फिर Restart संवाद। APK sideloaders को इस flow की गारंटी नहीं।
- App package ID पहले जैसा (`com.smartdkclasses.app`)। Public App v1.4.6 `versionCode 22`, API 36। Admin App v1.4.2, `versionCode 7`।
- Database SQL: `SDKC_Student_Queries_RLS.sql` (Supabase में लागू; Reapply भी सुरक्षित)।
- IMPORTANT: Google Play Console Data Safety में नाम, optional Email, optional Phone और User messages के संग्रह की सही घोषणा करें। App privacy policy में Query Collection का विवरण जोड़ें। 13 साल से कम बच्चों के लिए Google Play Families Policy और ads/consent requirements जाँचें।
- Spam: anonymous submission के लिए server-side rate limit / challenge अतिरिक्त सुरक्षा है। अभी app UI में 30 second cooldown है, जो automated spam को पूर्णतः नहीं रोकता। production traffic में rate limiting की सिफारिश।
- ऐप/एडमिन के वास्तविक GitHub APK/AAB Builds और फोन पर end-to-end परीक्षण अभी आवश्यक हैं।
