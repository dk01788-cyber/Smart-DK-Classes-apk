# Smart DK Classes — Profile Banner & Required Mobile Update

## क्या बदला है
- Home पर Welcome banner में profile photo, student name और mobile number दिखते हैं।
- Welcome के सामने छोटा ✎ Edit icon है; अलग “My Profile / Edit” button हटाया गया है।
- Update button उसी banner row में है और official website के `/app-update.html` पर खुलता है। Home पर दूसरा Update button नहीं है।
- Profile form से checkbox हटाया गया है। Continue से पहले साफ सूचना है कि नाम और मोबाइल Admin profile list में सेव होंगे।
- Name और 10-digit mobile required हैं। OTP/Login नहीं है। Photo optional है और फोन पर ही रहती है।
- Admin → Student Analytics में नाम और unverified mobile दिखाई देंगे।

## लागू करने का क्रम
1. Supabase SQL Editor में `database/03_PROFILE_REQUIRED_MOBILE.sql` चलाएँ।
2. Public source ZIP से Public APK बनाकर पुरानी signing key से sign करें; नया `versionCode` 28 है।
3. Admin source ZIP से Admin APK बनाकर उसकी पुरानी signing key से sign करें; नया `versionCode` 11 है।
4. पहले टेस्ट करें: नई प्रोफाइल → नाम और 10-digit mobile → Continue → Admin > Student Analytics में रिकॉर्ड दिखना।
5. पुराना ऐप uninstall न करें; उसी package/signing key से in-place upgrade करें।

## गोपनीयता और सीमाएँ
- कोई checkbox नहीं है, इसलिए profile form में Continue से पहले स्पष्ट data notice दिया गया है।
- मोबाइल नंबर बिना OTP के लिया जाता है; वह verified identity नहीं है और गलत/किसी दूसरे का नंबर भी हो सकता है।
- फोटो server पर नहीं भेजी जाती; वह local device पर रहती है।
- यह source update है, built/tested APK नहीं। Build और वास्तविक फोन पर परीक्षण अभी करना होगा।
- विद्यार्थियों में नाबालिग भी हों तो लागू कानून/अभिभावकीय सहमति और गोपनीयता आवश्यकताओं की समीक्षा करें।
