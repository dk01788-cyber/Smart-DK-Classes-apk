# Smart DK Classes Admin v1.2.0

अब App Structure Manager में Class Card, Subject, Category और Video Chapter पर:

- Edit Name
- Hide / Show
- Lock / Unlock
- Placement / Order
- Safe Delete

Lock होने पर item public side पर normal usable रह सकता है, लेकिन Admin में accidental rename, delete या placement/order change नहीं होगा। पहले Unlock करना होगा।

Content Manager में पहले से मौजूद Edit, Hide/Show, Move To और Delete controls बने रहते हैं।
