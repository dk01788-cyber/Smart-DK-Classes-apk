# Smart DK Classes Admin v1.1.0

- Class Card, Subject, Category और Video Chapter के लिए अलग App Structure Manager.
- हर structure item को Add, Rename/Edit, Hide/Show और safe-delete control.
- Add Content और Add Video में Class/Subject/Category/Chapter free-text नहीं; dropdown/select controls.
- नया Subject जोड़ने पर standard study categories automatically seed होती हैं.
- Video upload में Chapter select करना आवश्यक है; नया Chapter पहले Structure Manager से add होगा.
- किसी content को Delete किए बिना Move To से दूसरी Class/Subject/Category/Chapter में move किया जा सकता है.
- Content और video को Hide/Show किया जा सकता है.
- Class/Subject/Category/Chapter rename करने पर related app_content values भी update होती हैं.
- App Only / Website Only / Both placement controls.
- Home video manual selection retained.
- Shared Supabase `app_content` + `content_structure` backend Public App और Website दोनों के लिए source of truth है.
