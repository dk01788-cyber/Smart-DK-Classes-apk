alter table public.content_structure
  add column if not exists is_locked boolean not null default false;

comment on column public.content_structure.is_locked is
  'Admin safety lock. Locked structure items remain usable/visible but cannot be renamed, deleted, or have placement/order changed until unlocked.';
