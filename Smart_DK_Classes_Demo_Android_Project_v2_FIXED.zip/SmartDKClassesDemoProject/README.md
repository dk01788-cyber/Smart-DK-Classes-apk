# Smart DK Classes Demo v2

Updated demo using the locked blue-white theme and mirrored DK Sir banner.
This v2 demo uses a separate demo applicationId (`com.smartdkclasses.demo2`) so it can install alongside an older demo app.
