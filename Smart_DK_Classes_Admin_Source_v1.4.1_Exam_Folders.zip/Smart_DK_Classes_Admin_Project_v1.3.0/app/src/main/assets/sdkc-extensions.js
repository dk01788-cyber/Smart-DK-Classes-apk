/* SDKC 19 Oct 2026: additive Admin features. Existing login, banner, legacy academic upload preserved. */
let sdkcFolders=[],sdkcMaterials=[],sdkcTests=[],sdkcDesignItems=[],sdkcOrderItems=[];
const extGet=id=>document.getElementById(id);
const extEsc=s=>esc(s);
const extField=id=>norm(extGet(id)?.value);
const extError=(id,e)=>msg(id,e?.message||String(e),true);
const extSelect=(id,rows,label,selected='')=>{const el=extGet(id);if(!el)return;const old=selected||el.value;el.innerHTML=`<option value="">${extEsc(label)}</option>`+rows.map(x=>`<option value="${extEsc(x.id)}">${extEsc(x.title||x.name)}</option>`).join('');if([...el.options].some(x=>x.value===old))el.value=old;};
async function sdkcList(table,query=''){await ensureAdmin();return await api(`/rest/v1/${table}?select=*${query?'&'+query:''}`,{headers:authHeaders(false)})||[];}
async function sdkcInsert(table,body){await ensureAdmin();return await api(`/rest/v1/${table}`,{method:'POST',headers:{...authHeaders(true),Prefer:'return=representation'},body:JSON.stringify(body)});}
async function sdkcPatch(table,id,body){await ensureAdmin();return await api(`/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',headers:{...authHeaders(true),Prefer:'return=minimal'},body:JSON.stringify(body)});}
async function sdkcDelete(table,id){await ensureAdmin();return await api(`/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`,{method:'DELETE',headers:authHeaders(false)});}
function sdkcAcademicOptions(){
  const cats=structure.filter(x=>x.item_type==='category').map(x=>({id:x.id,title:[x.class_name,x.subject,x.name].join(' → ')}));
  extSelect('sdkcAcademicUpload',cats,'No Academic destination (Direct only)');
  extSelect('sdkcAcademicMove',cats,'No Academic destination (Direct only)');
}
function sdkcAcademicFields(id){const c=structure.find(x=>x.id===id&&x.item_type==='category');return c?{academic_class:c.class_name,academic_subject:c.subject,academic_category:c.name,academic_chapter:null}:{};}
function sdkcFolderOptions(){
 const rows=sdkcFolders.filter(x=>x.card_type==='folder');
 for(const name of ['sdkcParent','sdkcBulkFolder','sdkcMoveFolder'])extSelect(name,rows,name==='sdkcParent'?'No Parent (Top Level)':'General Library (No Folder)');
 const hub=sdkcFolders.find(x=>x.card_type==='mock-hub');
 const byId=new Map(sdkcFolders.map(c=>[c.id,c]));
 const isMockFolder=c=>{const seen=new Set();while(c&&!seen.has(c.id)){if(c.parent_id===hub?.id)return true;seen.add(c.id);c=byId.get(c.parent_id);}return false;};
 const testFolders=rows.filter(isMockFolder);
 extSelect('sdkcTestFolder',testFolders,'General Mock Tests (No Folder)');
 extSelect('sdkcMoveTestFolder',testFolders,'General Mock Tests (No Folder)');
 const list=extGet('sdkcMockFolderList');
 if(list)list.innerHTML=testFolders.length?testFolders.map(c=>`<div class="structure-row">📁 <b>${extEsc(c.title)}</b></div>`).join(''):'अभी कोई परीक्षा-फोल्डर नहीं है।';
}
async function sdkcRefreshFolders(){sdkcFolders=await sdkcList('sdkc_cards','order=sort_order.asc,created_at.asc');sdkcFolderOptions();
const list=extGet('sdkcFolderList');if(list)list.innerHTML=sdkcFolders.map(c=>`<div class="structure-row"><b>📁 ${extEsc(c.title)}</b><span class="muted"> ${c.parent_id?'Subfolder':'Main Section'}</span><div class="mini-actions"><button class="btn ghost" onclick="sdkcOpenDesign('custom','${c.id}')">🎨 Background</button><button class="btn ghost" onclick="sdkcRenameFolder('${c.id}')">Rename</button><button class="btn ghost" onclick="sdkcToggleFolder('${c.id}')">${c.is_published?'Hide':'Show'}</button><button class="btn red" onclick="sdkcDeleteEmptyFolder('${c.id}')">Delete Empty</button></div></div>`).join('');}
async function sdkcRenameFolder(id){const c=sdkcFolders.find(x=>x.id===id);if(!c)return;const title=norm(prompt('New Section/Folder name',c.title));if(!title)return;try{await sdkcPatch('sdkc_cards',id,{title});await sdkcRefreshFolders();}catch(e){extError('sdkcUploadMsg',e);}}
async function sdkcToggleFolder(id){const c=sdkcFolders.find(x=>x.id===id);if(!c)return;try{await sdkcPatch('sdkc_cards',id,{is_published:!c.is_published});await sdkcRefreshFolders();}catch(e){extError('sdkcUploadMsg',e);}}
async function sdkcDeleteEmptyFolder(id){const c=sdkcFolders.find(x=>x.id===id);if(!c)return;
 const hasChildren=sdkcFolders.some(x=>x.parent_id===id);const content=await sdkcList('sdkc_materials','card_id=eq.'+id+'&limit=1');const tests=await sdkcList('sdkc_mock_tests','card_id=eq.'+id+'&limit=1');const hasContent=content.length>0,hasTests=tests.length>0;
 if(hasChildren||hasContent||hasTests){alert('Move children, PDFs, Videos and Tests elsewhere before deleting.');return;}
 if(!confirm('Delete empty folder '+c.title+'?'))return;
 try{await sdkcDelete('sdkc_cards',id);await sdkcRefreshFolders();}catch(e){extError('sdkcUploadMsg',e);}}
async function sdkcCreateFolder(){
 const title=extField('sdkcFolderName'),parent_id=extField('sdkcParent')||null;
 if(!title){alert('Folder/Section name लिखें।');return;}
 try{await sdkcInsert('sdkc_cards',{title,parent_id,card_type:'folder',show_on_home:!parent_id,is_published:true,sort_order:999});extGet('sdkcFolderName').value='';await sdkcRefreshFolders();await sdkcShowMaterials();msg('sdkcUploadMsg','Section/Folder बनाया गया।');}catch(e){extError('sdkcUploadMsg',e);}
}
async function sdkcBulkUpload(){
 const files=[...extGet('sdkcMultiFiles').files],academicId=extField('sdkcAcademicUpload'),folder=academicId?null:(extField('sdkcBulkFolder')||null);
 if(!files.length){msg('sdkcUploadMsg','कृपया PDF फाइलें चुनें।',true);return;}
 if(files.some(f=>!(/\.pdf$/i.test(f.name) && f.size>0))){msg('sdkcUploadMsg','सभी फाइलें Valid PDFs होनी चाहिए।',true);return;}
 const btn=extGet('sdkcBulkBtn');btn.disabled=true;let completed=0,failed=[];
 try{
  for(const f of files){
   msg('sdkcUploadMsg',`${completed}/${files.length} PDFs uploaded: ${f.name}`);
   try{
    const path=await uploadPdf(f);
    await sdkcInsert('sdkc_materials',{title:f.name.replace(/\.pdf$/i,''),item_type:'pdf',card_id:folder,...sdkcAcademicFields(academicId),file_path:path,is_published:true});
    completed++;
   }catch(e){failed.push(`${f.name}: ${e.message}`);}
  }
  extGet('sdkcMultiFiles').value='';msg('sdkcUploadMsg',`${completed}/${files.length} PDFs uploaded.${failed.length?' Failed: '+failed.join('; '):''}`,failed.length>0);
  await sdkcShowMaterials();
 }finally{btn.disabled=false;}
}
async function sdkcAddVideo(){const title=extField('sdkcVideoTitle'),url=extField('sdkcVideoUrl'),card_id=extField('sdkcBulkFolder')||null;
 if(!title||!/^https:\/\/(www\.)?(youtube\.com|youtu\.be)\//i.test(url)){msg('sdkcUploadMsg','YouTube का सही HTTPS Link और Title दें।',true);return;}
 try{await sdkcInsert('sdkc_materials',{title,item_type:'video',external_url:url,card_id});msg('sdkcUploadMsg','Video added.');extGet('sdkcVideoTitle').value='';extGet('sdkcVideoUrl').value='';await sdkcShowMaterials();}catch(e){extError('sdkcUploadMsg',e);}
}
async function sdkcShowMaterials(){
 sdkcMaterials=await sdkcList('sdkc_materials','order=created_at.desc&limit=250');
 extGet('sdkcMaterialList').innerHTML=sdkcMaterials.map(x=>`<label class="structure-row" style="display:flex;align-items:center;gap:9px"><input type="checkbox" class="sdkc-material-check" value="${x.id}"><span>${x.item_type==='pdf'?'📄':'▶️'} ${extEsc(x.title)}<small class="muted" style="display:block">${extEsc(x.academic_class?[x.academic_class,x.academic_subject,x.academic_category].join(' → '):(sdkcFolders.find(f=>f.id===x.card_id)?.title||'General Library'))}</small></span></label>`).join('')||'<div class="notice">No materials uploaded yet.</div>';
}
async function sdkcBulkMove(){const ids=[...document.querySelectorAll('.sdkc-material-check:checked')].map(e=>e.value),academicId=extField('sdkcAcademicMove'),folder=academicId?null:(extField('sdkcMoveFolder')||null);
 if(!ids.length){msg('sdkcMoveMsg','पहले PDFs/Video select करें।',true);return;}
 try{for(const id of ids)await sdkcPatch('sdkc_materials',id,{card_id:folder,academic_class:null,academic_subject:null,academic_category:null,academic_chapter:null,...sdkcAcademicFields(academicId)});msg('sdkcMoveMsg',`${ids.length} items moved without re-upload.`);await sdkcShowMaterials();}catch(e){extError('sdkcMoveMsg',e);}
}
async function sdkcOpenDirect(){try{await loadStructure();await sdkcRefreshFolders();sdkcAcademicOptions();await sdkcShowMaterials();}catch(e){extError('sdkcUploadMsg',e);}}
function sdkcDesignSelect(){const key=extField('sdkcDesignItem'),o=sdkcDesignItems.find(x=>x.key===key);if(!o)return;
 extGet('sdkcBgMode').value=o.background_mode||'solid';extGet('sdkcBgColor').value=/^#[0-9a-f]{6}$/i.test(o.background_color||'')?o.background_color:'#2563eb';extGet('sdkcBgGradient').value=/^#[0-9a-f]{6}$/i.test(o.gradient_color||'')?o.gradient_color:'#0f766e';extGet('sdkcBgImage').value='';sdkcPreviewStyle();}
function sdkcPreviewStyle(){const key=extField('sdkcDesignItem'),o=sdkcDesignItems.find(x=>x.key===key),p=extGet('sdkcStylePreview');if(!p)return;
 p.textContent=o?.title||'Preview';const mode=extField('sdkcBgMode'),c=extField('sdkcBgColor'),g=extField('sdkcBgGradient');p.style.backgroundImage='';p.style.backgroundColor=c;
 if(mode==='gradient')p.style.backgroundImage=`linear-gradient(135deg, ${c}, ${g})`;
 if(mode==='image'){
  const img=extGet('sdkcBgImage').files[0];if(img){const r=new FileReader();r.onload=()=>{p.style.backgroundImage=`linear-gradient(#0005,#0005),url("${r.result}")`;p.style.backgroundSize='cover';};r.readAsDataURL(img);}else if(o?.background_image){p.style.backgroundImage=`linear-gradient(#0005,#0005),url("${o.background_image.replace(/"/g,'')}")`;p.style.backgroundSize='cover';}
 }
}
async function sdkcOpenDesign(type='',id=''){
 document.querySelectorAll('.adminTool').forEach(x=>x.style.display='none');extGet('sdkcDesignCard').style.display='block';try{await sdkcRefreshFolders();await loadStructure();
 sdkcDesignItems=[...structure.map(s=>({key:'academic:'+s.id,id:s.id,table:'content_structure',title:`${s.item_type}: ${s.name}`,background_mode:s.sdkc_background_mode,background_color:s.sdkc_background_color,gradient_color:s.sdkc_gradient_color,background_image:s.sdkc_background_image})),...sdkcFolders.map(c=>({key:'custom:'+c.id,id:c.id,table:'sdkc_cards',title:`Section: ${c.title}`,background_mode:c.background_mode,background_color:c.background_color,gradient_color:c.gradient_color,background_image:c.background_image}))];
 extSelect('sdkcDesignItem',sdkcDesignItems.map(x=>({id:x.key,title:x.title})),'Select card',type?type+':'+id:'');sdkcDesignSelect();
 }catch(e){extError('sdkcDesignMsg',e);}
}
async function sdkcSaveDesign(){const obj=sdkcDesignItems.find(x=>x.key===extField('sdkcDesignItem'));if(!obj){msg('sdkcDesignMsg','Please choose a card.',true);return;}
 try{let url=obj.background_image||null;const file=extGet('sdkcBgImage').files[0];if(file){if(!/^image\/(png|jpeg|webp)$/.test(file.type)||file.size>3_000_000)throw new Error('PNG/JPG/WEBP only, maximum 3MB');const path='backgrounds/'+Date.now()+'_'+file.name.replace(/[^a-zA-Z0-9._-]/g,'_');const r=await fetch(SUPABASE_URL+'/storage/v1/object/public-content/'+path,{method:'POST',headers:{apikey:SUPABASE_KEY,Authorization:'Bearer '+session.access_token,'Content-Type':file.type,'x-upsert':'false'},body:file});if(!r.ok)throw new Error('Image upload failed');url=SUPABASE_URL+'/storage/v1/object/public/public-content/'+path;}
 const vals={mode:extField('sdkcBgMode'),color:extField('sdkcBgColor'),gradient:extField('sdkcBgGradient'),image:url};
 const body=obj.table==='content_structure'?{sdkc_background_mode:vals.mode,sdkc_background_color:vals.color,sdkc_gradient_color:vals.gradient,sdkc_background_image:vals.mode==='image'?vals.image:null}:{background_mode:vals.mode,background_color:vals.color,gradient_color:vals.gradient,background_image:vals.mode==='image'?vals.image:null};
 const targets=extGet('sdkcApplySameType')?.checked ? sdkcDesignItems.filter(x=>{
   if(x.table!==obj.table)return false;
   if(x.table==='content_structure')return structure.find(y=>y.id===x.id)?.item_type===structure.find(y=>y.id===obj.id)?.item_type;
   return sdkcFolders.find(y=>y.id===x.id)?.parent_id===sdkcFolders.find(y=>y.id===obj.id)?.parent_id;
 }) : [obj];
 if(targets.length>1&&!confirm(`Apply same background to ${targets.length} cards?`))return;
 for(const target of targets)await sdkcPatch(target.table,target.id,body);
 msg('sdkcDesignMsg',`Background saved for ${targets.length} card(s).`);await sdkcOpenDesign(obj.table==='content_structure'?'academic':'custom',obj.id);
 }catch(e){extError('sdkcDesignMsg',e);}
}
async function sdkcResetDesign(){
 const obj=sdkcDesignItems.find(x=>x.key===extField('sdkcDesignItem'));if(!obj)return;
 if(!confirm('Restore original/default background of this card?'))return;
 try{const body=obj.table==='content_structure'
   ?{sdkc_background_mode:'solid',sdkc_background_color:null,sdkc_gradient_color:null,sdkc_background_image:null}
   :{background_mode:'solid',background_color:'#2563eb',gradient_color:'#0f766e',background_image:null};
 await sdkcPatch(obj.table,obj.id,body);await sdkcOpenDesign(obj.table==='content_structure'?'academic':'custom',obj.id);
 msg('sdkcDesignMsg','Default design restored.');}catch(e){extError('sdkcDesignMsg',e);}
}
function sdkcOrderContext(){const select=extGet('sdkcOrderParent');select.innerHTML='<option value="home">Home: Classes + Direct Sections</option><option value="allsubjects">All Academic Subjects</option><option value="allcategories">All Academic Categories</option><option value="allchapters">All Academic Chapters</option>'+sdkcFolders.map(x=>`<option value="folder:${x.id}">Inside: ${extEsc(x.title)}</option>`).join('');}
async function sdkcOpenOrder(){try{await sdkcRefreshFolders();await loadStructure();sdkcOrderContext();sdkcRenderOrder();}catch(e){extError('sdkcOrderMsg',e);}}
function sdkcRenderOrder(){const k=extField('sdkcOrderParent');let rows=[];
 if(k==='home')rows=[...structure.filter(x=>x.item_type==='class'&&x.is_visible!==false).map(x=>({id:x.id,title:x.name,table:'content_structure',sort_order:x.sort_order,is_locked:x.is_locked})),...sdkcFolders.filter(x=>x.parent_id===null&&x.show_on_home).map(x=>({id:x.id,title:x.title,table:'sdkc_cards',sort_order:x.sort_order}))];
 else if(k==='allsubjects'||k==='allcategories'||k==='allchapters')rows=structure.filter(x=>x.item_type===({allsubjects:'subject',allcategories:'category',allchapters:'chapter'}[k])).map(x=>({id:x.id,title:`${x.class_name||''} / ${x.subject||''} / ${x.name}`,table:'content_structure',sort_order:x.sort_order,is_locked:x.is_locked}));
 else if(k.startsWith('folder:'))rows=sdkcFolders.filter(x=>x.parent_id===k.slice(7)).map(x=>({id:x.id,title:x.title,table:'sdkc_cards',sort_order:x.sort_order}));
 sdkcOrderItems=rows.sort((a,b)=>(a.sort_order||0)-(b.sort_order||0)||a.title.localeCompare(b.title));
 extGet('sdkcOrderList').innerHTML=sdkcOrderItems.map((x,i)=>`<div class="structure-row"><b>${i+1}. ${extEsc(x.title)}</b><span style="float:right"><input style="width:54px" type="number" min="1" max="${sdkcOrderItems.length}" value="${i+1}" onchange="sdkcSetPosition(${i},this.value)" aria-label="Set position"> <button class="btn ghost" onclick="sdkcMoveOrder(${i},-1)" ${i===0||x.is_locked?'disabled':''}>↑</button> <button class="btn ghost" onclick="sdkcMoveOrder(${i},1)" ${i===sdkcOrderItems.length-1||x.is_locked?'disabled':''}>↓</button></span></div>`).join('')||'<div class="notice">No cards here.</div>';
}
async function sdkcSetPosition(i,p){const target=Math.max(0,Math.min(sdkcOrderItems.length-1,Number(p)-1));
 if(!Number.isInteger(target)||target===i){sdkcRenderOrder();return;}
 const entry=sdkcOrderItems[i];if(!entry||entry.is_locked)return;
 const array=[...sdkcOrderItems];if(array.slice(Math.min(i,target),Math.max(i,target)+1).some(x=>x.is_locked)){alert('Unlock affected cards first.');return;}array.splice(i,1);array.splice(target,0,entry);
 try{for(let n=0;n<array.length;n++)await sdkcPatch(array[n].table,array[n].id,{sort_order:(n+1)*10});
 await loadStructure();await sdkcRefreshFolders();sdkcRenderOrder();msg('sdkcOrderMsg','Position changed.');}
 catch(e){extError('sdkcOrderMsg',e);}
}
async function sdkcMoveOrder(i,delta){const a=sdkcOrderItems[i],b=sdkcOrderItems[i+delta];if(!a||!b||a.is_locked||b.is_locked)return;
 try{
  // Shift positions across mixed tables using a deterministic sequence; no content is moved/deleted.
  const reordered=[...sdkcOrderItems];[reordered[i],reordered[i+delta]]=[reordered[i+delta],reordered[i]];
  for(let j=0;j<reordered.length;j++){await sdkcPatch(reordered[j].table,reordered[j].id,{sort_order:(j+1)*10});}
  if(extField('sdkcOrderParent')==='home'){await loadStructure();await sdkcRefreshFolders();}
  else if(extField('sdkcOrderParent').startsWith('folder:'))await sdkcRefreshFolders();else await loadStructure();
  sdkcRenderOrder();msg('sdkcOrderMsg','Order saved.');
 }catch(e){extError('sdkcOrderMsg',e);}
}
async function sdkcEnsureMockHub(){try{await sdkcRefreshFolders();let hub=sdkcFolders.find(x=>x.card_type==='mock-hub');if(!hub){await sdkcInsert('sdkc_cards',{title:'Mock Test',card_type:'mock-hub',show_on_home:true,is_published:true,sort_order:500});await sdkcRefreshFolders();}else if(!hub.show_on_home||!hub.is_published){await sdkcPatch('sdkc_cards',hub.id,{show_on_home:true,is_published:true});}
 msg('sdkcTestMsg','Main Mock Test Card is enabled.');}catch(e){extError('sdkcTestMsg',e);}}
async function sdkcOpenMock(){try{await sdkcRefreshFolders();await sdkcLoadTests();}catch(e){extError('sdkcTestMsg',e);}}
async function sdkcCreateMockFolder(){
 const title=extField('sdkcMockFolderName');
 if(!title){msg('sdkcTestMsg','Exam Folder का नाम लिखें।',true);return;}
 try{
  await sdkcEnsureMockHub();
  const hub=sdkcFolders.find(x=>x.card_type==='mock-hub');
  if(!hub)throw Error('Main Mock Test Card नहीं मिला।');
  const existing=sdkcFolders.find(x=>x.parent_id===hub.id&&x.title.toLowerCase()===title.toLowerCase());
  if(existing){msg('sdkcTestMsg','यह Folder पहले से है।');extGet('sdkcTestFolder').value=existing.id;return;}
  const created=await sdkcInsert('sdkc_cards',{title,card_type:'folder',parent_id:hub.id,show_on_home:false,is_published:true,sort_order:sdkcFolders.filter(x=>x.parent_id===hub.id).length*10+10});
  await sdkcRefreshFolders();
  extGet('sdkcMockFolderName').value='';
  if(created[0])extGet('sdkcTestFolder').value=created[0].id;
  msg('sdkcTestMsg','Exam Folder बन गया। अब इसमें Mock Test बनाएँ या पुराने Test को Move करें।');
 }catch(e){extError('sdkcTestMsg',e);}
}
async function sdkcMoveTestToFolder(){
 const id=extField('sdkcTestSelect');
 if(!id){msg('sdkcTestMsg','पहले कोई Test चुनें।',true);return;}
 try{
  await sdkcPatch('sdkc_mock_tests',id,{card_id:extField('sdkcMoveTestFolder')||null});
  msg('sdkcTestMsg','Test को चुने हुए परीक्षा-फोल्डर में रख दिया गया।');
 }catch(e){extError('sdkcTestMsg',e);}
}
async function sdkcLoadTests(){sdkcTests=await sdkcList('sdkc_mock_tests','order=created_at.desc&limit=100');extSelect('sdkcTestSelect',sdkcTests,'Select a Test');await sdkcLoadQuestions();}
async function sdkcCreateTest(){let title=extField('sdkcTestTitle'),duration=Number(extField('sdkcTestDuration')),negative=Number(extField('sdkcTestNegative'));
 if(!title||!Number.isInteger(duration)||duration<0||duration>600||negative<0){msg('sdkcTestMsg','Valid title, duration and negative marks दें।',true);return;}
 try{const folder=extField('sdkcTestFolder')||null;await sdkcEnsureMockHub();const rows=await sdkcInsert('sdkc_mock_tests',{title,description:extField('sdkcTestDescription')||null,card_id:folder,duration_minutes:duration,negative_marks:negative,show_answers:extGet('sdkcTestReview').checked,is_published:false});await sdkcLoadTests();extGet('sdkcTestSelect').value=rows[0].id;await sdkcLoadQuestions();msg('sdkcTestMsg','Draft test created. Add questions, then Publish.');}catch(e){extError('sdkcTestMsg',e);}
}
async function sdkcAddQuestion(){const test_id=extField('sdkcTestSelect'),question_text=extField('sdkcQuestionText'),options=extGet('sdkcQuestionOptions').value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean),correct_index=Number(extField('sdkcCorrectOption'))-1,marks=Number(extField('sdkcQuestionMarks'));
 if(!test_id||!question_text||options.length<2||options.length>6||correct_index<0||correct_index>=options.length||marks<=0){msg('sdkcQuestionMsg','Question, 2–6 options, correct option और marks सही भरें।',true);return;}
 try{await sdkcInsert('sdkc_mock_questions',{test_id,question_text,options,correct_index,marks,explanation:extField('sdkcQuestionExplanation')||null,sort_order:document.querySelectorAll('#sdkcQuestionList .structure-row').length*10});
 for(const id of ['sdkcQuestionText','sdkcQuestionOptions','sdkcQuestionExplanation'])extGet(id).value='';msg('sdkcQuestionMsg','Question added.');await sdkcLoadQuestions();}catch(e){extError('sdkcQuestionMsg',e);}
}
async function sdkcLoadQuestions(){const id=extField('sdkcTestSelect');if(!id){extGet('sdkcQuestionList').innerHTML='<div class="notice">Create or select a test.</div>';return;}
 try{const questions=await sdkcList('sdkc_mock_questions','test_id=eq.'+encodeURIComponent(id)+'&order=sort_order.asc');extGet('sdkcQuestionList').innerHTML=questions.map((q,i)=>`<div class="structure-row"><b>${i+1}. ${extEsc(q.question_text)}</b><div class="muted">Correct: ${extEsc(q.options[q.correct_index])} · ${q.marks} marks</div><button class="btn red" onclick="sdkcDeleteQuestion('${q.id}')">Delete</button></div>`).join('')||'<div class="notice">No questions yet.</div>';}
 catch(e){extError('sdkcQuestionMsg',e);}
}
async function sdkcDeleteQuestion(id){if(!confirm('Delete this question?'))return;try{await sdkcDelete('sdkc_mock_questions',id);await sdkcLoadQuestions();}catch(e){extError('sdkcQuestionMsg',e);}}
async function sdkcPublishTest(flag){const id=extField('sdkcTestSelect');if(!id){msg('sdkcTestMsg','Select a test.',true);return;}
 try{if(flag){const rows=await sdkcList('sdkc_mock_questions','test_id=eq.'+encodeURIComponent(id)+'&limit=1');if(!rows.length)throw new Error('Add at least one question before publishing.');}
 await sdkcPatch('sdkc_mock_tests',id,{is_published:flag});msg('sdkcTestMsg',flag?'Test Published. Students can start it.':'Test is now Draft.');await sdkcLoadTests();extGet('sdkcTestSelect').value=id;}catch(e){extError('sdkcTestMsg',e);}
}

// CSV import: quoted commas and newlines are handled; rejected rows never silently become quiz questions.
function sdkcParseCsv(src){let rows=[],row=[],value='',quoted=false;const s=String(src||'').replace(/^\uFEFF/,'');
 for(let i=0;i<s.length;i++){const c=s[i];if(c==='"'){if(quoted&&s[i+1]==='"'){value+='"';i++;}else quoted=!quoted;}
 else if(c===','&&!quoted){row.push(value);value='';}
 else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&s[i+1]==='\n')i++;row.push(value);if(row.some(x=>x.trim()))rows.push(row);row=[];value='';}
 else value+=c;}
 if(quoted)throw Error('Malformed CSV: unclosed quote');row.push(value);if(row.some(x=>x.trim()))rows.push(row);return rows;}
async function sdkcImportQuestionsCsv(){const test_id=extField('sdkcTestSelect'),file=extGet('sdkcQuestionsCsv').files[0];if(!test_id||!file){msg('sdkcQuestionMsg','Select test and CSV file.',true);return;}
 try{const content=await file.text(),rows=sdkcParseCsv(content);if(rows.length<2)throw Error('CSV needs header and rows');
 const columns=rows[0].map(x=>x.trim().toLowerCase());const required=['question','optiona','optionb','optionc','optiond','correct'];for(const key of required)if(!columns.includes(key))throw Error('Missing CSV column '+key);
 let done=0;const invalid=[];
 for(let i=1;i<rows.length;i++){const record={};rows[i].forEach((x,j)=>record[columns[j]]=x.trim());
  const options=['optiona','optionb','optionc','optiond','optione','optionf'].map(k=>record[k]).filter(Boolean),correct=Number(record.correct)-1,marks=Number(record.marks||'1');
  if(!record.question||options.length<2||correct<0||correct>=options.length||!Number.isInteger(correct)||!Number.isFinite(marks)||marks<=0){invalid.push(i+1);continue;}
  await sdkcInsert('sdkc_mock_questions',{test_id,question_text:record.question,options,correct_index:correct,explanation:record.explanation||null,marks,sort_order:(done+1)*10});done++;
  msg('sdkcQuestionMsg',`${done} imported, ${invalid.length} invalid. ${i}/${rows.length-1} processed`);
 }
 extGet('sdkcQuestionsCsv').value='';await sdkcLoadQuestions();msg('sdkcQuestionMsg',`${done} questions imported. ${invalid.length?'Invalid rows: '+invalid.join(', '):''}`,invalid.length>0);
 }catch(e){extError('sdkcQuestionMsg',e);}
}
